/**
 * 
 * The phone class represents a cellular phone.
 * 
 * Add the instance variables you think a phone would need
 */ 

public class Phone
{

    // Attributes
   
    

}
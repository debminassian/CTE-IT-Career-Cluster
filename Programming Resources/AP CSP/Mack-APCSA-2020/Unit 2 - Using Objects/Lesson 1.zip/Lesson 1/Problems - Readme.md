# Example: Rectangle Skeleton
Here is an example of the first piece of a class definition. This code will be used later to create objects. Until we use the class definition to instantiate objects, this code will not do anything.


Hence, this code is for you to look and not to run. Nothing will happen if you hit run.

# Example: GrilledCheese Skeleton
Here is an example of the first piece of a class definition. This code will be used later to create objects. Until we use the class definition to instantiate objects, this code will not do anything.


Hence, this code is for you to look and not to run. Nothing will happen if you hit run.

# Example: Shark Skeleton
Here is an example of the first piece of a class definition. This code will be used later to create objects. Until we use the class definition to instantiate objects, this code will not do anything.


Hence, this code is for you to look and not to run. Nothing will happen if you hit run.

# Problem 1 - Free Response: What instance variables?
A big part of using classes in Java is thinking about the design of the class. You’ll need to figure out what information needs to be in the blueprint. So far we’ve seen a handful of examples. For instance, in our Rectangle class, we needed to know the width and height.

This exercise is a free response question. Imagine that someone comes to you and asks you to design a class that represents a Pizza.

1. What instance variables should the Pizza class have?

2. What do the instance variables represent? What are the types of those instance variables?

# Problem 2 - Pizza Instance Variables
This class represents a `Pizza`.

Add the instance variables you came up with in the last exercise to the class.

Don’t forget to give the variables a type and a name. They should not have values at this point.

# Problem 3 - Phone Skeleton
This class represents a phone.

Add the instance variables you think a phone would need, like you did for the `Pizza` class.


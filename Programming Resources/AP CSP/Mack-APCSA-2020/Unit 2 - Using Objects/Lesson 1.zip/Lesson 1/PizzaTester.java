public class PizzaTester
{
    public static void main(String[] args)
    {
        System.out.println("You should be able to run this");
        System.out.println("if you added the instance variables correctly");
        
    }
}

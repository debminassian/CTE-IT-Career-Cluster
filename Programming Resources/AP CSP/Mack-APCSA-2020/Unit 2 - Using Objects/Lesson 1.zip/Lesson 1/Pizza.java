public class Pizza
{
    // Add your instance variables here
}

# Example: Using the Math Class
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

MathDemos

# Example: Static Methods: Rectangle
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

Rectangle & RectangleTester

# Example: Generating Random Numbers
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

RandomRange

# Problem 1 - Circle Area
Here is a `Circle` class.

Implement `getArea` and `getCircumference` by using methods from the `Math` class.
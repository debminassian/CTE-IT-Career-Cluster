# Example: Variables
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

# Example: Using Final
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

# Problems 1 - Our First Integer
Write a program that declares an int named `year` and set
it equal to the current year. Then print it out.

If it were the year 2016, the output should say:
```
The current year is 2016
```
**Note**: You must include the current year and the word “year” in your output.

# Example: Swapping Two Values
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

# Answering Questions5 points
In this exercise, we’ve started to declare some variables but we don’t know the answers to the questions. You should fill in the rest of the lines to make them correct.
```
String myName = "";
int luckyNumber = /* you fill in */;
double ...
boolean ...
```

Edit the code so that the output of running the program is:
```
Karel the Dog
11
75.3
true
```
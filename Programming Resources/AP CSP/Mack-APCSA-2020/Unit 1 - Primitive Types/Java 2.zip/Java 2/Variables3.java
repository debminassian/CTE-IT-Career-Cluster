public class Variables3 
{
    public static void main(String[] args)
    {
        String myName = 
        int luckyNumber = 
        double currentTemperature = 
        boolean isStudent = 
        
        System.out.println(myName);
        System.out.println(luckyNumber);
        System.out.println(currentTemperature);
        System.out.println(isStudent);
    }
}
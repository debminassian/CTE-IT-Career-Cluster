public class Variables 
{

    public static void main(String[] args)
    {
        int snapchatsSent = 353;
        System.out.print("Number of snapchats sent: ");
        System.out.println(snapchatsSent);
        
        double youTubeVideosWatched = 130.5;
        System.out.print("Number of YouTube videos watched: ");
        System.out.println(youTubeVideosWatched);
        
        String favoriteApp = "Instagram";
        System.out.print("Favorite app: ");
        System.out.println(favoriteApp);
        
        youTubeVideosWatched = 240.4;
        
        System.out.print("Number of YouTube videos watched: ");
        System.out.println(youTubeVideosWatched);
        
        char firstLetter = 'A';
        System.out.print("First letter: ");
        System.out.println(firstLetter);
    }

}
public class Art 
{
    public static void main(String[] args)
    {
       //your code goes here!
    }

}
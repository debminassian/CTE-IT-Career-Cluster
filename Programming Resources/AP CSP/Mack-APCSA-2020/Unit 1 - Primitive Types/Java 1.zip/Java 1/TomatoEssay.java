public class TomatoEssay
{
    public static void main(String[] args)
    {
        // Start here!
        System.out.println("Is a tomato a fruit or a vegetable?");
        System.out.println("While biologically speaking a tomato");
        System.out.println(" is a fruit, legally speaking it is a vegetable!");
        System.out.print("In Supreme Court Case Nix v. Hedden, the Court");
        System.out.println(" ruled that tomatoes should be classified as a vegetable");
        System.out.println(" under U.S Customs regulations because they are consumed");
        System.out.println(" more like a vegetable than a fruit, and should be taxed as such.");
        System.out.print("When tomatoes are shipped into the U.S, they are now taxed as vegetables");
        System.out.println(" even though their anatomy suggests otherwise.");
    }
}
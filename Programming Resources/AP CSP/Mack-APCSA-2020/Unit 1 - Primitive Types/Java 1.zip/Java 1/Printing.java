public class Printing
{
    public static void main(String[] args)
    {
        System.out.println("Hello world.");
        System.out.println("Another line");
        
        System.out.print("Print will add to ");
        System.out.print("the same line!");
    }
}
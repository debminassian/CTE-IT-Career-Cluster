public class Welcome 
{
    public static void main(String[] args)
    {
        // Your code will go here
        // These lines are comments
        // Java ignores anything that comes after 
        // two forward slashes
        // You can delete the comments or leave them in
        // Java ignores them anyway!
    } 
}
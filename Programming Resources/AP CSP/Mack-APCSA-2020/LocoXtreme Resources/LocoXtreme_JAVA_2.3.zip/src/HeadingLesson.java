/** Program HeadingLesson.java 
 	Example program to find a heading value
*/


import java.util.Scanner;
import java.util.concurrent.TimeUnit;

/** Public Class Name Matches File Name */
public class HeadingLesson
{	
	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr dc:00";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		control.scan(2000);
				
		// Connect to Named Robot - Connection Function Returns Robot Object Named Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		robot.enableSensor(MessageCodes.D_Magnetometer, 1);
		robot.enableSensor(MessageCodes.D_Accelerometer, 1);
		// Wait for 500 Milliseconds
		control.waitTime(500);
		
		
		System.out.println("Starting calibration");
		double[] offsets = calibrateMag(robot, 10);
		
		String offsetStr = String.format("Offsets (minx, miny, minz, maxx, maxy, maxz): %f, %f, %f, %f, %f, %f", 
				offsets[0], offsets[1], offsets[2], offsets[3], offsets[4], offsets[5]);
		
		System.out.println(offsetStr);
		
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);		
	}
	
	/** Calibrates Magnetometer
	* @param GroundRobot Object
	* @param Long Type Calibration Time
	* @return Double Array Type 
	*/
	public static double[] calibrateMag(GroundRobot headingRobot, long timeSpan) {
		double mOffsets[] = new double[6];
		double minx = 32767.0, maxx = -32768.0;
		double miny = 32767.0, maxy = -32768.0;
		double minz = 32767.0, maxz = -32768.0;
		
		// Timed Loop to Run for 10 Seconds
		for (long stop=System.nanoTime() + TimeUnit.SECONDS.toNanos(timeSpan); stop > System.nanoTime();)
		{
			double mx = headingRobot.getMagnetometerXFiltered();
			double my = headingRobot.getMagnetometerYFiltered();
			double mz = headingRobot.getMagnetometerZFiltered();
			minx = Math.min(minx, mx);
			miny = Math.min(miny, my);
			minz = Math.min(minz, mz);
			maxx = Math.max(maxx, mx);
			maxy = Math.max(maxy, my);
			maxz = Math.max(maxz, mz);
					
			headingRobot.waitTime(100);
		}
		
		mOffsets[0] = minx;
		mOffsets[1] = miny;
		mOffsets[2] = minz;
		mOffsets[3] = maxx;
		mOffsets[4] = maxy;
		mOffsets[5] = maxz;
		
		return mOffsets;
	}

	/** Calculates Pitch Angle Based on Accelerometer Data
	* @param GroundRobot Object
	* @param Double array of Magnetometer Offset Values
	* @return Double Type Heading Angle in Radians
	*/
	public static double findHeading(GroundRobot headingRobot, double[] offsets)
	{
		
		double rad2deg = 180.0 / Math.PI;

		double heading = 0;
		double mx = headingRobot.getMagnetometerXFiltered();
		double my = headingRobot.getMagnetometerYFiltered();
		double mz = headingRobot.getMagnetometerZFiltered();
		
		double ax = headingRobot.getAccelXFiltered();
		double ay = headingRobot.getAccelYFiltered();
		double az = headingRobot.getAccelZFiltered();
		
		double roll = calcualteRoll(ax, ay, az);
		double pitch = calcualtePitch(ax, ay, az);
		
		double croll = Math.cos(roll);
		double cpitch = Math.cos(pitch);
		double sroll = Math.sin(roll);
		double spitch = Math.sin(pitch);
		
		mx = mx - ((offsets[0] + offsets[3]) / 2.0);
		my = my - ((offsets[1] + offsets[4]) / 2.0);
		mz = mz - ((offsets[2] + offsets[5]) / 2.0);
		
		double mag_norm = Math.sqrt((mx*mx)+(my*my)+(mz*mz));
		mx = mx / mag_norm;
		my = my / mag_norm;
		mz = mz / mag_norm;
		
		double headx = mx * cpitch + my * sroll * spitch + mz * croll * spitch;
		double heady = mz * sroll - my * croll;
		
		heading = Math.atan2(heady, headx) * rad2deg;
		if (heading < 0.0) {
			heading = heading + 360.0;
		}
		return heading;
	}

	/** Calculates Pitch Angle Based on Accelerometer Data
	* @return Double Type Pitch Angle in Radians
	*/
	public static double calcualtePitch(double _ax, double _ay, double _az) {
		double pitch = 0;
		try
		{
			pitch = Math.atan2(_ay, Math.sqrt(_ax*_ax + _az*_az));
		}
		catch(Exception E) { E.printStackTrace(); }		
		return pitch;
	}

	/** Calculates Roll Angle Based on Accelerometer Data
	* @return Double Type Roll Angle in Radians
	*/
	public static double calcualteRoll(double _ax, double _ay, double _az) {
		double roll = 0;
		try
		{
			roll = Math.atan2(_ax, Math.sqrt(_ay*_ay + _az*_az));
		}
		catch(Exception E) { E.printStackTrace(); }
		return roll;
	}	
	
	
}
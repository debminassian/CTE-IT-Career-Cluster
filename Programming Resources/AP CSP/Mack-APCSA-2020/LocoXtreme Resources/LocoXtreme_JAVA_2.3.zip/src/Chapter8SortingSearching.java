/** Program Chapter8SortingSearching.java 
 	Example program to show Sorting and Searching in Java   
*/

import java.util.ArrayList;

/** Public Class Name Matches File Name */
public class Chapter8SortingSearching
{	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Array List of Ground Robots set as null
		ArrayList<GroundRobot> scannedBots = null;
		
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		scannedBots = control.scan(2000);
		// Check Robot Names
		System.out.print("Robot Names: ");
		// For-Each Loop 
		for (GroundRobot bot : scannedBots)
		{
			System.out.println(bot.getName());
		}
		// Connect to Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		robot.enableSensor(MessageCodes.D_Accelerometer, 1);
		// Wait for 500 Milliseconds
		control.waitTime(500);
		
		// Initialize Variables for Data Reading
		int samples = 1000, i = 0;
		double[] accMagData = new double[samples];
		double[] accMagDataMergeSorted;
		double ax = 0, ay = 0, az = 1;
		
		// Loop For the Number of Samples. Read and Save Data Each Iteration
		while (i < samples)
		{			
			ax = robot.getAccelXFiltered();
			ay = robot.getAccelYFiltered();
			az = robot.getAccelZFiltered();
			accMagData[i] = Math.abs(1 - Math.sqrt(ax * ax + ay * ay + az * az));
			control.waitTime(10);
			i++;
		}
				
		// Perform a Merge Sort on the Data, Look at the Duration of the Sort in Nanoseconds, and Print the Data 
		long startTime = System.nanoTime();
		accMagDataMergeSorted = MergeSort.mergeSort(accMagData);
		long mergeSortDuration = System.nanoTime() - startTime;
		System.out.println("Stationary Robot, Acceleration Magntiude Errors Merge Sorted Smallest to Largest.");
		System.out.println("Merge Sort Time (nanoseconds): " + mergeSortDuration);
		System.out.print("Merge Sorted Acceleration Magnitude Error Data: ");
		for (double i1 : accMagDataMergeSorted)
		{
			System.out.print(i1 + ",");
		}
		System.out.println("");
		
		// Perform an Insertion Sort on the Data, Look at the Duration of the Sort in Nanoseconds, and Print the Data
		startTime = System.nanoTime();
		InsertionSort.insertionSort(accMagData);
		mergeSortDuration = System.nanoTime() - startTime;
		System.out.println("Stationary Robot, Acceleration Magntiude Errors Insert Sorted Smallest to Largest.");
		System.out.println("Insertion Sort Time (nanoseconds): " + mergeSortDuration);		
		System.out.print("Insertion Sorted Acceleration Magnitude Error Data: ");
		for (double i1 : accMagDataMergeSorted)
		{
			System.out.print(i1 + ",");
		}
		System.out.println("");		
		
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);	
	}
}


/** Insert Sort Class */
class InsertionSort {  
		
	/** Perform an Insertion Sort on the Provided Double Type Data Array 
	 * @param Double Type Array of Data to Be Sorted
	 */
    public static void insertionSort(double array[]) {  
        int n = array.length;  
        for (int j = 1; j < n; j++) {  
            double key = array[j];  
            int i = j-1;  
            while ( (i > -1) && ( array [i] > key ) ) {  
                array [i+1] = array [i];  
                i--;  
            }  
            array[i+1] = key;  
        }  
    }    
}

/** Merge Sort Class */
class MergeSort
{
	/** Perform an Insertion Sort on the Provided Double Type Data Array 
	 * @param Double Type Array of Data to Be Sorted
	 * @return Double Type Array of Sorted Data
	 */
    public static double[] mergeSort(double [] list) {
        if (list.length <= 1) {
            return list;
        }
        
        // Split the Array in Half
        double[] first = new double[list.length / 2];
        double[] second = new double[list.length - first.length];
        System.arraycopy(list, 0, first, 0, first.length);
        System.arraycopy(list, first.length, second, 0, second.length);
        
        // Sort Both Halves
        mergeSort(first);
        mergeSort(second);
        
        // Merge the Halves, Overwriting the Original Array
        merge(first, second, list);
        return list;
    }
    
	/** Perform an Insertion Sort on the Provided Double Type Data Array 
	 * @param Double Type Array of First Half of Data to Be Sorted
	 * @param Double Type Array of Second Half of Data to Be Sorted
	 * @param Double Type Array to Store Result From Both Halves In
	 */
    private static void merge(double[] first, double[] second, double [] result) {
        // Merge both halves into the result array
        // Next element to consider in the first array
        int iFirst = 0;
        // Next element to consider in the second array
        int iSecond = 0;
        
        // Next open position in the result
        int j = 0;
        // As long as neither iFirst nor iSecond is past the end, move the
        // smaller element into the result.
        while (iFirst < first.length && iSecond < second.length) {
            if (first[iFirst] < second[iSecond]) {
                result[j] = first[iFirst];
                iFirst++;
                } else {
                result[j] = second[iSecond];
                iSecond++;
            }
            j++;
        }
        // copy what's left
        System.arraycopy(first, iFirst, result, j, first.length - iFirst);
        System.arraycopy(second, iSecond, result, j, second.length - iSecond);
    }
}



/** Program Chapter4ObjectClass.java 
 	Example program to show use of the Object Class in Java   
*/

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;


/** Public Class Name Matches File Name */
public class Chapter4ObjectClass
{
	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Array List of Ground Robots set as null
		ArrayList<GroundRobot> scannedBots = null;
		
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		scannedBots = control.scan(2000);
		// Check Robot Names
		System.out.print("Robot Names: ");
		// For-Each Loop 
		for (GroundRobot bot : scannedBots)
		{
			System.out.println(bot.getName());
		}		
		
		// Connect to Named Robot - Connection Function Returns Robot Object Named robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		// Wait for 500 Milliseconds
		control.waitTime(500);		
		
		// Create Three Objects of the LightsFlicker Class 
		LightsFlickerClass lights1 = new LightsFlickerClass(robot);
		LightsFlickerClass lights2 = lights1;
		LightsFlickerClass lights3 = new LightsFlickerClass(robot);
		
		// The toString() Method
		System.out.println(lights1.toString());
		// The equals() Method
		System.out.println(lights1.equals(lights2));
		System.out.println(lights1.equals(lights3));
		
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);
	}	
}


/** Abstract Class Lights Class for Storing RGB Data*/
abstract class LightsClass
{
	
	private int rVal = 0;
	private int gVal = 0;
	private int bVal = 100;
	
	/** Default Constructor */
	public LightsClass()
	{
	}

	/** Object Class Method toString() to Print Message About the Class When Called on An Object of the Class Type
	 * @return String with Information about Current RGB Color Values
	 */
	public String toString()
	{
		return "Stored Colors (RGB): " + rVal + ", " + gVal + ", " + bVal;
	}
		
	/** Set Method for Setting the Instance's LED RGB Values
	* @param Integer red color value ranging from 0 to 255
	* @param Integer green color value ranging from 0 to 255
	* @param Integer blue color value ranging from 0 to 255
	*/
	public void setColorVals(int rValSet, int gValSet, int bValSet)
	{
		rVal = rValSet;
		gVal = gValSet;
		bVal = bValSet;
	}
	
	/** Accessor Get Method For Red Color
	* @return the Instance's Integer red color value
	*/
	public int getRVal()
	{
		return rVal;
	}
	
	/** Accessor Get Method For Green Color
	* @return the Instance's Integer green color value
	*/
	public int getGVal()
	{
		return gVal;
	}
	
	/** Accessor Get Method For Blue Color
	* @return the Instance's Integer blue color value
	*/
	public int getBVal()
	{
		return bVal;
	}
	
}

/** Flicker Animation Class that Extends the Lights Class  */
class LightsFlickerClass extends LightsClass
{
	private GroundRobot robotLights;
	private long duration = 1000;
	private int onTime = 500;
	private int offTime = 500;	
	
	/** Constructor That Takes a GroundRobot Object as Input */
	public LightsFlickerClass(GroundRobot robot) {
		robotLights = robot;
	}
	
	/** Flicker Animation Running Method */	
	public void flicker()
	{
		int rFlicker = getRVal();
		int gFlicker = getGVal();
		int bFlicker = getBVal();
		
		for (long stop=System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(duration); stop > System.nanoTime();)
		{

			robotLights.setLights(rFlicker, gFlicker, bFlicker);
			robotLights.syncLights();
			for (long onStart=System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(onTime); onStart > System.nanoTime();)
			{	
			}
			
			robotLights.setLights(0, 0, 0);
			robotLights.syncLights();			
			for (long offStart=System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(offTime); offStart > System.nanoTime();)
			{	
			}
			
		}
	}	

	/** Accessor Set Method For Animation Timing
	* @param Integer "On" Duration Time Value for the Animation
	* @param Integer "Off" Duration Time Value for the Animation
	* @param Integer Total Duration Time Value for the Animation
	*/	
	public void setFlickerTimes(int onTimeSet, int offTimeSet, int durationSet)
	{
		onTime = onTimeSet;
		offTime = offTimeSet;
		duration = durationSet;
	}
}

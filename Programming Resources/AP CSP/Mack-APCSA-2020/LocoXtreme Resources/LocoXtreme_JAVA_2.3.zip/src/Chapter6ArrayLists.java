/** Program Chapter6ArrayLists.java 
 	Example program to show use of ArrayLists in Java   
*/

import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;


/** Public Class Name Matches File Name */
public class Chapter6ArrayLists
{
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{

		// Array List of Ground Robots set as null
		ArrayList<GroundRobot> scannedBots = null;
		
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		scannedBots = control.scan(2000);
		// Check Robot Names
		System.out.print("Robot Names: ");
		// For-Each Loop 
		for (GroundRobot bot : scannedBots)
		{
			System.out.println(bot.getName());
		}
		// Connect to Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();

		// Create an ArrayList of Type String
		ArrayList<String> sensorsTracking  = new ArrayList<String>();
		// Add Three Defined Strings to the ArrayList
		sensorsTracking.add(MessageCodes.D_Accelerometer);
		sensorsTracking.add(MessageCodes.D_GyroscopeRaw);
		sensorsTracking.add(MessageCodes.D_Magnetometer);
		
		// Create Instance of the SensorData Class and Pass a GroundRobot Object and ArrayList of Sensor Names
		SensorData sensorObj = new SensorData(robot, sensorsTracking);
		sensorObj.enableSensors();
		// Wait for 500 Milliseconds
		control.waitTime(500);	
		
		// Run Timed Loop Calling the readSensors Method of the SensorData Class Instance
		System.out.println("Starting Data Read");
		for (long stop=System.nanoTime() + TimeUnit.SECONDS.toNanos(10); stop > System.nanoTime();)
		{
			sensorObj.readSensors();
			control.waitTime(100);
			System.out.println("Accelerometer (g): " + sensorObj.ax + ", " + sensorObj.ay + ", " + sensorObj.az);
			System.out.println("Gyroscope Raw (deg/s): " + sensorObj.gxR + ", " + sensorObj.gyR + ", " + sensorObj.gzR);
			System.out.println("Magnetometer (uT): " + sensorObj.mx + ", " + sensorObj.my + ", " + sensorObj.mz);
		}		
		
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);		
	}
}

/** Sensor Data Class to Enable And Read Sensors Based on an ArrayList */
class SensorData
{
	private GroundRobot sensorRobot;
	private ArrayList<String> sensorsList;
	public double ax, ay, az;
	public double axR, ayR, azR;
	public double gxR, gyR, gzR;
	public double mx, my, mz;
	public double mxR, myR, mzR;
	public double heading;
	public double distance, distanceR;	
	public double temperature;
	
	/** Constructor That Takes As Input a GroundRobot Object and ArrayList of Sensor Name Strings */
	public SensorData(GroundRobot robot, ArrayList<String> sensors)
	{
		sensorRobot = robot;
		sensorsList = sensors;
	}
	
	/** Enables Sensors For the GroundRobot Object Provided Based on the ArrayList of Sensor Names Provided */
	public void enableSensors()
	{
		for (String i : sensorsList)
		{
			sensorRobot.enableSensor(i, 1);
		}
	}
	
	/** Disables a Sensor For the GroundRobot Object
	 * @param Sensor Name String 
	 */
	public void disableSensor(String sensorRemove)
	{
		sensorsList.remove(sensorsList.indexOf(sensorRemove));
	}
	
	/** Iterates Through ArrayList of Sensor Names and Updates Their Data Values */
	public void readSensors()
	{
		for(Iterator<String> it = sensorsList.iterator(); it.hasNext(); )
		{
			switch (it.next())
			{
				case MessageCodes.D_Ultrasonic:
					distance = sensorRobot.getUSDistanceCMFiltered();
				case MessageCodes.D_UltrasonicRaw:
					distanceR = sensorRobot.getUSDistanceCMRaw();
				case MessageCodes.D_Accelerometer:
					ax = sensorRobot.getAccelXFiltered();
					ay = sensorRobot.getAccelYFiltered();
					az = sensorRobot.getAccelZFiltered();
				case MessageCodes.D_AccelerometerRaw:
					axR = sensorRobot.getAccelXRaw();
					ayR = sensorRobot.getAccelYRaw();
					azR = sensorRobot.getAccelZRaw();
				case MessageCodes.D_Magnetometer:
					mx = sensorRobot.getMagnetometerXFiltered();
					my = sensorRobot.getMagnetometerYFiltered();
					mz = sensorRobot.getMagnetometerZFiltered();
				case MessageCodes.D_MagnetometerRaw:
					mxR = sensorRobot.getMagnetometerXRaw();
					myR = sensorRobot.getMagnetometerYRaw();
					mzR = sensorRobot.getMagnetometerZRaw();
				case MessageCodes.D_GyroscopeRaw:
					gxR = sensorRobot.getGyroXRaw();
					gyR = sensorRobot.getGyroXRaw();
					gzR = sensorRobot.getGyroXRaw();						
				case MessageCodes.D_Temperature:
					temperature = sensorRobot.getTempCelsius();
				case MessageCodes.D_Heading:
					heading = sensorRobot.getHeadingDegrees();
			}
		}
	}
}

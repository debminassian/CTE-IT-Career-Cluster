/** Program BuzzerFeedbackLesson.java 
 	Example program to trigger Buzzer sounds as part of triggered events
*/

import java.util.concurrent.TimeUnit;


/** Public Class Name Matches File Name */
public class BuzzerFeedbackLesson
{	
	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		control.scan(2000);
				
		// Connect to Named Robot - Connection Function Returns Robot Object Named Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		robot.enableSensor(MessageCodes.D_Ultrasonic, 1);
		robot.enableSensor(MessageCodes.D_Accelerometer, 1);
		// Wait for 500 Milliseconds
		control.waitTime(500);
		
		// Create an Instance of the BuzzerEvents class
		BuzzerEvents buzzEvents = new BuzzerEvents(robot);
		
		// Run Buzzer Event Timed Loop For 20 Seconds 
		buzzEvents.eventCheck(20);
				
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);	
	}	
}

/** Class to Play Buzzer Notes Upon Defined Accelerometer and Ultrasonic Events */
class BuzzerEvents
{
	private GroundRobot buzzerRobot;
	private int distanceClose = 6;
	private double zEvent = 0.5;
	String buzzerAccNote = MessageCodes.N_C;
	String buzzerDistNote = MessageCodes.N_F; 
	
	/** Constructor with an Input of a GroundRobot Object */
	public BuzzerEvents(GroundRobot robot)
	{
		buzzerRobot = robot;
	}
	
	/** Method to Run for Timed Duration And Trigger Buzzer Events When Applicable 
	 *@param Time Duration in Seconds
	 */
	public void eventCheck(long duration)
	{
		for (long stop=System.nanoTime() + TimeUnit.SECONDS.toNanos(duration); stop > System.nanoTime();)
		{
			checkAccelerometer();
			checkDistance();
			buzzerRobot.waitTime(50);
		}
	}
	
	/** Check Accelerometer's Z-Axis Data with Threshold */
	private void checkAccelerometer()
	{
		double az = buzzerRobot.getAccelZFiltered(); 
		if (az  < zEvent)
		{
			buzzerRobot.setupWait(MessageCodes.W_Song);
			buzzerRobot.playNote(buzzerAccNote, 500, true);
		}
	}
	
	/** Check Ultrasonic Sensor's Data with Threshold */
	private void checkDistance()
	{
		int dist = buzzerRobot.getUSDistanceCMFiltered(); 
		if (dist  < distanceClose)
		{
			buzzerRobot.setupWait(MessageCodes.W_Song);
			buzzerRobot.playNote(buzzerDistNote, 500, true);			
		}
	}
	
	/** Set Method for Z-axis Acceleration Value
	 *@param Z-Axis Threshold Double Value 
	 */
	public void setZLevel(double zLevel)
	{
		zEvent = zLevel;
	}
	
	/** Set Method for Distance Value
	 *@param Distance Threshold Integer Value 
	 */
	public void setDistanceClose(int closeLevel)
	{
		distanceClose = closeLevel;
	}
	
	/** Set Method for Buzzer Note to Play Upon Accelerometer Event
	 *@param String of a Buzzer Note
	 */
	public void setBuzzerAcc(String noteToPlay)
	{
		buzzerAccNote = noteToPlay;
	}
	
	/** Set Method for Buzzer Note to Play Upon Ultrasonic Sensor Event 
	 *@param String of a Buzzer Note  
	 */
	public void setBuzzerDist(String noteToPlay)
	{
		buzzerDistNote = noteToPlay;
	}
	
}
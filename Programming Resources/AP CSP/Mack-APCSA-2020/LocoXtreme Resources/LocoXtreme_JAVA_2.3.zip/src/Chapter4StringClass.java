/** Program Chapter4StringClass.java 
 	Example program to show use of the String Class in Java   
*/

import java.util.ArrayList;


/** Public Class Name Matches File Name */
public class Chapter4StringClass
{
		
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		
		// Array List of Ground Robots set as null
		ArrayList<GroundRobot> scannedBots = null;
		
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		scannedBots = control.scan(2000);
		// Check Robot Names
		System.out.print("Robot Names: ");
		// For-Each Loop 
		for (GroundRobot bot : scannedBots)
		{
			System.out.println(bot.getName());
		}
		
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		// Wait for 500 Milliseconds
		control.waitTime(500);		
		
		// Get Robot Name String and MAC Address String
		String robotName = robot.getName();
		String robotMacAddress = robot.getMacAddress();
		
		// Print Robot Information And Compare Strings to USB_PORT_ADDRESS String
		System.out.print("The connected Robot's name is: " + robotName + ". ");
		System.out.println("And its MAC Address is: " + robotMacAddress + ".");
		System.out.println(USB_PORT_ADDRESS.equals(robotName));
		System.out.println(USB_PORT_ADDRESS.equals(robotMacAddress));
		
		// Use substring() and indexOf String Class methods on the Robot Name String
		System.out.println("The first character in the Robot's name is: " + robotName.substring(0, 1));
		System.out.println("Does the Robot Name Contain a 1? " + robotName.indexOf("1"));
				
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);		
	}	
}

/** Program Chapter3Inheritance.java 
 	Example program to show use of Super and Subclasses in Java   
*/
import java.util.ArrayList;

/** Public Class Name Matches File Name */
public class Chapter3Inheritance
{
	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Array List of Ground Robots set as null
		ArrayList<GroundRobot> scannedBots = null;
		
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		scannedBots = control.scan(2000);
		// Check Robot Names
		System.out.print("Robot Names: ");
		// For-Each Loop 
		for (GroundRobot bot : scannedBots)
		{
			System.out.println(bot.getName());
		}		
		
		// Connect to Named Robot - Connection Function Returns Robot Object Named robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		// Wait for 500 Milliseconds
		control.waitTime(500);
		
		// Create Instance of the DriveDistance Class as the Object driveDistObj
		DriveDistance driveDistObj = new DriveDistance(robot);
		// Create Instance of the DriveDistanceLights Subclass as the Object driveDistLightsObj		
		DriveDistanceLights driveDistLightsObj = new DriveDistanceLights(robot);
		
		// Call the driveDistance Method from Object driveDistObj with Input Parameters
		driveDistObj.driveDistance(MessageCodes.MD_Forward, 5, 0.5f);
		
		// Wait for 1000 Milliseconds
		control.waitTime(1000);

		// Call the setlightsColor Method from Object driveDistLightsObj with RGB LED Colors
		driveDistLightsObj.setlightsColor(0, 100, 100);
		// Call the driveDistance Method from Object driveDistLightsObj with Input Parameters
		driveDistLightsObj.driveDistance(MessageCodes.MD_Forward, 5, 0.5f);
	
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);			
		
	}
	
}

/** Superclass DriveDistance */
class DriveDistance
{
	protected GroundRobot driveRobot;
	/** Constructor with Input of GroundRobot Object */
	public DriveDistance(GroundRobot robot)
	{
		driveRobot = robot;
	}
	
	/** Instructs Robot to Drive for a Specified Distance
	* @param Motor Direction String
	* @param Integer distance value in centimeters
	* @param Float motor speed value ranging from 0 to 1
	*/
	public void driveDistance(String direction, int distance, float speed)
	{
		driveRobot.setupWait(MessageCodes.W_Distance, (distance * 1000));
		driveRobot.move(direction, direction, speed, speed, true, true);
	}
}

/** Subclass DriveDistanceLights of the Superclass DriveDistance */
class DriveDistanceLights extends DriveDistance
{
	private int lightsR = 0;
	private int lightsG = 100;
	private int lightsB = 100;

	public DriveDistanceLights(GroundRobot robot) {
		super(robot);
	}
	
	/** Set Method for Setting the Instance's LED RGB Values
	* @param Integer red color value ranging from 0 to 255
	* @param Integer green color value ranging from 0 to 255
	* @param Integer blue color value ranging from 0 to 255
	*/
	public void setlightsColor(int rValue, int gValue, int bValue)
	{
		rValue = lightsR;
		gValue = lightsG;
		bValue = lightsB;
	}
	/** Instructs Robot to Drive for a Specified Distance and Sets LEDs Upon Completion
	* @param Motor Direction String
	* @param Integer distance value in centimeters
	* @param Float motor speed value ranging from 0 to 1
	*/
	public void driveDistance(String direction, int distance, float speed)
	{
		driveRobot.setupWait(MessageCodes.W_Distance, (distance * 1000));
		driveRobot.move(direction, direction, speed, speed, true, true);
		driveRobot.setLights(lightsR, lightsG, lightsB);
		driveRobot.syncLights();
		driveRobot.waitTime(500);
	}	
}


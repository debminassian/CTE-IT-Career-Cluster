/** Program Chapter1InputOutput_Structures.java 
 	Example program to show expanded use System Output, Decision Making, and Iterative Control Structures
*/

//Import a Packages
import java.util.concurrent.TimeUnit;
import java.util.ArrayList;

/** Public Class Name Matches File Name */
public class Chapter1Output_Structures
{
	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Array List of Ground Robots set as null
		ArrayList<GroundRobot> scannedBots = null;
		
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		scannedBots = control.scan(2000);
		// Check Robot Names
		System.out.print("Robot Names: ");
		// For-Each Loop To Print the Names of Any Detected Robots
		for (GroundRobot bot : scannedBots)
		{
			System.out.println(bot.getName());
		}		
		
		// Connect to Named Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		robot.enableSensor(MessageCodes.D_Accelerometer, 1);
		// Wait for 500 Milliseconds
		control.waitTime(500);
		
		// Output of a String Including a Variable and Escape Sequence - A Backslash Followed by a Single Character, in This Case \n for Creation of a NewLine
		float accMagThreshold = 1.5f;
		System.out.print("Shake Robot for an Acceleration Magnitude Above " + accMagThreshold + " g Within 5 Seconds \n");
		
		// Read Accelerometer Data and Calculate and Print the Acceleration Magnitude
		double ax = robot.getAccelXFiltered();
		double ay = robot.getAccelYFiltered();
		double az = robot.getAccelZFiltered();
		double accMag = Chapter1Output_Structures.computeAccMag(ax, ay, az);
		System.out.println("Current Acceleration Magnitude: " + accMag + " g");
		boolean didShake = false;

		// For Loop To Run For Timed Duration
		for (long stop=System.nanoTime() + TimeUnit.SECONDS.toNanos(5); stop > System.nanoTime();) 
		{
			// Update Accelerometer Data
			ax = robot.getAccelXFiltered();
			ay = robot.getAccelYFiltered();
			az = robot.getAccelZFiltered();
			accMag = Chapter1Output_Structures.computeAccMag(ax, ay, az);
			control.waitTime(50);
			// If-Statement to Check on Accelerometer Magnitude Value With Respect to the Defined Threshold Value
			if (accMag > accMagThreshold)
			{
				didShake = true;
				System.out.println("Shake Magnitude: " + accMag + " g");
				break;
			}
		}	
		
		// Nested If Statement with Extended If Statement Logic 
		if (didShake == true)
		{
			// Compare Last Magnitude Value with A Multiple of the Threshold
			if (accMag > (accMagThreshold * 1.2))
			{
				// Iterative For Loop To Set Each LED a Different Color
				for (int i = 0; i < 8; i++)
				{
					robot.setLight(i, i*2, i*8, i*20);
				}
			}
			// Compare Last Magnitude Value with A Multiple of the Threshold			
			else if (accMag > (accMagThreshold * 1.1))
			{
				// Set All the LEDs to the Same Color
				robot.setLights(0, 100, 100);
			}
			// Else Case for Comparisons of Last Magnitude Value with A Multiple of the Threshold
			else
			{
				// Set All the LEDs to the Same Color
				robot.setLights(0, 50, 100);
			}
		}
		else
		{
			// Set All the LEDs to the Same Color
			robot.setLights(100, 10, 10);
		}
		// Update the LED Ring and Wait for 5 Seconds
		robot.syncLights();
		control.waitTime(5000);
		
		// Deactivate the Motors and Disconnect from the Robot
		robot.deactivateMotors();
		control.disconnect(robot);
	}
	
	/** Computes the Acceleration Magnitude from 3 Acceleration Axes Data Values
	* @param a Double of the X-Axis Acceleration Reading
	* @param a Double of the Y-Axis Acceleration Reading
	* @param a Double of the Z-Axis Acceleration Reading
	* @return the Acceleration Magnitude
	*/	
	public static double computeAccMag(double ax, double ay, double az)
	{
		return Math.sqrt(ax*ax + ay*ay + az*az);
	}	
	
}
/** Program FindClosestLesson.java 
 	Example program to rotate in a circle while measuring distance data
*/

/** Public Class Name Matches File Name */
public class FindClosestLesson
{	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		control.scan(2000);
				
		// Connect to Named Robot - Connection Function Returns Robot Object Named Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		robot.enableSensor(MessageCodes.D_Ultrasonic, 1);
		// Wait for 500 Milliseconds
		control.waitTime(500);
		
		// Create Empty Data Array
		int[] distanceArray;
		
		// Create Instance of the CircleSweep Class and Get Number of Steps
		CircleSweep circSweep = new CircleSweep(robot);
		int angleStep = circSweep.getAngleStep();
		int angleSize = circSweep.getAngleLimit();
		int steps = angleSize / angleStep + 1;
		distanceArray = new int[steps];
		
		// Collect Data
		distanceArray = circSweep.distanceSweep();
		
		// Find Farthest Distance Measured
		int maxDistance = distanceArray[0];
		for (int u = 1; u < steps; u++)
		{
			int currentDistance = distanceArray[u]; 
			if (currentDistance > maxDistance)
			{
				maxDistance = currentDistance;
			}			
		}
		System.out.println("Maximum Distance Found (Centimeters): " + maxDistance);
		
		// Find Closest Distance Measured
		int minDistance = distanceArray[0];
		for (int u = 1; u < steps; u++)
		{
			int currentDistance = distanceArray[u]; 
			if (currentDistance < minDistance)
			{
				minDistance = currentDistance;
			}			
		}
		System.out.println("Minimum Distance Found (Centimeters): " + minDistance);
		
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);
	}
}


/** Class For Controlling the Robot to Conduct a Circular Distance Measurement Sweep */
class CircleSweep
{
	
	private GroundRobot circleRobot;
	private int angleStep = 10;
	private int angleLimit = 360;
		
	/** Constructor Takes as Input a GroundRobot Object
	 *@param GroundRobot Object
	 */
	public CircleSweep(GroundRobot robot)
	{
		circleRobot = robot;	
	}
	
	/** Get Method for the GroundRobot Object Instance
	 *@return GroundRobot Object Instance
	 */
	public GroundRobot getRobot()
	{
		return circleRobot;
	}	
	
	/** Get Method for the Angle Step Size Value (Degrees)
	 *@return Angle Limit Integer in Degrees
	 */
	public int getAngleStep()
	{
		return angleStep;
	}
	
	/** Get Method for the Angle Limit Value (Degrees) */
	public int getAngleLimit()
	{
		return angleLimit; 	
	}
	
	/** Set Method for Setting the Angle Step Size (Degrees) 
	 *@param Angle Step Size Integer in Degrees 
	 */
	public void setAngleStep(int angleStepVal)
	{
		angleStep = angleStepVal;
	}
	
	/** Set Method for Setting the Angle Limit (Degrees) 
	 *@param Angle Limit Integer in Degrees 
	 */
	public void setAngleLimit(int angleLim)
	{
		angleLimit = angleLim; 	
	}	
	
	
	/** Controls Robot to Incrementally Rotate and Take Sample Distance Readings 
	 *@return Data Array for Storing Read Distance Values (Centimeters)  
	 */
	public int[] distanceSweep()
	{
		int[] distanceArray = new int[(angleLimit / angleStep) + 1];
		
		for (int k = 0; k <= angleLimit; k += angleStep)
		{
			// 
			distanceArray[k / angleStep] = circleRobot.getUSDistanceCMFiltered();
			// 
			circleRobot.setupWait(MessageCodes.W_Rotation, angleStep * 1000);
			circleRobot.move(MessageCodes.MD_Forward, MessageCodes.MD_Backward, 0.5f, 0.5f, true, true);
		}
		return distanceArray;
	}
}
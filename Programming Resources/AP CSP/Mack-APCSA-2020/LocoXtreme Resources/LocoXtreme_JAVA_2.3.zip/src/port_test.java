
import java.util.ArrayList;
import com.fazecast.jSerialComm.SerialPort;

// Public Class Name Matches File Name
public class port_test 
{

	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{		
		SerialPort[] comArr = SerialPort.getCommPorts();
		for (int i = 0; i < comArr.length; i++) {
		  System.out.println(comArr[i].getSystemPortName());
		}		
	}
}
/** Program TemperatureGridLesson.java 
 	Example program to drive in a grid while collecting temperature data
*/

/** Public Class Name Matches File Name */
public class TemperatureGridLesson
{	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		control.scan(2000);	
		
		// Connect to Named Robot - Connection Function Returns Robot Object Named Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		robot.enableSensor(MessageCodes.D_Temperature, 1);
		// Wait for 500 Milliseconds
		control.waitTime(500);
		
		// Specify Number of Rows and Columns in the Grid and Create GridDriveTemperature Instance
		int rowCount = 3;
		int colCount = 3;
		GridDriveTemperature gridDriveTemp = new GridDriveTemperature(robot, rowCount, colCount);
		
		// Set Distance (Centimeters) for the Spacing Between Grid Points In Each Column and Between Columns
		gridDriveTemp.setRowDistance(4);
		gridDriveTemp.setColDistance(4);
		
		// Run the Grid and Gather Temperature Data
		gridDriveTemp.runGridTemp();
		
		// Read Back the Data and Print It to the Console
		double[][] tempData = new double[rowCount][colCount];
		for (int i = 0; i < rowCount; i++)
		{
			for (int k = 0; k < colCount; k++)
			{
				tempData[i][k] = gridDriveTemp.getDataValue(i, k);
				System.out.println(tempData[i][k] + "C");
			}
		}
		
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);
	}
}

/** Class for Driving in a Grid and Collecting Temperature Data */
class GridDriveTemperature
{
	private GroundRobot gridRobot;
	private int gridRows;
	private int gridCols;
	private int rowDist = 5;
	private int colDist = 5;
	private double[][] dataArray;
	
	/** Constructor That Takes in a GroundRobot Object, A Rows Count and a Columns Count */
	public GridDriveTemperature(GroundRobot robot, int rows, int columns)
	{
		gridRobot = robot;
		gridRows = rows;
		gridCols = columns;
		dataArray = new double[gridRows][gridCols];
	}	
	
	/**
	 *  @param Integer of the Distance Between Each Row Point in Centimeters
	 */
	public void setRowDistance(int rowDistSet)
	{
		rowDist = rowDistSet;
	}
	
	/**
	 *  @param Integer of the Distance Between Each Column in Centimeters
	 */
	public void setColDistance(int colDistSet)
	{
		colDist = colDistSet;
	}
	
	/**
	 *  @param Row Index in the Data Array
	 *  @param Column Index in the Data Array
	 *  @return Temperature Value From Data Array at the Input Indices
	 */
	public double getDataValue(int row, int col)
	{
		return dataArray[row][col];
	}
	
	/** Run Through the Grid of Positions */
	public void runGridTemp()
	{
		int rowIndx = 0;
		int colIndx = 0;
		float turnSpeed = 0.3f;
		float driveSpeed = 0.5f;
		
		for (int j = 0; j < gridCols; j++)
		{
			colIndx = j;
			// Drive A Column Depth
			for (int i = 0; i < gridRows; i++)
			{
				rowIndx = i;
				double temperature = gridRobot.getTempCelsius();
				dataArray[rowIndx][colIndx] = temperature;	
				gridRobot.setupWait(MessageCodes.W_Distance, (rowDist * 1000));
				gridRobot.move(MessageCodes.MD_Forward, MessageCodes.MD_Forward, driveSpeed, driveSpeed, true, true);
			}
			
			// Check For Direction to Turn
			boolean turnRight;
			if (j % 2 == 0) {
				turnRight = true;
			}
			else {
				turnRight = false;
			}
			
			
			// Rotate
			gridRobot.setupWait(MessageCodes.W_Rotation, (90000));
			if (turnRight == true) {
				gridRobot.move(MessageCodes.MD_Forward, MessageCodes.MD_Backward, turnSpeed, turnSpeed, true, true);
			}
			else {
				gridRobot.move(MessageCodes.MD_Backward, MessageCodes.MD_Forward, turnSpeed, turnSpeed, true, true);
			}
			
			// Drive to Next Column
			gridRobot.setupWait(MessageCodes.W_Distance, (colDist * 1000));
			gridRobot.move(MessageCodes.MD_Forward, MessageCodes.MD_Forward, driveSpeed, driveSpeed, true, true);
			
			// Rotate
			gridRobot.setupWait(MessageCodes.W_Rotation, (90000));
			if (turnRight == true) {
				gridRobot.move(MessageCodes.MD_Forward, MessageCodes.MD_Backward, turnSpeed, turnSpeed, true, true);
			}
			else {
				gridRobot.move(MessageCodes.MD_Backward, MessageCodes.MD_Forward, turnSpeed, turnSpeed, true, true);
			}
			
		}
	}

}

/** Program FlipDetectionLesson.java 
 	Example program to Detect When the Robot has Flipped
*/

import java.util.concurrent.TimeUnit;


/** Public Class Name Matches File Name */
public class FlipDetectionLesson
{	
	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		control.scan(2000);
				
		// Connect to Named Robot - Connection Function Returns Robot Object Named Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		robot.enableSensor(MessageCodes.D_Accelerometer, 1);
		// Wait for 500 Milliseconds
		control.waitTime(500);
		
		// Create an Instance of the FlipDetect class
		FlipDetect flipCheck = new FlipDetect(robot);
		
		// Drive for a Time While Checking for a Flipped State
		robot.move(MessageCodes.MD_Forward, MessageCodes.MD_Forward, 0.5f, 0.5f, false, true);
		for (long stop=System.nanoTime() + TimeUnit.SECONDS.toNanos(10); stop > System.nanoTime();)
		{
			boolean flipState = flipCheck.isFlipped();
			if (flipState == true)
			{
				break;
			}
			robot.waitTime(50);
		}
		robot.move(MessageCodes.MD_Forward, MessageCodes.MD_Forward, 0.0f, 0.0f, false, true);
				
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);	
	}	
}

/** Robot Flipped Checking Class */
class FlipDetect
{
	private GroundRobot flipRobot;
	
	/** Constructor with an Input of a GroundRobot Object */
	public FlipDetect(GroundRobot robot)
	{
		flipRobot = robot;
	}
	
	/** Checks Robot for Flipped State
	 *@return Boolean Value of Flipped State 
	 */
	public boolean isFlipped()
	{
		double az = flipRobot.getAccelZFiltered();
		
		if (az < 0)
		{
			return true;
		}
		else
		{
			return false;
		}		
	}
}
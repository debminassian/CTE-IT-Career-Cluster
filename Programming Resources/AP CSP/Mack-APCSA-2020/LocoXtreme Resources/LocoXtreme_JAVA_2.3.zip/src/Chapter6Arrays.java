/** Program Chapter6Arrays.java 
 	Example program to show use of Arrays in Java   
*/

import java.util.ArrayList;


// Public Class Name Matches File Name
public class Chapter6Arrays
{
	
	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{

		// Array List of Ground Robots set as null
		ArrayList<GroundRobot> scannedBots = null;
		
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr 67:64";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		scannedBots = control.scan(2000);
		// Check Robot Names
		System.out.print("Robot Names: ");
		// For-Each Loop 
		for (GroundRobot bot : scannedBots)
		{
			System.out.println(bot.getName());
		}
		
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		robot.enableSensor(MessageCodes.D_Ultrasonic, 1);
		robot.enableSensor(MessageCodes.D_UltrasonicRaw, 1);
		// Wait for 500 Milliseconds
		control.waitTime(500);	
		
		// Create Distance Thresholds in Centimeters
		int thresholdVal = 20;
		int arraySize = 25;
		// Create Arrays
		int[] data = new int[arraySize], dataRaw = new int[arraySize];
		
		// Populate Arrays With a For Loop and Time Delays
		for (int i = 0; i < data.length; i++)
		{
			int distance = robot.getUSDistanceCMFiltered();
			int distanceRaw = robot.getUSDistanceCMRaw();
			data[i] = distance;
			dataRaw[i] = distanceRaw;
			// If the Filtered Data is Less Than the Threshold, Zero It 
			if (data[i] < thresholdVal)
			{
				data[i] = 0;
			}
			// If the Raw Data is Less Than the Threshold, Zero It			
			if (dataRaw[i] < thresholdVal)
			{
				dataRaw[i] = 0;
			}				
			// Wait for 100 Milliseconds
			control.waitTime(100);
		}
		
		// Traverse Arrays To Check If Passed Threshold
		boolean dataPassedFlag = passedThreshold(data, thresholdVal);
		boolean dataRawPassedFlag = passedThreshold(dataRaw, thresholdVal);
		// Print Result Flags
		System.out.println("Filtered Data Passed Threshold: " + dataPassedFlag);
		System.out.println("Raw Data Passed Threshold: " + dataRawPassedFlag);
				
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);		
	}
	
	/** Method to Compare Array of Data To a Threshold Value 
	 * @param Integer Array of Data Values
	 * @param Integer Value of Threshold
	 * @return Returns Whether Or Not Any Distance Value In Array Was Above the Provided Threshold Value 
	 */
	static boolean passedThreshold(int[] dataVals, int threshold)
	{
		boolean passedThresh = false;
		for (int i : dataVals)
		{
			if (i > threshold)
			{
				passedThresh = true;
			}	
		}
		return passedThresh;
	}
	
}
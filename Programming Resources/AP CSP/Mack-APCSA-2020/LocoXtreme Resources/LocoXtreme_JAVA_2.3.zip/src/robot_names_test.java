
import java.util.ArrayList;

// Public Class Name Matches File Name
public class robot_names_test 
{
	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{		
		// Array List of Ground Robots Set as null
		ArrayList<GroundRobot> scannedBots = null;
		
		final String USB_ADDRESS = "COM5"; //"cu.usbmodem1";

		RobotControl control = new RobotControl();
		
		// Connect to Dongle
		control.setup(USB_ADDRESS);
				
		// Scan for Robots for 2000 Milliseconds
		scannedBots = control.scan(2000);
		// Check Robot Names
		System.out.print("Robot Names: ");
		for (GroundRobot bot : scannedBots)
		{
			System.out.println(bot.getName());
		}		
	}
}
/** Program AccelerometerCalibration.java 
 	Example program to calibrate the robot's accelerometer sensor
*/

import java.util.Scanner;
import java.util.concurrent.TimeUnit;

/** Public Class Name Matches File Name */
public class AccelerometerCalibration
{	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		control.scan(2000);	
		
		// Connect to Named Robot - Connection Function Returns Robot Object Named Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		robot.enableSensor(MessageCodes.D_Accelerometer, 1);
		// Wait for 500 Milliseconds
		control.waitTime(500);
		
		// Create an Instance of the Accelerometer Calibration class
		AccelerometerCalibrate accCalibrate = new AccelerometerCalibrate(robot);

		// Run the Accelerometer Calibration Method
		accCalibrate.calibrateAccelerometer();
		
		// Loop For a Time And Print Calibrated Accelerometer Data
		for (long stop=System.nanoTime() + TimeUnit.SECONDS.toNanos(10); stop > System.nanoTime();)
		{
			double[] dataArray = accCalibrate.getCalibratedAcc();
			System.out.println("Calibrated Accelerometer Data (g); " + dataArray[0] + ", " + dataArray[1] + ", " + dataArray[2]);
			robot.waitTime(200);
		}
		
		
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);
	}
}

/** Class for Simple Accelerometer Calibration */
class AccelerometerCalibrate
{
	private GroundRobot accRobot;
	private double accOffX = 0;
	private double accOffY = 0;
	private double accOffZ = 0;
	private double accSFX = 1.0;
	private double accSFY = 1.0;
	private double accSFZ = 1.0;
	
	private int avgCounts = 10;
	
	/** Constructor Takes a GroundRobot Instance As Input */
	public AccelerometerCalibrate(GroundRobot robot)
	{
		accRobot = robot;
	}
	
	/** Method Using User Input And Accelerometer Data to Calculate Accelerometer Error */
	public void calibrateAccelerometer()
	{
		// Initialize Data Arrays
		double[] zpXYZ = new double[3];		
		double[] xpXYZ = new double[3];		
		double[] ypXYZ = new double[3];		
		
		// Scan for User Input
		Scanner reader = new Scanner(System.in);  // Reading from System.in
		System.out.println("Place the LocoXtreme with Treads Facing Down On a Flat Surface, Then Press Enter: ");
		reader.nextLine();
		zpXYZ = getAvgAcc();

		// Scan for User Input
		System.out.println("Hold the LocoXtreme Still With Ultrasonic Sensor Facing Upwards, Then Press Enter: ");
		reader.nextLine();
		xpXYZ = getAvgAcc();

		// Scan for User Input
		System.out.println("Hold the LocoXtreme Still With the Left Tread Facing Upwards, Then Press Enter: ");
		reader.nextLine();
		ypXYZ = getAvgAcc();

		// Close Scanner
		reader.close();
		
		// Calculate Offsets
		accOffX = (xpXYZ[1] + xpXYZ[2]) / 2.0;
		accOffY = (ypXYZ[0] + ypXYZ[2]) / 2.0;
		accOffZ = (zpXYZ[0] + zpXYZ[1]) / 2.0;
		
		// Calculate Scale Factors
		accSFX = xpXYZ[0] - accOffX;
		accSFY = ypXYZ[1] - accOffY;
		accSFZ = zpXYZ[2] - accOffZ;
	}
	
	/** Method to Calculate An Average Accelerometer Reading Over a Series of Data Samples */
	private double[] getAvgAcc()
	{
		double[] accData = new double[3];
		double avgX = 0;
		double avgY = 0;
		double avgZ = 0;
		// Loop For a Number Of Samples And Average the Data
		for (int i = 0; i < avgCounts; i++)
		{
			avgX += accRobot.getAccelXFiltered();
			avgY += accRobot.getAccelYFiltered();
			avgZ += accRobot.getAccelZFiltered();
			accRobot.waitTime(50);
		}
		accData[0] = avgX / avgCounts;
		accData[1] = avgY / avgCounts;
		accData[2] = avgZ / avgCounts;
		return accData;
	}
	
	/** Request Accelerometer Data With Calibration Applied */
	public double[] getCalibratedAcc()
	{
		// Read Data And Apply Calibration
		double[] accData = new double[3];		
		accData[0] = (accRobot.getAccelXFiltered() - accOffX) / accSFX;
		accData[1] = (accRobot.getAccelYFiltered() - accOffY) / accSFY;
		accData[2] = (accRobot.getAccelZFiltered() - accOffZ) / accSFZ;		
		return accData;
	}
}


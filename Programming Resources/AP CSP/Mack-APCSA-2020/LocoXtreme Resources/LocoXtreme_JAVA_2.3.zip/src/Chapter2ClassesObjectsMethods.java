/** Program Chapter2ClassesObjectsMethods.java 
 	Example program to show creation of objects, classes, and methods
*/
import java.util.ArrayList;

/** Public Class Name Matches File Name */
public class Chapter2ClassesObjectsMethods
{
	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Array List of Ground Robots set as null
		ArrayList<GroundRobot> scannedBots = null;
		
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		scannedBots = control.scan(2000);
		// Check Robot Names
		System.out.print("Robot Names: ");
		// For-Each Loop 
		for (GroundRobot bot : scannedBots)
		{
			System.out.println(bot.getName());
		}		
		
		// Connect to Named Robot - Connection Function Returns Robot Object Named Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		// Wait for 500 Milliseconds
		control.waitTime(500);
		
		// Make Class Object
		DriveShape shape = new DriveShape(robot, 0.5f);
		
		// driveShape(Shape, Distance Per Side, Turn Direction) 
		shape.driveShape(shape.DRAW_TRIANGLE, 5, MessageCodes.M_Right);
		
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);
	}
}

/** Class for Defined Shape-Path Following */
class DriveShape
{	
	// Static: Memory Allocation Happens Once
	// Private: Only this Class can see it
	private GroundRobot driveRobot;
	private float driveSpeed;
	
	final public int DRAW_TRIANGLE = 0;
	final public int DRAW_SQUARE = 1;
	final public int DRAW_PENTAGON = 2;
	final public int DRAW_HEXAGON = 3;
	final public int DRAW_OCTAGON = 4;
	private int[] angles = {120, 90, 72, 60, 45};
	private int[] loopIter = {3, 4, 5, 6, 8};
	
	/** Constructor, Takes GroundRobot Object as Input */
	public DriveShape(GroundRobot robot)
	{
		// Set Default Drive Speed
		driveSpeed = 0.25f;
		
		// Set locoRobot Object as Constructor Input GroundRobot Object
		driveRobot = robot;		
	}
	
	/** Constructor, Takes GroundRobot Object as Input and a Float "speed" value */
	public DriveShape(GroundRobot robot, float speed)
	{
		// Bound Speed Between 0 and 1
		driveSpeed = Math.min(1, Math.max(speed, 0));
		
		// Set locoRobot Object as Constructor Input GroundRobot Object
		driveRobot = robot;		
	}
	
	/** Accessor Get Method For Speed Value
	* @return the driveSpeed value stored in the current Instance of the DriveShape class
	*/	
	public float getDriveSpeed()
	{
		return driveSpeed;
	}
	/** Accessor Set Method For Speed Value
	* @param takes as input a speed value to be set as the driveSpeed value stored in the current Instance of the DriveShape class
	*/	
	public void setDriveSpeed(float newSpeed)
	{
		driveSpeed = Math.min(1, Math.max(newSpeed, 0));
	}
	
	/** Method for Commanding Robot to Drive in an Equilateral Triangle
	* @param an Integer value which references which shape for the Robot to drive
	* @param an Integer value for the distance in centimeters of each side of the shape
	* @param an String to dictate if the Robot turns left or right when rotating
	*/
	public void driveShape(int shape, int sideDistance, String turnDirection)
	{		
		for (int i = 0; i < loopIter[shape]; i++)
		{	
			// Drive Side
			driveRobot.setupWait(MessageCodes.W_Distance, (sideDistance * 1000));
			driveRobot.move(MessageCodes.MD_Forward, MessageCodes.MD_Forward, driveSpeed, driveSpeed, true, true);
			
			// Drive Turn	
			if (turnDirection.equals(MessageCodes.M_Right))
			{
				try {
					driveRobot.setupWait(MessageCodes.W_Rotation, (angles[shape] * 1000));
				}
				catch (ArrayIndexOutOfBoundsException E) {E.printStackTrace();}	
				driveRobot.move(MessageCodes.MD_Forward, MessageCodes.MD_Backward, driveSpeed, driveSpeed, true, true);
			}
			else
			{
				try {
					driveRobot.setupWait(MessageCodes.W_Rotation, (angles[shape] * 1000));
				}
				catch (ArrayIndexOutOfBoundsException E) {E.printStackTrace();}
				driveRobot.move(MessageCodes.MD_Backward, MessageCodes.MD_Forward, driveSpeed, driveSpeed, true, true);
			}
		}
	}
}


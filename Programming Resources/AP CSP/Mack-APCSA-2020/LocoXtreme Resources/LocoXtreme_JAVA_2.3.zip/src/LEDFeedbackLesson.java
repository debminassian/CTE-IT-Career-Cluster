/** Program LEDFeedbackLesson.java 
 	Example program to change LED Behavior Based on Sensor Data
*/

import java.util.concurrent.TimeUnit;


/** Public Class Name Matches File Name */
public class LEDFeedbackLesson
{	
	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		control.scan(2000);
				
		// Connect to Named Robot - Connection Function Returns Robot Object Named Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		robot.enableSensor(MessageCodes.D_Ultrasonic, 1);
		// Wait for 500 Milliseconds
		control.waitTime(500);
		
		// Create an Instance of the LEDDistanceMeter class
		LEDDistanceMeter distMeter = new LEDDistanceMeter(robot);
		
		// Run a Timed Loop For the Distance Meter Ring Behavior
		for (long stop=System.nanoTime() + TimeUnit.SECONDS.toNanos(10); stop > System.nanoTime();)
		{
			distMeter.distanceMeterRing();
			robot.waitTime(50);
		}
		
		// Run a Timed Loop For the Distance Meter Bright Behavior	
		for (long stop=System.nanoTime() + TimeUnit.SECONDS.toNanos(10); stop > System.nanoTime();)
		{
			distMeter.distanceMeterBright();
			robot.waitTime(50);
		}		
		
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);	
	}	
}

/** Class Containing Methods to Set LED Ring in Different Patterns Based on Distance Readings */
class LEDDistanceMeter
{
	private GroundRobot meterRobot;
	private int rVal = 0;
	private int gVal = 0;
	private int bVal = 150;
	
	/** Constructor with an Input of a GroundRobot Object */
	public LEDDistanceMeter(GroundRobot robot)
	{
		meterRobot = robot;
	}
	
	/** Set Which LEDs Are Lit in the Ring Based on the Detected Distance */
	public void distanceMeterRing()
	{
		int distance = meterRobot.getUSDistanceCMFiltered();
		int ledCount = mapRange(distance, 0, 50, 0, 8);
		
		for (int y = 0; y < ledCount; y++)
		{
			meterRobot.setLight(y, rVal, gVal, bVal);
		}
		for (int k = ledCount; k < 8; k++)
		{
			meterRobot.setLight(k, 0, 0, 0);
		}
		
		meterRobot.syncLights();
	}

	/** Set the Brightness of the LEDs Based on the Detected Distance */
	public void distanceMeterBright()
	{
		float lim = 255.0f;
		float distance = meterRobot.getUSDistanceCMFiltered();
		int scaledR = (int)((distance / lim) *(float)(rVal)); 
		int scaledG = (int)((distance / lim) *(float)(gVal));
		int scaledB = (int)((distance / lim) *(float)(bVal));
		
		meterRobot.setLights(scaledR, scaledG, scaledB);
		meterRobot.syncLights();
	}	
	
	/** Set Method for Setting the Instance's LED RGB Values
	* @param Integer red color value ranging from 0 to 255
	* @param Integer green color value ranging from 0 to 255
	* @param Integer blue color value ranging from 0 to 255
	*/
	public void setColorVals(int rValSet, int gValSet, int bValSet)
	{
		rVal = rValSet;
		gVal = gValSet;
		bVal = bValSet;
	}
	
	/** Linear Integer Mapping from an Input Range to an Output Range
	 *@param Input value
	 *@param Input range minimum value
	 *@param Input range maximum value
	 *@param Output range minimum value
	 *@param Output range maximum value
	 *@return Mapped Output Integer value
	 */
	public int mapRange(int in, int inMin, int inMax, int outMin, int outMax)
	{
		return (in - inMin) * (outMax - outMin) / (inMax - inMin) + outMin;		
	}
	
}
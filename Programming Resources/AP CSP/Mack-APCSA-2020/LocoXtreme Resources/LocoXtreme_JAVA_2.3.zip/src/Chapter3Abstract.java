/** Program Chapter3Abstract.java 
 	Example program to show use of Abstract Classes in Java   
*/

//Import a Time Package
import java.util.concurrent.TimeUnit;

import java.util.ArrayList;

/** Public Class Name Matches File Name */
public class Chapter3Abstract
{
	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Array List of Ground Robots set as null
		ArrayList<GroundRobot> scannedBots = null;
		
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		scannedBots = control.scan(2000);
		// Check Robot Names
		System.out.print("Robot Names: ");
		// For-Each Loop 
		for (GroundRobot bot : scannedBots)
		{
			System.out.println(bot.getName());
		}		
		
		// Connect to Named Robot - Connection Function Returns Robot Object Named robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		// Wait for 500 Milliseconds
		control.waitTime(500);
		
		// Create Instances of the LightFlicker class and LightsBreathe class
		LightsFlicker flickerObj = new LightsFlicker(robot);
		LightsBreathe breatheObj = new LightsBreathe(robot);
		
		// Change the flickerObj Instance's LED Color Values Using the Set Method setColorVals
		flickerObj.setColorVals(100, 20, 150);
		// Change the flickerObj Instance's Animation Time Values Using the Set Method setFlickerTimes
		flickerObj.setFlickerTimes(500, 500, 3000);
		// Run The Flicker LEDs Animation
		flickerObj.animate();
			
		// Change the breatheObj Instance's LED Color Values Using the Set Method setColorVals
		breatheObj.setColorVals(10, 220, 100);
		// Run The Breathe LEDs Animation
		breatheObj.animate();
		
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);
	}
	
}

/** Abstract Class Lights that Holds RGB Color Values */
abstract class Lights
{	
	private int rVal = 0;
	private int gVal = 0;
	private int bVal = 100;
	
	/** Empty Constructor for the Lights Class */
	public Lights()
	{
	}
	
	/** Abstract animate lights method
	 **/
	public abstract void animate();
	
	/** Accessor Set Method For RGB Colors
	* @param Integer red color value ranging from 0 to 255
	* @param Integer green color value ranging from 0 to 255
	* @param Integer blue color value ranging from 0 to 255
	*/
	public void setColorVals(int rValSet, int gValSet, int bValSet)
	{
		rVal = rValSet;
		gVal = gValSet;
		bVal = bValSet;
	}
	
	/** Accessor Get Method For Red Color
	* @return the Instance's Integer red color value
	*/
	public int getRVal()
	{
		return rVal;
	}
	/** Accessor Get Method For Green Color
	* @return the Instance's Integer green color value
	*/	
	public int getGVal()
	{
		return gVal;
	}
	/** Accessor Get Method For Blue Color
	* @return the Instance's Integer blue color value
	*/	
	public int getBVal()
	{
		return bVal;
	}
	
}

/** Flicker Animation Class that Extends the Lights Class  */
class LightsFlicker extends Lights
{
	private GroundRobot robotLights;
	private long duration = 1000;
	private int onTime = 500;
	private int offTime = 500;	
	
	/** Constructor That Takes a GroundRobot Object as Input */
	public LightsFlicker(GroundRobot robot) {
		robotLights = robot;
	}
	
	/** Flicker Animation Running Method */	
	public void animate()
	{
		int rFlicker = getRVal();
		int gFlicker = getGVal();
		int bFlicker = getBVal();
		
		for (long stop=System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(duration); stop > System.nanoTime();)
		{

			robotLights.setLights(rFlicker, gFlicker, bFlicker);
			robotLights.syncLights();
			for (long onStart=System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(onTime); onStart > System.nanoTime();)
			{	
			}

			robotLights.setLights(0, 0, 0);
			robotLights.syncLights();
			for (long offStart=System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(offTime); offStart > System.nanoTime();)
			{	
			}
			
		}
	}	
	/** Accessor Set Method For Animation Timing
	* @param Integer "On" Duration Time Value for the Animation
	* @param Integer "Off" Duration Time Value for the Animation
	* @param Integer Total Duration Time Value for the Animation
	*/	
	public void setFlickerTimes(int onTimeSet, int offTimeSet, int durationSet)
	{
		onTime = onTimeSet;
		offTime = offTimeSet;
		duration = durationSet;
	}
}

/** Breathe Animation Class that Extends the Lights Class  */
class LightsBreathe extends Lights
{	
	private GroundRobot robotLights;
	private long duration = 3000;
	private int inTime = 500;
	private int outTime = 500;
	private int steps = 10;
	
	/** Constructor That Takes a GroundRobot Object as Input */
	public LightsBreathe(GroundRobot robot) {
		robotLights = robot;
	}	
	
	/** Breathe Animation Running Method */
	public void animate()
	{
		int rFlicker = getRVal();
		int gFlicker = getGVal();
		int bFlicker = getBVal();
		float scalar = 0;
		
		float stepsFloat = (float)steps;
		float inStepRes = stepsFloat / (inTime / stepsFloat);
		float offStepRes = stepsFloat / (outTime / stepsFloat);		
		
		for (long stop=System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(duration); stop > System.nanoTime();)
		{
			for (long inStart=System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(inTime); inStart > System.nanoTime();)
			{	
				robotLights.setLights((int)(scalar * rFlicker), (int)(scalar * gFlicker), (int)(scalar * bFlicker));
				robotLights.syncLights();
				for (long inSubStart=System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(inTime/steps); inSubStart > System.nanoTime();)
				{
				}
				scalar += inStepRes;	
				scalar = Math.min(1.0f, scalar);
			}

			
			for (long offStart=System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(outTime); offStart > System.nanoTime();)
			{	
				robotLights.setLights((int)(scalar * rFlicker), (int)(scalar * gFlicker), (int)(scalar * bFlicker));
				robotLights.syncLights();
				for (long offSubStart=System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(inTime/steps); offSubStart > System.nanoTime();)
				{
				}
				scalar -= offStepRes;
				scalar = Math.max(0.0f, scalar);
			}
		}
	}
	/** Accessor Set Method For Animation Timing
	* @param Integer "In" Duration Time Value for the Animation
	* @param Integer "Out" Duration Time Value for the Animation
	* @param Integer Total Duration Time Value for the Animation
	*/	
	public void setBreatheTimes(int inTimeSet, int outTimeSet, int durationSet)
	{
		inTime = inTimeSet;
		outTime = outTimeSet;
		duration = durationSet;
	}	
}
/** Program DistanceMapLesson.java 
 	Example program to use the Defined Plot2D class and ultrasonic data for creating a visual map of the area around the robot
*/

/** Public Class Name Matches File Name */
public class DistanceMapLesson
{	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		control.scan(2000);	
		
		// Connect to Named Robot - Connection Function Returns Robot Object Named Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		robot.enableSensor(MessageCodes.D_Ultrasonic, 1);
		// Wait for 500 Milliseconds
		control.waitTime(500);
		
		// Create an Instance of the Distance Map Class
		CircleSweepMap circleMap = new CircleSweepMap(robot);
		
		// Run Circle And Collect Data
		double[][] DataXY = new double[2][(circleMap.getAngleLimit() / circleMap.getAngleStep()) + 1];
		DataXY = circleMap.distanceMap();
		
		
		// Create 2D Plot Objects, One Per Acceleration Axis
		Plot2D distancePlot = new Plot2D();
		distancePlot.setColor(0, 255, 0);
		
		// Set Limits For Plot
		distancePlot.setXLimits(-150, 150);
		distancePlot.setYLimits(-150, 150);
		
		// Set Data For Plot
		distancePlot.addData(DataXY[0], DataXY[1]);

		// Set Title For Plot
		distancePlot.setTitle("Distance Data");
		
		// Set X Label For Plot
		distancePlot.setXLabel("Distance (cm)");
		
		// Set Y Label For Plot
		distancePlot.setYLabel("Distance (cm)");
		
		// Create Plot
		distancePlot.plotData();
		
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);
		
	}
}


/** Class For Controlling the Robot to Conduct a Circular Distance Measurement Sweep */
class CircleSweepMap extends CircleSweep
{
	
	private int samples = 10;
	
	/** Constructor Takes as Input a GroundRobot Object
	 *@param GroundRobot Object
	 */
	public CircleSweepMap(GroundRobot robot)
	{
		super(robot);
	}
	
	/** Controls Robot to Incrementally Rotate and Take Sample Distance Readings 
	 *@return Array of X and Y Values Coordinates Calculated From Distance Readings And Angles (Centimeters)  
	 */
	public double[][] distanceMap()
	{
		int angleLimit = super.getAngleLimit();
		int angleStep = super.getAngleStep();
		double[][] distanceXY = new double[2][(angleLimit / angleStep) + 1];
		
		for (int k = 0; k <= angleLimit; k += angleStep)
		{
			// 
			int distance = getAverageDistance();
			distanceXY[0][k / angleStep] = Math.cos((double)(k) * Math.PI / 180.0) * distance;
			distanceXY[1][k / angleStep] = Math.sin((double)(k) * Math.PI / 180.0) * distance;
			
			// 
			super.getRobot().setupWait(MessageCodes.W_Rotation, angleStep * 1000);
			super.getRobot().move(MessageCodes.MD_Forward, MessageCodes.MD_Backward, 0.5f, 0.5f, true, true);
		}
		
		return distanceXY;
	}
	
	/** Reads Distance Data With Small Delay For a Set Number of Samples 
	 *@return Averaged Distance Value (Centimeters)  
	 */
	private int getAverageDistance()
	{
		int distance = 0;
		for (int i = 0; i < samples; i++)
		{
			distance += super.getRobot().getUSDistanceCMFiltered();
			super.getRobot().waitTime(10);
		}
		distance /= samples;
		return distance;
		
	}
	
	
}
/** Program UserInputLesson.java 
 	Example program to incorporate user input into a program
*/

import java.util.Scanner;

/** Public Class Name Matches File Name */
public class UserInputLesson
{	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Scan for User Input		
		Scanner reader = new Scanner(System.in);  // Reading from System.in
		System.out.println("Enter the Dongle USB Port: ");
		String usbPort = reader.nextLine();
		System.out.println("Enter the robot name: ");
		String robotName = reader.nextLine();
		
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(usbPort);
		
		// Scan for Robots for 2000 Milliseconds
		control.scan(2000);	
		
		// Connect to Named Robot - Connection Function Returns Robot Object Named Robot
		robot = control.connect(robotName);
		control.listen();
		robot.activateMotors();
		robot.enableSensor(MessageCodes.D_Ultrasonic, 1);
		// Wait for 500 Milliseconds
		control.waitTime(500);
		
		// User Input for Setting Lights
		System.out.println("Enter Comma Separated RGB Values (R,G,B): ");
		String rgbStr = reader.nextLine();
		reader.close();
		
		// Split the String By Commas
		String[] rgbParse = rgbStr.split(",");
		// Check for 3 Strings
		if (rgbParse.length != 3)
		{
			robot.deactivateMotors();
			control.disconnect(robot);
			System.out.println("Invalid Input");
			System.exit(0);
		}
		// Convert Strings to Integers
		int[] rgbVals = new int[3];		
		for (int i = 0; i < 3; i++)
		{
			rgbVals[i] = Math.min(Math.max(0, Integer.parseInt(rgbParse[i])), 255);
		}
		// Set And Sync LED Ring
		robot.setLights(rgbVals[0], rgbVals[1], rgbVals[2]);
		robot.syncLights();	
		robot.waitTime(3000);
		
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);
	}
}

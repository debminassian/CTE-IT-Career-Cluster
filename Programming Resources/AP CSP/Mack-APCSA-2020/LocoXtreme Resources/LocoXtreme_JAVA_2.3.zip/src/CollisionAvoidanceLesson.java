/** Program CollisionAvoidanceLesson.java 
 	Example program to drive around while avoiding obstacles detected in front of the robot
*/

import java.util.concurrent.TimeUnit;


/** Public Class Name Matches File Name */
public class CollisionAvoidanceLesson
{	
	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		control.scan(2000);
				
		// Connect to Named Robot - Connection Function Returns Robot Object Named Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		robot.enableSensor(MessageCodes.D_Ultrasonic, 1);
		// Wait for 500 Milliseconds
		control.waitTime(500);
		
		// Create Instance of Collision Avoidance Class
		CollisionAvoidance collisionAvoid = new CollisionAvoidance(robot);
		
		// Run Avoidance for 10 Seconds
		collisionAvoid.avoidanceRun(10);
		
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);		
	}	
}

/** Class For Robot Driving While Executing a Collision Avoidance Algorithm */
class CollisionAvoidance
{
	private GroundRobot avoidRobot;
	private int tuningClose = 10; // Centimeters
	private int tuningBackupDistance = 10; // Centimeters
	private int tuningTurnAngle = 60;  // Degrees
	
	/**  */
	public CollisionAvoidance(GroundRobot robot)
	{
		avoidRobot = robot;
	}
	
	/** Run Collision Avoidance for a Set Time 
	 *@param Long Data Type Duration to Run (Seconds)
	 */
	public void avoidanceRun(long runTime)
	{		
		// Start Driving
		avoidRobot.move(MessageCodes.MD_Forward, MessageCodes.MD_Forward, 0.5f, 0.5f, false, true);
		
		for (long stop=System.nanoTime() + TimeUnit.SECONDS.toNanos(runTime); stop > System.nanoTime();)
		{
			int distance = avoidRobot.getUSDistanceCMFiltered();
			
			if (distance < tuningClose)
			{
				objectClose();
			}			
			
			avoidRobot.waitTime(50);		
		}
		
		// Stop Driving
		avoidRobot.move(MessageCodes.MD_Forward, MessageCodes.MD_Forward, 0.0f, 0.0f, false, true);
	}
	
	/** Compensate When Detection of Object Within Threshold */
	private void objectClose()
	{
		// Backup
		avoidRobot.setupWait(MessageCodes.W_Distance, (tuningBackupDistance * 1000));
		avoidRobot.move(MessageCodes.MD_Backward, MessageCodes.MD_Backward, 0.5f, 0.5f, true, true);
		
		// Rotate 
		avoidRobot.setupWait(MessageCodes.W_Rotation, tuningTurnAngle * 1000);
		avoidRobot.move(MessageCodes.MD_Forward, MessageCodes.MD_Backward, 0.5f, 0.5f, true, true);
		
		// Drive Again
		avoidRobot.move(MessageCodes.MD_Forward, MessageCodes.MD_Forward, 0.5f, 0.5f, false, true);
	}
}
		
		
import java.util.ArrayList;

/** Program Chapter1TypesIdentifiers.java 
 	Example Program to Show Use of Identifiers and Data Types in Java   
*/
//Import a Time Package
import java.util.concurrent.TimeUnit;

/** Public Class Name Matches File Name */
public class Chapter1TypesIdentifiersOperators
{
	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Three Identifiers of the Integer Data Type 
		int r = 30;
		int g = 0;
		int b = 150;
		
		// Float Data Type for a Temperature Data Variable
		float temperature;
		
		// Array List of Ground Robots Set as null
		ArrayList<GroundRobot> scannedBots = null;
		
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		scannedBots = control.scan(2000);
		// Check Robot Names
		System.out.print("Robot Names: ");
		for (GroundRobot bot : scannedBots)
		{
			System.out.println(bot.getName());
		}		
		
		// Connect to Named Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		robot.enableSensor(MessageCodes.D_Temperature, 1);
		robot.enableSensor(MessageCodes.D_Ultrasonic, 1);
		// Wait for 500 Milliseconds
		control.waitTime(500);
				
		// Set Robot's lights with the Integers Declared Earlier
		robot.setLights(r, g, b);
		robot.syncLights();
		
		// Request Robot's Temperature Reading and Store in the Previously Declared float
		temperature = robot.getTempCelsius();
		System.out.print("Temperature C: ");
		System.out.println(temperature);
		
		
		// Use Operators to Average Temperature Readings
		temperature = 0;
		int numReadings = 0;
		// Run for 2 Seconds
		for (long stop=System.nanoTime() + TimeUnit.SECONDS.toNanos(2); stop > System.nanoTime();) 
		{
			// Addition Assignment Operator
			temperature += robot.getTempCelsius();
			// Increment Operator
			numReadings++;
			// Wait for 500 Milliseconds
			control.waitTime(500);
		}
		
		
		float c_to_f_sf = 1.8f;
		float c_to_f_bias = 32.0f;
		float f_to_k_bias1 = 32.0f;
		float f_to_k_mt = 5.0f;
		float f_to_k_mb = 9.0f;
		float f_to_k_bias2 = 273.15f;		
		
		// Compute Average Reading
		temperature = temperature / numReadings;
		System.out.print("Average Temperature C: ");
		System.out.println(temperature);
		
		// Convert Celsius to Fahrenheit
		temperature = temperature * c_to_f_sf + c_to_f_bias; 
		System.out.print("Average Temperature F: ");
		System.out.println(temperature);
		
		// Convert Fahrenheit to Kelvin
		temperature = ((temperature - f_to_k_bias1) * (f_to_k_mt /f_to_k_mb)) + f_to_k_bias2; 
		System.out.print("Average Temperature K: ");
		System.out.println(temperature);
		
		// Compare Temperature To Thresholds
		if (temperature > 0)
		{
			System.out.println("The Temperature (K) is above absolute zero!");
		}
		if (temperature > 273)
		{
			System.out.println("The Temperature (K) is above the freezing temperature of water!");
		}
		// AND Operator
		if ((temperature > 293.15) && (temperature <= 295.15))
		{
			System.out.println("The Temperature (K) is approximately room temperature!");
		}
		if (temperature == 373.15)
		{
			System.out.println("The Temperature (K) is at the boiling point of water!");
		}
		
		// Get Distance and Compare It to Threshold Values
		int distance = robot.getUSDistanceCMFiltered(); 		
		while (distance != 10)
		{
			distance = robot.getUSDistanceCMFiltered();
			System.out.println(distance);
			// Wait for 500 Milliseconds
			control.waitTime(100);
		}		
		System.out.println("Distance Loop Ended");
		
		// Deactivate the Motors and Disconnect from the Robot
		robot.deactivateMotors();
		control.disconnect(robot);
	}	
}

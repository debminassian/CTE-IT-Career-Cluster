/** Program Chapter3Interfaces.java 
 	Example program to show use of Interfaces in Java   
*/

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;


/** Public Class Name Matches File Name */
public class Chapter3Interfaces
{
	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Array List of Ground Robots set as null
		ArrayList<GroundRobot> scannedBots = null;
		
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		scannedBots = control.scan(2000);
		// Check Robot Names
		System.out.print("Robot Names: ");
		// For-Each Loop 
		for (GroundRobot bot : scannedBots)
		{
			System.out.println(bot.getName());
		}		
		
		// Connect to Named Robot - Connection Function Returns Robot Object Named robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		
		// Create Instance of the RobotOrientation Class and Store in Object robotOri
		RobotOrientation robotOri = new RobotOrientation(robot);
		// Wait for 500 Milliseconds
		control.waitTime(500);

		// Timed Loop to Run for 10 Seconds
		for (long stop=System.nanoTime() + TimeUnit.SECONDS.toNanos(10); stop > System.nanoTime();)
		{
			// Update robotOri's Acceleration Data
			robotOri.updateAccelerometerData();
			// Calculate the Roll and Pitch Angles (Degrees) From robotOri's Stored Accelerometer Data 
			double roll = robotOri.calcualtePitch();
			double pitch = robotOri.calcualteRoll();
	
			System.out.println("Roll (Degress), Pitch (Degrees): " + roll + ", " + pitch);
			// Wait for 250 Milliseconds
			control.waitTime(250);
		}
		
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);
	}		
}

/** Interface for Euler Angle Methods */
interface EulerAngles
{
	double calcualtePitch();
	double calcualteRoll();
}

/** Class for Storing Acceleration Data and Calculating Acceleration Data Based Roll and Pitch Angles */
class RobotOrientation implements EulerAngles
{
	private GroundRobot orientationRobot;
	private double ax;
	private double ay;
	private double az;
	
	/** Constructor with Input of GroundRobot Object */
	public RobotOrientation(GroundRobot robot)
	{
		orientationRobot = robot;
		orientationRobot.enableSensor(MessageCodes.D_Accelerometer, 1);
	}
	
	/** Update Accelerometer Data Using the GroundRobot Object */
	public void updateAccelerometerData()
	{
		ax = orientationRobot.getAccelXFiltered();
		ay = orientationRobot.getAccelYFiltered();
		az = orientationRobot.getAccelZFiltered();
	}
	
	/** Calculates Pitch Angle Based on Accelerometer Data
	* @return Double Type Pitch Angle in Degrees
	*/
	public double calcualtePitch() {
		double pitch = 0;
		try
		{
			pitch = Math.atan2(ay, Math.sqrt(ax*ax + az*az)) * (180.0 / Math.PI);
		}
		catch(Exception E) { E.printStackTrace(); }		
		return pitch;
	}

	/** Calculates Roll Angle Based on Accelerometer Data
	* @return Double Type Roll Angle in Degrees
	*/
	public double calcualteRoll() {
		double roll = 0;
		try
		{
			roll = Math.atan2(ax, Math.sqrt(ay*ay + az*az)) * (180.0 / Math.PI);
		}
		catch(Exception E) { E.printStackTrace(); }
		return roll;
	}	
}


/** Program Chapter1Classes.java 
 	Example program to show how to setup a class, a process that can be used in later examples  
*/
// Import a Time Package -- Unused in This File
import java.util.concurrent.TimeUnit;

// Public Class Name Matches File Name
public class Chapter1Classes 
{
	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{		
		// Print to the Console the Returned Value of basicMethod for the Integer Inputs 1 and 2 
		System.out.println(basicMethod(1, 2));
	}
	
	// A Private Method in the Chapter1Classes Class, Only accessible in this class
	/** Takes in two Integer values, squares their sum and returns it
	* @param an Integer to be used in the calculation
	* @param an Integer to be used in the calculation
	* @return the sum of the squares of the inputs
	*/	
	private static int basicMethod(int a, int b)
	{
		return a*a + b*b;
	}
}


/** Program RobotMaze.java 
 	Example program to Have the Robot Attempt to Solve a Maze 
*/

/** Public Class Name Matches File Name */
public class RobotMaze
{	
	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		control.scan(2000);
				
		// Connect to Named Robot - Connection Function Returns Robot Object Named Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		robot.enableSensor(MessageCodes.D_Ultrasonic, 1);
		robot.enableSensor(MessageCodes.D_Accelerometer, 1);
		// Wait for 500 Milliseconds
		control.waitTime(500);
		
		// Create an Instance of the MazeSolver class
		MazeSolver mazeObj = new MazeSolver(robot);
		
		// Drive Maze		
		mazeObj.driveMaze();
		
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);	
	}	
}

/** Robot Maze Solving Class */
class MazeSolver
{
	private GroundRobot mazeRobot;
	private float speed = 0.3f;
	private int closeDist = 6;
	
	/** Constructor That Takes a GroundRobot Object as Input */
	public MazeSolver(GroundRobot robot)
	{
		mazeRobot = robot;
	}
	
	
	/** Drive the Robot in a Maze */
	public void driveMaze()
	{				
		// Start Moving
		mazeRobot.move(MessageCodes.MD_Forward, MessageCodes.MD_Forward, speed, speed, false, true);
		
		// Maze Loop Logic
		boolean notUpsideDown = true;		
		while (notUpsideDown)
		{			
			// Check Distance
			checkDistance();
			
			// Short Wait
			mazeRobot.waitTime(50);
			
			// Check UpsideDown
			notUpsideDown = checkNotFlipped();
		}
		mazeRobot.move(MessageCodes.MD_Forward, MessageCodes.MD_Forward, 0.0f, 0.0f, false, true);
	}
	
	/** Check If Robot Within Distance Threshold, and Turn When It Is */
	private void checkDistance()
	{
		// Read Distance And Check Threshold
		int distance = mazeRobot.getUSDistanceCMFiltered();
		if (distance < closeDist)
		{
			while (distance < closeDist)
			{
				mazeRobot.setupWait(MessageCodes.W_Rotation, 90000);
				mazeRobot.move(MessageCodes.MD_Forward, MessageCodes.MD_Backward, speed, speed, true, true);
				distance = mazeRobot.getUSDistanceCMFiltered();
			}
			// Start Moving
			mazeRobot.move(MessageCodes.MD_Forward, MessageCodes.MD_Forward, speed, speed, false, true);
		}
	}
	
	/** Check If Robot is UpsideDown
	 *@return Flag State of Robot's Orientation 
	 */
	private boolean checkNotFlipped()
	{
		// Read Z-Axis Accelerometer Data
		double az = mazeRobot.getAccelZFiltered();
		if (az < 0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
}


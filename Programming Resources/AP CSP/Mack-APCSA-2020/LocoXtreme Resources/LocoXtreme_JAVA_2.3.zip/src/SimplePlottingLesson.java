/** Program SimplePlottingLesson.java 
 	Example program to use the Defined Plot2D class for Visualizing Sensor Data 
*/

/** Public Class Name Matches File Name */
public class SimplePlottingLesson
{	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		control.scan(2000);	
		
		// Connect to Named Robot - Connection Function Returns Robot Object Named Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		robot.enableSensor(MessageCodes.D_Accelerometer, 1);
		// Wait for 500 Milliseconds
		control.waitTime(500);
		
		// Specify Number of Samples And Time Delay Between Samples 
		int samples = 10;
		int sampleDelay = 50; // Milliseconds
		
		// Initialize Time Data and Accelerometer Data Arrays
		double[] tData = new double[samples];
		double[] xData = new double[samples];
		double[] yData = new double[samples];
		double[] zData = new double[samples];
		
		// Run A Loop To Sample Sensor Data
		int i = 0;
		double timeStart = System.currentTimeMillis();
		while (i < samples)
		{			
			xData[i] = robot.getAccelXFiltered();
			yData[i] = robot.getAccelYFiltered();
			zData[i] = robot.getAccelZFiltered();
			tData[i] = System.currentTimeMillis() - timeStart;
			robot.waitTime(sampleDelay);
			i++;
		}
		
		// Create 2D Plot Objects, One Per Acceleration Axis
		Plot2D accXPlot = new Plot2D();
		Plot2D accYPlot = new Plot2D();
		Plot2D accZPlot = new Plot2D();
		
		// Set RGB Colors of Each Plot
		accXPlot.setColor(255, 0, 0);
		accYPlot.setColor(0, 255, 0);
		accZPlot.setColor(0, 0, 255);
		
		// Set Plot Limits
		double timeMin = tData[0];
		double timeMax = tData[samples - 1];
		double accMin = -1;
		double accMax = 1.5;
		accXPlot.setXLimits(timeMin, timeMax);
		accXPlot.setYLimits(accMin, accMax);
		accYPlot.setXLimits(timeMin, timeMax);
		accYPlot.setYLimits(accMin, accMax);
		accZPlot.setXLimits(timeMin, timeMax);
		accZPlot.setYLimits(accMin, accMax);
		
		// Set Data For Each Plot
		accXPlot.addData(tData, xData);
		accYPlot.addData(tData, yData);
		accZPlot.addData(tData, zData);
		
		// Set Title For Each Plot
		accXPlot.setTitle("X-Axis Accelerometer Data");
		accYPlot.setTitle("Y-Axis Accelerometer Data");
		accZPlot.setTitle("Z-Axis Accelerometer Data");

		// Set X-Axes Labels for Each Plot
		String xLabel = "Time (ms)";
		accXPlot.setXLabel(xLabel);
		accYPlot.setXLabel(xLabel);
		accZPlot.setXLabel(xLabel);
		
		// Set Y-Axes Labels for Each Plot
		accXPlot.setYLabel("Acceleration (g)");
		accYPlot.setYLabel("Acceleration (g)");
		accZPlot.setYLabel("Acceleration (g)");
		
		// Create Each Plot
		accXPlot.plotData();
		accYPlot.plotData();
		accZPlot.plotData();		
		
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);
	}
}
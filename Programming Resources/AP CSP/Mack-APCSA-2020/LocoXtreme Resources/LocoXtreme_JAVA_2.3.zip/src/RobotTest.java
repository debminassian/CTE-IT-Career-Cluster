import java.util.ArrayList;
//import java.util.concurrent.TimeUnit;

public class RobotTest 
{

	public static void main(String[] args)
	{
		// Array List of Ground Robots set as null
		ArrayList<GroundRobot> scannedBots = null;
		
		RobotControl control = new RobotControl();
		GroundRobot robot = null;
		
		String usb_address = "COM5";
		control.setup(usb_address);
		
		scannedBots = control.scan(2000);
		// Check Robot Names
		System.out.print("Robot Names: ");
		// For-Each Loop 
		for (GroundRobot bot : scannedBots)
		{
			System.out.println(bot.getName() + " " + bot.getMacAddress());
		}	
		
		robot = control.connect("lr6765");
		control.listen();
		
		robot.activateMotors();
		//robot.enableSensor(MessageCodes.D_Accelerometer, 1);
		//control.waitTime(500);
		
		//System.out.println(robot.getMacAddress());
		//robot.setLights(100, 0, 100);
		//robot.syncLights();
		//control.waitTime(2000);
		//System.out.println("got here");
		
		//robot.setName("lr6765");
		
		//System.out.println(robot.getAccelXFiltered());
		//System.out.println(robot.getAccelYFiltered());
		//System.out.println(robot.getAccelZFiltered());
		
		robot.enableSensor(MessageCodes.D_MagnetometerRaw, 1);
		robot.enableSensor(MessageCodes.D_Magnetometer, 1);
		//robot.enableSensor(MessageCodes.D_Temperature, 1);
		control.waitTime(500);	
		
		/*
		//robot.enableSensor(MessageCodes.D_Ultrasonic, 1);
		//robot.enableSensor(MessageCodes.D_AccelerometerRaw, 1);
		robot.enableSensor(MessageCodes.D_GyroscopeRaw, 1);
		robot.enableSensor(MessageCodes.D_MagnetometerRaw, 1);
		robot.enableSensor(MessageCodes.D_Magnetometer, 1);
		robot.enableSensor(MessageCodes.D_Heading, 1);
		//robot.enableSensor(MessageCodes.D_Temperature, 1);
		control.waitTime(500);
		
		//robot.setupWait(MessageCodes.W_Song);
		//robot.playNote(MessageCodes.N_C, 1000, true);
		//robot.playSong(MessageCodes.SO_StarWars, true);
		
		//robot.setupWait(MessageCodes.W_UltrasonicLessThan, 10000);
		//robot.setupWait(MessageCodes.W_Distance, 10000);
		//robot.setupWait(MessageCodes.W_Rotation, 90000);
		//robot.move(MessageCodes.MD_Forward, MessageCodes.MD_Backward, (float)0.5, (float)0.5, true, true);
		
		
		robot.setLights(150, 0, 150);
		robot.syncLights();
		
		for (long stop=System.nanoTime() + TimeUnit.SECONDS.toNanos(2); stop > System.nanoTime();) 
		{
			
			//System.out.println("Distance: " + robot.getUSDistanceCMFiltered());
			//System.out.println("Temperature: " + robot.getTempCelsius());
			//System.out.println("Acceleration: " + robot.getAccelXFiltered() + ", " + robot.getAccelYFiltered() + ", " + robot.getAccelZFiltered());			
			//System.out.println("Acceleration Raw: " + robot.getAccelXRaw() + ", " + robot.getAccelYRaw() + ", " + robot.getAccelZRaw());
			
			System.out.println("Gyroscope Raw: " + robot.getGyroXRaw() + ", " + robot.getGyroYRaw() + ", " + robot.getGyroZRaw());
			System.out.println("Magnetometer Raw: " + robot.getMagnetometerXRaw() + ", " + robot.getMagnetometerYRaw() + ", " + robot.getMagnetometerZRaw());
			System.out.println("Magnetometer: " + robot.getMagnetometerXFiltered() + ", " + robot.getMagnetometerYFiltered() + ", " + robot.getMagnetometerZFiltered());
			System.out.println("Heading: " + robot.getHeadingDegrees());
			
			
			//System.out.println(robot.getUSDistanceCMRaw());
			
			control.waitTime(500);
		}			
		
		 */
		
		robot.deactivateMotors();
		
		control.disconnect(robot);
	}
	
}
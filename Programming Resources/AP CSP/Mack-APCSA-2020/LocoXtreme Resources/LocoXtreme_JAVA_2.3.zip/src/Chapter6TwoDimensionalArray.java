/** Program Chapter6TwoDimensionalArray.java 
 	Example program to show use of 2D Arrays in Java   
*/

import java.util.ArrayList;


/** Public Class Name Matches File Name */
public class Chapter6TwoDimensionalArray
{
	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{

		// Array List of Ground Robots set as null
		ArrayList<GroundRobot> scannedBots = null;
		
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		scannedBots = control.scan(2000);
		// Check Robot Names
		System.out.print("Robot Names: ");
		// For-Each Loop 
		for (GroundRobot bot : scannedBots)
		{
			System.out.println(bot.getName());
		}
		// Connect to Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		
		// Wait for 500 Milliseconds
		control.waitTime(500);
				
		//2D Array for LED Colors - RGB by Index
		int[][] colors = {{255, 0, 0, 128, 255, 0, 0, 128}, 
						  {0, 0, 255, 128, 0, 0, 255, 128},
						  {255, 128, 0, 0, 255, 128, 0, 0}};
		
		// Create Instance of the LightsArray Class and Store It in the Object lightArrayObj
		LightsArray lightArrayObj = new LightsArray(robot);
		
		// Set LEDs with the setLightsArray Method and the 2D colors Array
		lightArrayObj.setLightsArray(colors);
		// Wait for 5 Seconds
		control.waitTime(5000);	
		
		// Update the colors Array Value at Index 2, 2 (Row, Column)
		colors[2][2] = 255;
		// Set LEDs with the setLightsArray Method and the 2D colors Array
		lightArrayObj.setLightsArray(colors);
		// Wait for 5 Seconds
		control.waitTime(5000);				
		
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);	
	}	
}

/** Class to Set LEDs From An Array of Colors */
class LightsArray
{
	private GroundRobot lightsArrayRobot;
	
	/** */
	public LightsArray(GroundRobot robot)
	{
		lightsArrayRobot = robot;		
	}
		
	/** Method to Set LEDs from a 2D Array of RGB Color Data 
	 * @param 2D Integer Array of RGB Color Values 
	 */
	public void setLightsArray(int[][] colorsMatrix)
	{		
		for (int i = 0; i < colorsMatrix[0].length; i++)
		{
			lightsArrayRobot.setLight(i, colorsMatrix[0][i], colorsMatrix[1][i], colorsMatrix[2][i]);
		}
		lightsArrayRobot.syncLights();
	}	
}

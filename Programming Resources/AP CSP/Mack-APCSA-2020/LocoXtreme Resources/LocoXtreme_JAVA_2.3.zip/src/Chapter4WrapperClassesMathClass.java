/** Program Chapter4WrapperClassesMathClass.java 
 	Example program to show use of Wrapper Classes and the Math Class in Java   
*/

import java.util.ArrayList;


/** Public Class Name Matches File Name */
public class Chapter4WrapperClassesMathClass
{
	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{		
		// Array List of Ground Robots set as null
		ArrayList<GroundRobot> scannedBots = null;
		
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		scannedBots = control.scan(2000);
		// Check Robot Names
		System.out.print("Robot Names: ");
		// For-Each Loop 
		for (GroundRobot bot : scannedBots)
		{
			System.out.println(bot.getName());
		}
		// Connect to Named Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		robot.enableSensor(MessageCodes.D_Ultrasonic, 1);
		robot.enableSensor(MessageCodes.D_Temperature, 1);
		// Wait for 500 Milliseconds
		control.waitTime(500);
		
		// Boxes in Integer Object - Integer is a subclass of Object
		Integer distValue = new Integer(10);
		// Un-boxes from Integer Object
		int j = distValue.intValue(); 
		// Get Ultrasonic Sensor Distance Reading
		int distance = robot.getUSDistanceCMFiltered();
		// Compare Distance Reading with the Boxed and Un-boxed Integer Values
		System.out.println(distValue.equals(distance));
		System.out.println(j == distance);
		
		// Boxes in Double Object - Integer is a subclass of Object
		Double tempValue = new Double(23.15);
		// Un-boxes from Double Object
		int k = tempValue.intValue(); 
		// Get Temperature Sensor Data
		double temperature = robot.getTempCelsius();
		// Compare Distance Reading with the Boxed and Un-boxed Integer Values
		System.out.println(tempValue.equals(temperature));
		System.out.println(k == temperature);
		
		// Pick a Random Number from 0 to 20 Cast to Integer
		int x = (int)(20 * Math.random()); 
		// Read Distance Value and Print it Along with the Randomly Picked Threshold Value
		distance = robot.getUSDistanceCMFiltered();	
		System.out.println("Starting Distance (cm): " + distance);
		System.out.println("Distance Threshold (cm): " + x);
		// Loop while the Distance Read is Not Less Than the Threshold Value  
		while (distance < x)
		{	
			distance = robot.getUSDistanceCMFiltered();	
			control.waitTime(100);
		}
		// Print Out Ending Distance Value
		System.out.println("Last Distance (cm): " + distance);
				
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);
	}	
}

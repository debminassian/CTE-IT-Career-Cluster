/** Program EncoderConversionLesson.java 
 	Example program to Convert Encoder Ticks to Distance  
*/

import java.util.concurrent.TimeUnit;


/** Public Class Name Matches File Name */
public class EncoderConversionLesson
{	
	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		control.scan(2000);
				
		// Connect to Named Robot - Connection Function Returns Robot Object Named Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		robot.enableSensor(MessageCodes.D_RunningEncoders, 1);
		// Wait for 500 Milliseconds
		control.waitTime(500);
		
		// Create a New Instance of the ENcoderConversion class
		EncoderConversion encoderConv = new EncoderConversion();
		
		
		// Start Driving
		float speed = 0.4f;
		double distTraveledL = 0;
		int lastTicksL = robot.getLeftEncCount();
		double distTraveledR = 0;
		int lastTicksR = robot.getRightEncCount();
		robot.move(MessageCodes.MD_Forward, MessageCodes.MD_Forward, speed, speed, false, true);
		
		// Run for a Timed Duration
		for (long stop=System.nanoTime() + TimeUnit.SECONDS.toNanos(3); stop > System.nanoTime();)
		{
			// Read Encoders
			int leftTicks = robot.getLeftEncCount();
			int rightTicks = robot.getRightEncCount();
			
			distTraveledL += encoderConv.getDistance(leftTicks, lastTicksL);
			distTraveledR += encoderConv.getDistance(rightTicks, lastTicksR);
			
			lastTicksL = leftTicks;
			lastTicksR = rightTicks;
			
			// Short Wait
			robot.waitTime(50);
		}
		
		// Stop Driving
		robot.move(MessageCodes.MD_Forward, MessageCodes.MD_Forward, 0.0f, 0.0f, false, true);
		
		System.out.println("Distance Traveled (Left, Right) [cm]: (" + distTraveledL + ", " + distTraveledR + ")");
		
		
		
		// Start Driving		
		speed = 0.8f;
		double angleRotatedL = 0;
		double angleRotatedR = 0;
		lastTicksL = robot.getLeftEncCount();
		lastTicksR = robot.getRightEncCount();
		robot.move(MessageCodes.MD_Forward, MessageCodes.MD_Backward, speed, speed, false, true);
				
		// Run for a Timed Duration
		for (long stop=System.nanoTime() + TimeUnit.SECONDS.toNanos(3); stop > System.nanoTime();)
		{
			// Read Encoders
			int leftTicks = robot.getLeftEncCount();
			int rightTicks = robot.getRightEncCount();
			angleRotatedL += encoderConv.getAngle(leftTicks, lastTicksL);
			angleRotatedR += encoderConv.getAngle(rightTicks, lastTicksR);

			lastTicksL = leftTicks;
			lastTicksR = rightTicks;
			
			// Short Wait
			robot.waitTime(50);
		}
		
		// Stop Driving
		robot.move(MessageCodes.MD_Forward, MessageCodes.MD_Forward, 0.0f, 0.0f, false, true);
		
		System.out.println("Angle Rotated (Left, Right) [deg]: (" + angleRotatedL + ", " + angleRotatedR + ")");
		
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);	
	}	
}

/** */
class EncoderConversion
{
	private final double MM_PER_REVOLUTION = 117;
	private final double GEAR_RATIO = 150;
	private final double ENCODER_RATIO = 12;
	private final double MM_PER_CM = 10;
	private final double TICKS_PER_10_DEGREES = 140;
	
	/** */
	public EncoderConversion()
	{
	}
	
	/** */
	public double getDistance(int encoderTicks, int lastTicks)
	{
		double deltaTicks = Math.abs(encoderTicks - lastTicks);
		double distance = ((deltaTicks * MM_PER_REVOLUTION) / GEAR_RATIO / ENCODER_RATIO / MM_PER_CM);
		//System.out.println(encoderTicks + ", " + lastTicks);
		return distance;
	}

	/** */
	public double getAngle(int encoderTicks, int lastTicks)
	{
		double deltaTicks = Math.abs(encoderTicks - lastTicks);
		return ((deltaTicks * 10) / TICKS_PER_10_DEGREES);		
	}
}


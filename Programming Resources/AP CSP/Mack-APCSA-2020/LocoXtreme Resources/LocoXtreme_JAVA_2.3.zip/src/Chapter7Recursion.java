/** Program Chapter7Recursion.java 
 	Example program to show use of a Recursive Method in Java   
*/

import java.util.ArrayList;


/** Public Class Name Matches File Name */
public class Chapter7Recursion
{	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Array List of Ground Robots set as null
		ArrayList<GroundRobot> scannedBots = null;
		
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		scannedBots = control.scan(2000);
		// Check Robot Names
		System.out.print("Robot Names: ");
		// For-Each Loop 
		for (GroundRobot bot : scannedBots)
		{
			System.out.println(bot.getName());
		}
		// Connect to the Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		robot.enableSensor(MessageCodes.D_Ultrasonic, 1);
		// Wait for 500 Milliseconds
		control.waitTime(500);
				
		// Create Instance of the RecursiveDistance Class
		RecursiveDistance recursiveObj = new RecursiveDistance(robot, control, 50, 25);
		// Call the recursiveMeasure Method with an Input of 0
		recursiveObj.recurvsiveMeasure(0);		
		// Call the recursiveLights Method with an Input of 0
		recursiveObj.recursiveLights(0);
		// Wait 5 Seconds
		control.waitTime(5000);		
		
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);	
	}	
}

/** Class With Recursive Methods for LED Setting and a Particular Distance Check Behavior */
class RecursiveDistance
{
	private GroundRobot recursiveRobot;
	private RobotControl recursiveControl;
	private int distance = 0;
	private int readingsThresh;
	private int distThresh;
	
	private int[][] lightsData = {{0,   0,   0,   0,   0,   0,   50, 128}, 
								  {0,   10,  50,  128, 255, 0,   0,   0},
								  {255, 255, 255, 255, 255, 255, 255, 255}};;
	
	/** Constructor That Takes in a GroundRobot, a RobotControl Object, a Number of Readings Integer, and a Distance Value (Centimeters) Integer */
	public RecursiveDistance(GroundRobot robot, RobotControl control, int readings, int dist)
	{
		recursiveRobot = robot;
		recursiveControl = control;
		readingsThresh = readings;
		distThresh = dist;
	}
	
	/** Recursively Check for Threshold Crossed or Number of Readings Exceeded 
	 * @param Integer of Starting Number of Readings Value
	 */
	public void recurvsiveMeasure(int readingsCount)
	{
		distance = recursiveRobot.getUSDistanceCMFiltered();
		if (distance > distThresh)
		{
			System.out.println("Safe Distance to Exit");
		}
		else if (readingsCount > readingsThresh)
		{
			System.out.println("Done Checking");
		}
		else 
		{
			recursiveControl.waitTime(100);
			readingsCount++;
			recurvsiveMeasure(readingsCount);
		}	
	}
	
	/** Recursively Set LEDs From a 2D Array of Data 
	 * @param Integer of Starting LED Index
	 */
	public void recursiveLights(int colVal)
	{		
		recursiveRobot.setLight(colVal, lightsData[0][colVal], lightsData[1][colVal], lightsData[2][colVal]);
		colVal += 1;
		if (colVal < 8)
		{
			recursiveLights(colVal);
		}
		else
		{
			recursiveRobot.syncLights();
		}
	}	
}

/** Program GyroscopeDrift.java 
 	Example program to find bias error in gyroscope data
*/

import java.util.concurrent.TimeUnit;

/** Public Class Name Matches File Name */
public class GyroscopeDrift
{	
	// The Main Method: Gets Executed 
	public static void main(String[] args)
	{
		// Use the "final" Keyword for User-Defined Constants, They Cannot be Changed After Declaration
		final String USB_PORT_ADDRESS = "COM5";	
		final String ROBOT_NAME = "lr6765";
		
		// Identifier for a new Instance of the RobotClass
		RobotControl control = new RobotControl();
		// Identifier for a Robot, Set as null
		GroundRobot robot = null;
		
		// Passing the final Variable "USB_PORT_ADDRESS" to the RobotClass Method "setup"
		control.setup(USB_PORT_ADDRESS);
		
		// Scan for Robots for 2000 Milliseconds
		control.scan(2000);	
		
		// Connect to Named Robot - Connection Function Returns Robot Object Named Robot
		robot = control.connect(ROBOT_NAME);
		control.listen();
		robot.activateMotors();
		robot.enableSensor(MessageCodes.D_GyroscopeRaw, 1);
		// Wait for 500 Milliseconds
		control.waitTime(500);
		
		// Create a New Instances of the GryoscopeData class
		GyroscopeData gyroData = new GyroscopeData(robot);
		
		// Get Gyroscope Offsets
		gyroData.getGyroOffsets();
		
		
		// Loop for a time Using Gyroscope Offset Compensation
		System.out.println("Starting Offset Compensation Loop");
		for (long stop=System.nanoTime() + TimeUnit.SECONDS.toNanos(5); stop > System.nanoTime();)
		{
			double[] dataArray = gyroData.getGyroCalibrated();
			System.out.println("Offset Compensated Gyroscope Data (deg/sec); " + dataArray[0] + ", " + dataArray[1] + ", " + dataArray[2]);
			robot.waitTime(100);
		}
		
		
		// Loop for a time Using Gyroscope Offset Bounding
		System.out.println("Starting Offset Bounding Loop");
		for (long stop=System.nanoTime() + TimeUnit.SECONDS.toNanos(5); stop > System.nanoTime();)
		{
			double[] dataArray = gyroData.getGyroBounded();
			System.out.println("Offset Bounded Gyroscope Data (deg/sec); " + dataArray[0] + ", " + dataArray[1] + ", " + dataArray[2]);
			robot.waitTime(100);
		}
		
		
		// Deactivate Motors and Disconnect from Robot
		robot.deactivateMotors();
		control.disconnect(robot);
	}
}

/** Class For Minimizing Gyroscope Data Drift */
class GyroscopeData
{
	private GroundRobot gyroRobot;
	private double gyroXOff = 0;
	private double gyroYOff = 0;
	private double gyroZOff = 0;
	
	private int avgCounts = 100;
	
	/** Constructor Takes As Input a GroundRobot Object */
	public GyroscopeData(GroundRobot robot)
	{
		gyroRobot = robot;
	}
	
	/** Calculates Average Gyroscope Readings For a Set Number of Samples */
	private double[] getAverageGyro()
	{
		double[] gyroAvg = new double[3];
		double avgX = 0;
		double avgY = 0;
		double avgZ = 0;
		
		for (int i = 0; i < avgCounts; i++)
		{
			avgX += gyroRobot.getGyroXRaw();
			avgY += gyroRobot.getGyroYRaw();
			avgZ += gyroRobot.getGyroZRaw();
			gyroRobot.waitTime(50);
		}
		gyroAvg[0] = avgX / avgCounts;
		gyroAvg[1] = avgY / avgCounts;
		gyroAvg[2] = avgZ / avgCounts;
		
		return gyroAvg;
	}
	
	/** Calculates Gyroscope Offset Values */
	public void getGyroOffsets()
	{
		double[] gyroOffsets = getAverageGyro();
		gyroXOff = gyroOffsets[0];
		gyroYOff = gyroOffsets[1];
		gyroZOff = gyroOffsets[2];
	}
	
	/** Get Gyroscope Data With Offset Removal */	
	public double[] getGyroCalibrated()
	{
		double[] gyroData = new double[3];
		
		gyroData[0] = gyroRobot.getGyroXRaw() - gyroXOff;
		gyroData[1] = gyroRobot.getGyroYRaw() - gyroYOff;
		gyroData[2] = gyroRobot.getGyroZRaw() - gyroZOff;
		
		return gyroData;
	}
	
	/** Get Gyroscope Data With Below Offset Values Floored To Zero*/	
	public double[] getGyroBounded()
	{
		double[] gyroData = new double[3];
		
		gyroData[0] = gyroRobot.getGyroXRaw() - gyroXOff;
		gyroData[1] = gyroRobot.getGyroYRaw() - gyroYOff;
		gyroData[2] = gyroRobot.getGyroZRaw() - gyroZOff;
		
		if (Math.abs(gyroData[0]) < Math.abs(gyroXOff))
		{
			gyroData[0] = 0;	
		}
		if (Math.abs(gyroData[1]) < Math.abs(gyroYOff))
		{
			gyroData[1] = 0;	
		}
		if (Math.abs(gyroData[2]) < Math.abs(gyroZOff))
		{
			gyroData[2] = 0;	
		}		
		return gyroData;
	}
}


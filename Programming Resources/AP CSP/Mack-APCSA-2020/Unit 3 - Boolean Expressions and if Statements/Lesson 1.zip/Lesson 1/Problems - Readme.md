# Example: Old Enough To Vote
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

CanVote

# Example: Grade Range
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

graderange

# Example: Equality of Strings
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

main

# Problem 1 - Sugar Tax
In this [article](https://www.heart.org/en/healthy-living/healthy-eating/eat-smart/sugar/added-sugars) , the American Heart Association recommends that adult men get no more than 36 grams of added sugar and adult women get no more than 25 grams of added sugar per day.

In this program, ask the user to enter the number of grams of added sugar they have eaten that day. Using 30 grams as the cut off point, use a boolean statement to state if the user can eat more sugar.

Here is what your output should look like:
```
How many grams of sugar have you eaten today? 
28
You can eat more sugar: true
```

Source: https://www.heart.org/en/healthy-living/healthy-eating/eat-smart/sugar/added-sugars


import java.util.Scanner;

public class AddedSugar
{
    public static void main(String[] args)
    {
        // Ask the user for the grams of sugar
        
        // Use a boolean expression to print if they can eat more sugar
    }
}
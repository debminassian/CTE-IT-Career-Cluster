public class Car
{
    String name;
    String model;
    int cost;
    
    public Car(String name, String model, int cost)
    {
        this.name = name;
        this.model = model;
        this.cost = cost;
    }
}
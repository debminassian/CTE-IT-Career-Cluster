import java.util.ArrayList;
public class Agency
{
    public static void main(String[] args)
    {
        //Initialize your ArrayLists here!
        
    }
}
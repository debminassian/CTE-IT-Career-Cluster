import java.util.ArrayList;
public class CarTracker
{
    public static void main(String[] args)
    {
        //Initialize your ArrayList here:
    }
}

# Example: While Loop Countdown
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

WhileLoopCountdown

# Example: Get Down to One
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

Gettoone

# Example: Running Average
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

RunningAverage

# Problem 1 - Max and Min Values

In this exercise, you will need to write a program that asks the user to enter different positive numbers.

After each number is entered, print out which number is the maximum and which number is the minimum of the numbers they have entered so far.

Stop asking for numbers when the user enters -1.

Possible output:
```
Enter a number (-1 to quit): 
100
Smallest # so far: 100
Largest # so far: 100
Enter a number (-1 to quit): 
4
Smallest # so far: 4
Largest # so far: 100
Enter a number (-1 to quit): 
25
Smallest # so far: 4
Largest # so far: 100
Enter a number (-1 to quit): 
1
Smallest # so far: 1
Largest # so far: 100
Enter a number (-1 to quit): 
200
Smallest # so far: 1
Largest # so far: 200
Enter a number (-1 to quit): 
-1
```
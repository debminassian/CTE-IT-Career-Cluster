import java.util.Scanner;

public class StudentTester
{
    public static void main(String[] args)
    {
        // Prompt the user for name, test scores, and service hours
        
        
        // Create a HSStudent object
        
        // Print the results
    }
}

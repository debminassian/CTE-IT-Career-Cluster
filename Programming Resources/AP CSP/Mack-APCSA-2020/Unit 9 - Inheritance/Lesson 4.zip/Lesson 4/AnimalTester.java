public class AnimalTester
{
    public static void main(String[] args)
    {
        
        // Dog class extends the Animal class
        Dog karel = new Dog();
        
        // We can create a custom speak method for the Dog
        karel.bark(5);
    }
}

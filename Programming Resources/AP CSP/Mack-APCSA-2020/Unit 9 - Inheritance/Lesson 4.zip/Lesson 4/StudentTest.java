public class StudentTest 
{

    private int mathScore;
    private int elaScore;
    private String name;

    public StudentTest(String name, int mathScore, int elaScore){
       
    }

	public int getMathScore() {
	
	}

	public void setMathScore(int mathScore) {
		
	}

	public int getElaScore() {
	
	}

	public void setElaScore(int elaScore) {
		
	}

	public String getName() {
		
	}

}

# Click on the Example tab to see more info. -->
# <-- Click on the data.csv file to see the dataset.

import pandas as pd

df = pd.read_csv (r"data.csv")
pd.set_option("display.max_columns", None)

# list the statistical question
print("1. Which member of BTS is worth the most money") 
print("per pound (weight)?")

# create a function to find the net worth per weight
def worth_per_weight(worth, weight):
    return worth/weight

# use the function to create a new column with the calculations     
df['worth_per_weight'] = worth_per_weight(df["net_worth"], df["weight"])


# filter for name, net_worth, weight, and worth_per_weight 
print()
print("************************************************")
print()
print("BTS Info")
print("-------------------")
filtered_table = df[["name", "weight", "net_worth", "worth_per_weight"]]
print(filtered_table)

# find the maximum value in worth_per_weight
max_worth = df["worth_per_weight"].max()

print()
print("************************************************")
print()
print("The maximum value in the worth_per_weight column") 
print("is " + str(round(max_worth, 2)))

# filter for the row that contains the max_value
row_with_max_worth = filtered_table[df["worth_per_weight"] == max_worth]

print()

print(row_with_max_worth)

# print a conlusion statement
print()
print("************************************************")
print()
print("Conclusion: The member of BTS who is worth the") 
print("most per pound is J-Hope.")
       
       
# list the statistical question
print()
print("************************************************")
print()
print("2. Based on how many words each member sang or")
print("rapped, how much did each member contribute to") 
print("the total sales of their 2020 album BE?")
print()
print("Total Sales of BE were 3,437,000 units.")

# create a function to find the sales contribution
def sales_contribution(lines):
    return 3437000 * lines/100

# use the function to create a new column with the calculations     
df['sales_contribution'] = sales_contribution(df["line_distribution"])


# filter and print the table to display the name and the sales contribution
print()
print("************************************************")
print()
print("Sales Contribution")
print("-------------------")
filtered_table2 = df[["name", "sales_contribution"]]
print(filtered_table2)

# find the maximum value in worth_per_weight
max_sales = df["sales_contribution"].max()

print()
print("************************************************")
print()
print("The maximum value in the sales_contribution column")
print("is " + str(max_sales))

# filter for the row that contains the max_value
row_with_max_sales = filtered_table2[df["sales_contribution"] == max_sales]

print()
print()
print(row_with_max_sales)

# print a conlusion statement
print()
print("************************************************")
print()
print("Conclusion: The member of BTS who contributed to")
print("the most sales based on the number of words")
print("sang/rapped was Jungkook.")
# Click on the Assignment tab to see the instructions. -->
# <-- Click on the data.csv file to see the dataset.

import pandas as pd

df = pd.read_csv (r"data.csv")

print (df)
# imports the statistics and math libraries
import statistics
import math

# prints pi = 3.14...
print(math.pi)

# prints 2 to the third power (2^3) = 2 * 2 * 2
print()
print(math.pow(2,3))

cousins_ages = [8, 12, 14, 14, 15, 19, 22]

# prints the mean of the elements in cousins_ages
print()
print("Mean: " + str(statistics.mean(cousins_ages)))

# prints the median of the elements in cousins_ages
print("Median: " + str(statistics.median(cousins_ages)))

# prints the mode of the elements in cousins_ages
print("Mode: " + str(statistics.mode(cousins_ages)))

# prints the standard deviation of the elements in cousins_ages
std = statistics.stdev(cousins_ages)
print("Standard Deviation: " + str(std))

# drops the decimal (this is different than rounding)
print()
print("Using 'floor': " + str(math.floor(std)))

# round is built-in to python without using the math module
print("Using 'round': " + str(round(std, 2)))
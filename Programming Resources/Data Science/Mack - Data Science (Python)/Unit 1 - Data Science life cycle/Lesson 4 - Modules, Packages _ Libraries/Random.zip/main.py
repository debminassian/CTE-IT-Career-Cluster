# imports the library
import random

# prints a random float between 0 and 1
print(random.random())

# prints a random integer between 1 and 10
print(random.randint(1,10))

my_list = [2, 109, False, 10, "Lorem", 482, "Ipsum"]

# prints a random element from my_list
print(random.choice(my_list))
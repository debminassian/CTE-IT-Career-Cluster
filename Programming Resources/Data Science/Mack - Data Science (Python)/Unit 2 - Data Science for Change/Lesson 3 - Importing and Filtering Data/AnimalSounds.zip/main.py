# Click on the Assignment tab to see the instructions. -->
# <-- Click on the data.csv file to see the dataset.

import pandas as pd

# import the data from the data.csv file
df = pd.read_csv (r"data.csv")
pd.set_option("display.max_columns", None)


# Using loc - Print the row and animal columns for rows 3 to 6


# Using iloc - Print the row and animal columns for rows 3 to 6




# Using loc - Print the sound of the animal at index 7




# Using iloc - Print the sound of the animal at index 7


# Using loc - Print rows at index 8-10 


# Using iloc - Print rows at index 8-10
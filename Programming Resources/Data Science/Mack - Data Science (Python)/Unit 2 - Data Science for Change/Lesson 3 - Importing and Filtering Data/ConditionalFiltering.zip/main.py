# Click on the Example tab to see more info. -->
# <-- Click on the data.csv file to see the dataset.

import pandas as pd

df = pd.read_csv (r"data.csv")
pd.set_option("display.max_columns", None)

# selects the country and score columns for rows 
# whose score is greater than 7
print("Table 1 - Score > 7")
print("---------------------")
print(df.loc[(df.score > 7), ["country","score"]])

# selects the country, score and social support columns for rows 
# whose score is greater than 7 AND whose social support 
# is greater than 1.5
print()
print()
print("Table 2 - Score > 7 and Social Support > 1.5")
print("---------------------------------------------")
print(df.loc[(df.score > 7) & (df.social_support > 1.5) , ["country","score", "social_support"]])

# selects the country and score columns for rows 
# whose score is greater than 7 AND whose social support 
# is greater than 1.5
print()
print()
print("Table 3 - Score > 7 or Social Support > 1.5")
print("---------------------------------------------")
print(df.loc[(df.score > 7) | (df.social_support > 1.5) , ["country","score", "social_support"]])
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <cstdlib>
#include <cmath>
#include <dos.h>
#include <conio.h>
#include <windows.h>
#include <string>
#define black 0
#define dark_blue 1
#define green 2
#define cyan 3
#define red 4
#define dark_purple 5
#define brown 6
#define gray 7
#define dark_gray 8
#define blue 9
#define neon_green 10
#define light_blue 11
#define light_red 12
#define purple 13
#define yellow 14
#define white 15

using namespace std;

// Here's where all my functions are:

void Game(int intStartGame);

void StartMenu(int &intStartGame);

void CharacterMenu();

void CharacterInfo(int intCharacter);

void GetColor();

void Help();

void News();

void NameSelection(string &strYourName, string &strYourGirlfriendsName, string &strYourHamstersName);

void WorriesWithGirlfriend(string strYourName, string strYourGirlfriendsName, string strYourHamstersName);

void StayNormal(string strYourName, string strYourGirlfriendsName, string strYourHamstersName);

void ForeverChanged(string strYourName, string strYourGirlfriendsName, string strYourHamstersName);

int WokenUp();

void Loner(string strYourName, string strYourGirlfriendsName, int intAdvice);

void Advice(int &intAdvice, string strYourName, string strYourGirlfriendsName);

void Cut(int &intHeroism, int intAdvice);

void Day2(string strYourName, string strYourGirlfriendsName);

void Comfort(string strYourHamstersName, string strYourGirlfriendsName);

void Death(int &intDied);

void NeverBeTheSame(string strYourHamstersName, string strYourGirlfriendsName);

void PoliceChance(int &intPoliceChance, string strYourGirlfriendsName);

void ShootingPractice(string strYourGirlfriendsName);

void RulesAndRegulations(string strYourGirlfriendsName);

void CommunityHelp();

void Fire(string strYourGirlfriendsName, string strYourHamstersName);

void NameSelection2(string &strWeaselsName, string &strLlamasName);

void Walmart(string strWeaselsName, string strLlamasName, string strYourGirlfriendsName, string strYourHamstersName);

void Tutorial(string strWeaselsName, string strLlamasName, string strYourGirlfriendsName, string strYourName, string strYourHamstersName);

void FirstFight(string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, int &intStun1, int &intStun2, int &intStun3, int &intStunned, int &intYourLevel, int &intYourEXP, int &intAttack, int &intGFLevel, int &intGFEXP, int &intStunChance, int &intWeaselLevel, int &intWeaselEXP, int &intHitCount, int &intLlamaLevel, int &intLlamaEXP, int &intAccuracyLowered, int &intRecharge);

void FightHelp(string strWeaselsName, string strLlamasName, string strYourGirlfriendsName, string strYourName, string strYourHamstersName);

void CharactersMeet(string strWeaselsName, string strLlamasName, string strYourGirlfriendsName, string strYourName);

int YourFightMenu(int &intRecharge, int &intElecricShotgunCharge, int intAttack, int &intThug1HP, int &intThug2HP, int &intThug3HP, string strYourName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intYourHP, int intYourEXP, int intJello);

int GFFightMenu(int &intRecharge, int &intHairStraightenerCharge, int intStunChance, int &intStun1, int &intStun2, int &intStun3, string strYourGirlfriendsName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intGFHP, int intGFEXP, int intJello);

int WeaselFightMenu(int &intHitCount, int &intThug1HP, int &intThug2HP, int &intThug3HP, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intWeaselHP, int intWeaselEXP, int &intJello);

int LlamaFightMenu(int intAccuracyLowered, int &intThug1Accuracy, int &intThug2Accuracy, int &intThug3Accuracy, string strLlamasName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intLlamaHP, int intLlamaEXP, int intJello);

void MainDirection(int &intDirection);

void GoSouth();

void GoNorthWest(string strYourGirlfriendsName);

void GoNorth();

void Thug1(int intThug1HP, int intThug1Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName);

void Thug2(int intThug2HP, int intThug2Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName);

void Thug3(int intThug3HP, int intThug3Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName);

void Traveling(int intDirection, string strWeaselsName, string strLlamasName, string strYourGirlfriendsName, string strYourName, int &intRing);

void GirlfriendPet(string strWeaselsName, string strLlamasName, string strYourGirlfriendsName, string strYourName);

void Map1();

void WeaselPet(string strWeaselsName, string strLlamasName, string strYourGirlfriendsName, string strYourName);

void StopPetting(string strWeaselsName, string strLlamasName, string strYourGirlfriendsName, string strYourName);

void Proposal(string strYourGirlfriendsName, string strWeaselsName);

void Map2();

void KeepGoing();

void SellRing(string strYourGirlfriendsName, int &intRing);

void TalkAboutDream(string strWeaselsName, string strLlamasName, string strYourGirlfriendsName);

void Map3();

void StrangeDream(string strWeaselsName, string strLlamasName, string strYourGirlfriendsName);

void DreamLie(string strWeaselsName, string strYourGirlfriendsName);

void Crocodiles();

void BikerGang();

void Weasels();

void CrocFight(string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, int &intMommaCrocStun, int &intBabyCrocStun, int &intStunned, int &intYourLevel, int &intYourEXP, int &intAttack, int &intGFLevel, int &intGFEXP, int &intStunChance, int &intWeaselLevel, int &intWeaselEXP, int &intHitCount, int &intLlamaLevel, int &intLlamaEXP, int &intAccuracyLowered, int &intRecharge);

int YourCrocFightMenu(int &intRecharge, int &intElectricShotgunCharge, int intAttack, int &intMommaCrocHP, int &intBabyCrocHP, string strYourName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intYourHP, int intYourEXP, int intJello);

int GFCrocFightMenu(int &intRecharge, int &intHairStraightenerCharge, int intStunChance, int &intMommaCrocStun, int &intBabyCrocStun, string strYourGirlfriendsName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intGFHP, int intGFEXP, int intJello);

int WeaselCrocFightMenu(int &intHitCount, int &intMommaCrocHP, int &intBabyCrocHP, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intWeaselHP, int intWeaselEXP, int &intJello);

int LlamaCrocFightMenu(int intAccuracyLowered, int &intMommaCrocAccuracy, int &intBabyCrocAccuracy, string strLlamasName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intLlamaHP, int intLlamaEXP, int intJello);

void MommaCroc(int intMommaCrocHP, int intMommaCrocAccuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName);

void BabyCroc(int intBabyCrocHP, int intBabyCrocAccuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName);

void BikerFight(string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, int &intBiker1Stun, int &intBiker2Stun, int &intBiker3Stun, int &intBiker4Stun, int &intStunned, int &intYourLevel, int &intYourEXP, int &intAttack, int &intGFLevel, int &intGFEXP, int &intStunChance, int &intWeaselLevel, int &intWeaselEXP, int &intHitCount, int &intLlamaLevel, int &intLlamaEXP, int &intAccuracyLowered, int &intRecharge);

int YourBikerFightMenu(int &intRecharge, int &intElectricShotgunCharge, int intAttack, int &intBiker1HP, int &intBiker2HP, int &intBiker3HP, int &intBiker4HP, string strYourName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intYourHP, int intYourEXP, int intJello);

int GFBikerFightMenu(int &intRecharge, int &intHairStraightenerCharge, int intStunChance, int &intBiker1Stun, int &intBiker2Stun, int &intBiker3Stun, int &intBiker4Stun, string strYourGirlfriendsName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intGFHP, int intGFEXP, int intJello);

int WeaselBikerFightMenu(int &intHitCount, int &intBiker1HP, int &intBiker2HP, int &intBiker3HP, int &intBiker4HP, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intWeaselHP, int intWeaselEXP, int &intJello);

int LlamaBikerFightMenu(int intAccuracyLowered, int &intBiker1Accuracy, int &intBiker2Accuracy, int &intBiker3Accuracy, int &intBiker4Accuracy, string strLlamasName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intLlamaHP, int intLlamaEXP, int intJello);

void Biker1(int intBiker1HP, int intBiker1Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName);

void Biker2(int intBiker2HP, int intBiker2Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName);

void Biker3(int intBiker3HP, int intBiker3Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName);

void Biker4(int intBiker4HP, int intBiker4Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName);

void Weasels();

void WeaselFight(string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, int &intWeasel1Stun, int &intWeasel2Stun, int &intWeasel3Stun, int &intWeasel4Stun, int &intWeasel5Stun, int &intWeasel6Stun, int &intStunned, int &intYourLevel, int &intYourEXP, int &intAttack, int &intGFLevel, int &intGFEXP, int &intStunChance, int &intWeaselLevel, int &intWeaselEXP, int &intHitCount, int &intLlamaLevel, int &intLlamaEXP, int &intAccuracyLowered, int &intRecharge);

int YourWeaselFightMenu(int &intRecharge, int &intElectricShotgunCharge, int intAttack, int &intWeasel1HP, int &intWeasel2HP, int &intWeasel3HP, int &intWeasel4HP, int &intWeasel5HP, int &intWeasel6HP, string strYourName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intYourHP, int intYourEXP, int intJello);

int GFWeaselFightMenu(int &intRecharge, int &intHairStraightenerCharge, int intStunChance, int &intWeasel1Stun, int &intWeasel2Stun, int &intWeasel3Stun, int &intWeasel4Stun, int &intWeasel5Stun, int &intWeasel6Stun, string strYourGirlfriendsName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intGFHP, int intGFEXP, int intJello);

int WeaselWeaselFightMenu(int &intHitCount, int &intWeasel1HP, int &intWeasel2HP, int &intWeasel3HP, int &intWeasel4HP, int &intWeasel5, int &intWeasel6, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intWeaselHP, int intWeaselEXP, int &intJello);

int LlamaWeaselFightMenu(int intAccuracyLowered, int &intWeasel1Accuracy, int &intWeasel2Accuracy, int &intWeasel3Accuracy, int &intWeasel4Accuracy, int &intWeasel5Accuracy, int &intWeasel6Accuracy, string strLlamasName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intLlamaHP, int intLlamaEXP, int intJello);

void Weasel1(int intWeasel1HP, int intWeasel1Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName);

void Weasel2(int intWeasel2HP, int intWeasel2Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName);

void Weasel3(int intWeasel3HP, int intWeasel3Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName);

void Weasel4(int intWeasel4HP, int intWeasel4Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName);

void Weasel5(int intWeasel5HP, int intWeasel5Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName);

void Weasel6(int intWeasel6HP, int intWeasel6Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName);

void GovernmentEnding();

void DirectEnding();

void BoatEnding();

int intStartGame;
int intHeroism;
int intAdvice;
int intPoliceChance;
int intDied = 0;
int intRing = 0;

int intYourLevel = 1;
int intGFLevel = 1;
int intWeaselLevel = 1;
int intLlamaLevel = 1;

int intAttack = 2;
int intYourHP = 15;
int intYourEXP = 400;
int intElectricShotgunCharge = 5;

int intStunChance = 1;
int intGFHP = 15;
int intGFEXP = 400;
int intHairStraightenerCharge = 10;

int intHitCount = 1;
int intWeaselHP = 15;
int intWeaselEXP = 400;
int intJello = 1;

int intAccuracyLowered = 1;
int intLlamaHP = 15;
int intLlamaEXP = 400;

int intMoney = 0;
int intRecharge = 0;
int intBlanket = 1;

int intThug1HP = 10;
int intThug2HP = 10;
int intThug3HP = 10;
int intThug1Accuracy = 10;
int intThug2Accuracy = 10;
int intThug3Accuracy = 10;
int intStunned = 0;
int intStun1 = 0;
int intStun2 = 0;
int intStun3 = 0;

int intDirection;

int intMommaCrocHP = 20;
int intBabyCrocHP = 15;
int intMommaCrocAccuracy = 10;
int intBabyCrocAccuracy = 10;
int intMommaCrocStun = 0;
int intBabyCrocStun = 0;

int intBiker1HP = 12;
int intBiker2HP = 12;
int intBiker3HP = 12;
int intBiker4HP = 12;
int intBiker1Accuracy = 10;
int intBiker2Accuracy = 10;
int intBiker3Accuracy = 10;
int intBiker4Accuracy = 10;
int intBiker1Stun = 0;
int intBiker2Stun = 0;
int intBiker3Stun = 0;
int intBiker4Stun = 0;

int intWeasel1HP = 5;
int intWeasel2HP = 5;
int intWeasel3HP = 5;
int intWeasel4HP = 5;
int intWeasel5HP = 5;
int intWeasel6HP = 5;
int intWeasel1Accuracy = 10;
int intWeasel2Accuracy = 10;
int intWeasel3Accuracy = 10;
int intWeasel4Accuracy = 10;
int intWeasel5Accuracy = 10;
int intWeasel6Accuracy = 10;
int intWeasel1Stun = 0;
int intWeasel2Stun = 0;
int intWeasel3Stun = 0;
int intWeasel4Stun = 0;
int intWeasel5Stun = 0;
int intWeasel6Stun = 0;

string strYourName;
string strYourGirlfriendsName;
string strYourHamstersName;
string strWeaselsName;
string strLlamasName;

//Start of int Main, it was very short.
int main()
{

Game(intStartGame);

return 0;
}

void Game(int intStartGame)
{

    while (intStartGame != 4)
    {

    StartMenu(intStartGame);

        if (intStartGame == 4)
        {
        system("CLS");
        exit(0);
        }

        while (intDied != 1)
        {

            if (intStartGame != 4)
            {
                if (intDied == 0)
                {
                NameSelection(strYourName, strYourGirlfriendsName, strYourHamstersName);
                }
                if (intDied == 0)
                {
                WorriesWithGirlfriend(strYourName, strYourGirlfriendsName, strYourHamstersName);
                }
                if (intDied == 0)
                {
                intHeroism = WokenUp();
                }
                if (intDied == 0)
                {
                Day2(strYourName, strYourGirlfriendsName);
                }
                if (intDied == 0)
                {
                Fire(strYourHamstersName, strYourGirlfriendsName);
                }
                if (intDied == 0)
                {
                NameSelection2(strWeaselsName, strLlamasName);
                }
                if (intDied == 0)
                {
                Walmart(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourHamstersName);
                }
                intDied = 0;
            }
        }
    }

system("CLS");

}

//Start of Start Menu, it might be a good idea to send people back here if they fail the game.

void StartMenu(int &intStartGame)
{
system("CLS");

cout << "    ____________     __        __     ____________          __        __     ____________      __________      ____________     ____________     __            " << endl;
cout << "   |____    ____|   |  |      |  |   |   _________|        |  |      |  |   |   _________|    /  ______  \\    |    ________|   |   _________|   |  |          " << endl;
cout << "        |  |        |  |      |  |   |  |                  |  |      |  |   |  |             |  |      |  |   |   |            |  |             |  |           " << endl;
cout << "        |  |        |  |______|  |   |  |_________         |  |  __  |  |   |  |_________    |  |______|  |   |   |________    |  |_________    |  |           " << endl;
cout << "        |  |        |   ______   |   |   _________|        |  | |  | |  |   |   _________|   |   ______   |   |________    |   |   _________|   |  |           " << endl;
cout << "        |  |        |  |      |  |   |  |                  |  | |  | |  |   |  |             |  |      |  |            |   |   |  |             |  |           " << endl;
cout << "        |  |        |  |      |  |   |  |_________         |  |_|  |_|  |   |  |_________    |  |      |  |    ________|   |   |  |_________    |  |_________  " << endl;
cout << "        |__|        |__|      |__|   |____________|        |____________|   |____________|   |__|      |__|   |____________|   |____________|   |____________| " << endl;


cout << endl;
cout << endl;
cout << endl;


cout << "    ____________     ____________     __                    ____________     ____________     ____________     ____________     ____________     ____________  " << endl;
cout << "   |    ____    |   |____    ____|   |  |                  |   _________|   |   _________|   |____    ____|   |    ________|   |____    ____|   |    ________| " << endl;
cout << "   |   |    |   |        |  |        |  |                  |  |             |  |                  |  |        |   |                 |  |        |   |          " << endl;
cout << "   |   |    |   |        |  |        |  |                  |  |             |  |                  |  |        |   |________         |  |        |   |________  " << endl;
cout << "   |   |    |   |        |  |        |  |                  |  |             |  |                  |  |        |________    |        |  |        |________    | " << endl;
cout << "   |   |    |   |        |  |        |  |                  |  |             |  |                  |  |                 |   |        |  |                 |   | " << endl;
cout << "   |   |____|   |    ____|  |____    |  |_________         |  |_________    |  |              ____|  |____     ________|   |    ____|  |____     ________|   | " << endl;
cout << "   |____________|   |____________|   |____________|        |____________|   |__|             |____________|   |____________|   |____________|   |____________| " << endl;


cout << endl;
cout << endl;
cout << endl;
cout << endl;


cout << "                                                     ////^\\\\\\\\                              ., _                                                           " << endl;
cout << "                                                     | ^   ^ |                             /     \\                                                            " << endl;
cout << "       (\\~?~/).                                     @ (@) (@) @                           ((|)))))                                                            " << endl;
cout << "       .'^  ' )                                      |   <   |                             ((/ @ @)                                                            " << endl;
cout << "    __/,(@  (. )                                     | \\__/  |                             )))   >))                                                          " << endl;
cout << "   (_ _ '    ).)                                      \\_____/                             ((((\\__/((                                                         " << endl;
cout << "    (:-'-,-' ,)                                     ____|  |____                         ,--/ (-.                                                              " << endl;
cout << "     '~~ ). ,)                                     /    \\__/    \\                       / \\ <\\/>/|                                                         " << endl;
cout << "        ((  (                                     /              \\                     / /)   V )|                                                            " << endl;
cout << "        )) ,)                 '                  /\\_/|        |\\_/\\                   / / )    / |                                                          " << endl;
cout << "       (.  (                 &                  / /  |        |  \\ \\                 |   /    ( /                                                            " << endl;
cout << "       )   )                )(                 ( <   |        |   > )                |  /     ;/                                                               " << endl;
cout << "      (  (. )~.~.~.!;,;,;,;,()&                 \\ \\  |        |  / /                 ||(      |                                                              " << endl;
cout << "      )  ) )  )';'.,)       .  )                _\\ \\ |________| / /_                / )|/|    \\                           _,-/'---,                         " << endl;
cout << "      ( .(    (  '     .       ')              (    @|   |    |@    )              |/'/\\ \\_____\\                        _/;; ''  <@`---v                    " << endl;
cout << "       )  (    ).              .)               %%%% |   |    | %%%%                    \\   |  \\                      _/ ;;  '    _.../                      " << endl;
cout << "       ((  ). (     .   (   .   )                    |   |    |                          \\  |\\  \\                  __/::    ;;,'''''                        " << endl;
cout << "        )) (      .    (  (     )                    |   |    |                          |  | )  )                {           /                                " << endl;
cout << "        ((  )  )    ,_( .  ) . )                     |   |    |                           )  )/  /                 {_      '')/                                " << endl;
cout << "        ( ( .   )''' (.(   (  )                      |___|____|                          /  /   /                  {          \\;;\\''=                        " << endl;
cout << "         ) )   )      ) ( . ) )                      |  |  |  |                         /   |  /                   {           \\\\\\'''=                      " << endl;
cout << "         (*~(**)      (**~(  )                       (  (  (  (                        /    | /              ;'''';{           /                               " << endl;
cout << "         |~||~|        | ||~|                        |  |  |  |                       /     ||              \\/''' {          /                                " << endl;
cout << "         | || |        | || |                        |  |  |  |                      /      ||                     /;;V_;; ;;;                                 " << endl;
cout << "         \\ /\\ /        \\ /\\ /                        |  |  |  |                       '-,_  |_\\                     | :/ / ,/                             " << endl;
cout << "         (_)\\ /        (_) \\\\                       _|  | _|  |                         ( ''-`                      | | / /'''=                             " << endl;
cout << "             (_)           (_)                     (____|(____|                          \\(\\_\\                      ; ;{::'''''=                            " << endl;
cout << endl;
cout << endl;

cout << "Choose one of the following:" << endl;
cout << "(1) Start Game     " << endl;
cout << "(2) Character Info " << endl;
cout << "(3) Color Selection" << endl;
cout << "(4) Exit Game" << endl;
cout << endl;
cin >> intStartGame;

//This is basically a menu selection screen

    if (intStartGame == 1)
    {
    News();
    }

    if (intStartGame == 2)
    {
    CharacterMenu();
    }

    if (intStartGame == 3)
    {
    GetColor();
    }

}

//Start of Character Menu, this is where they pick a character to learn more about. If you add any characters and want to add them in feel free.

void CharacterMenu()
{
system("CLS");

int intCharacter;

cout << "Select The Character To Learn Their Backstories:" << endl;
cout << endl;
cout << "(1) LLama          " << endl;
cout << "(2) You            " << endl;
cout << "(3) Your Girlfriend" << endl;
cout << "(4) Weasel         " << endl;
cout << "(5) Exit           " << endl;
cout << endl;

cin >> intCharacter;
CharacterInfo(intCharacter);
}

//Start of Character Info, feel free to add more as you develop the characters or add new ones if you want.

void CharacterInfo(int intCharacter)
{
system("CLS");
char chrSpoiler;
    if (intCharacter == 1)
    {
    cout << "This will contain Minor Spoilers for Chapter 1, Continue? (Y/N)" << endl;
    cin >> chrSpoiler;
    chrSpoiler = toupper(chrSpoiler);
        if (chrSpoiler == 'N')
        {
        CharacterMenu();
        }
        if (chrSpoiler == 'Y')
        {
        system("CLS");
        cout << "This is a Female llama, She is telepathically connected to the Weasel. She has no" << endl;
        cout << "way to communicate besides trying to get the Weasel to communicate what she's    " << endl;
        cout << "saying, and he isn't always cooperative. She also starts developing different    " << endl;
        cout << "abilities along the way." << endl;
        cout << endl;
        system("Pause");
        CharacterMenu();
        }
    }

    if (intCharacter == 2)
    {
    cout << "This will contain Minor Spoilers for Chapter 1, Continue? (Y/N)" << endl;
    cin >> chrSpoiler;
    chrSpoiler = toupper(chrSpoiler);
        if (chrSpoiler == 'N')
        {
        CharacterMenu();
        }
        if (chrSpoiler == 'Y')
        {
        system("CLS");
        cout << "This is you, You are a man in your early 30s. You have been dating your current" << endl;
        cout << "Girlfriend for a few years and are ready to propose. You live in Florida with  " << endl;
        cout << "your Girlfriend and Hamster. You work as a computer programmer and when all is " << endl;
        cout << "going well, The Weasel Oil Crisis occurs..." << endl;
        cout << endl;
        system("Pause");
        CharacterMenu();
        }
    }

    if (intCharacter == 3)
    {
    cout << "This will contain Minor Spoilers for Chapter 1, Continue? (Y/N)" << endl;
    cin >> chrSpoiler;
    chrSpoiler = toupper(chrSpoiler);
        if (chrSpoiler == 'N')
        {
        CharacterMenu();
        }
        if (chrSpoiler == 'Y')
        {
        system("CLS");
        cout << "This is your Girlfriend, she is kind and supportive. You two met when you were   " << endl;
        cout << "young. She loves animals and anything furry and soft especially your pet hamster." << endl;
        cout << "But despite her usual kind nature, when she gets mad or upset, she really gets   " << endl;
        cout << "mad and upset." << endl;
        cout << endl;
        system("Pause");
        CharacterMenu();
        }
    }

    if (intCharacter == 4)
    {
    cout << "This will contain Minor Spoilers for Chapter 1, Continue? (Y/N)" << endl;
    cin >> chrSpoiler;
    chrSpoiler = toupper(chrSpoiler);
        if (chrSpoiler == 'N')
        {
        CharacterMenu();
        }
        if (chrSpoiler == 'Y')
        {
        system("CLS");
        cout << "The Weasel, or at least he is now. He used to be a man in his early 50s before " << endl;
        cout << "The Weasel Oil Crisis. He worked on an Oil Drilling Platform, he had a wife and" << endl;
        cout << "kid who left him years ago and hasn't really found any sort of 'Family' since. " << endl;
        cout << "But despite him having a Hard attitude on the inside he has a Soft heart and   " << endl;
        cout << "deep down just wants to be loved." << endl;
        cout << endl;
        system("Pause");
        CharacterMenu();
        }
    }

    if (intCharacter == 5)
    {
    StartMenu(intStartGame);
    }
}

//This is a Menu where you can change the color of the text.

void GetColor()
{
system("CLS");

string strColor;

cout << "Choose Your Color:" << endl;
cout << "Type 'Help' For Help" << endl;
cout << endl;
cin >> strColor;

    if (strColor == "Help")
    {
    Help();
    }

    else if (strColor == "Black")
    {
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hStdOut, 0);
    StartMenu(intStartGame);
    }

    else if (strColor == "DarkBlue")
    {
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hStdOut, 1);
    StartMenu(intStartGame);
    }

    else if (strColor == "Green")
    {
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hStdOut, 2);
    StartMenu(intStartGame);
    }

    else if (strColor == "Cyan")
    {
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hStdOut, 3);
    StartMenu(intStartGame);
    }

    else if (strColor == "Red")
    {
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hStdOut, 4);
    StartMenu(intStartGame);
    }

    else if (strColor == "DarkPurple")
    {
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hStdOut, 5);
    StartMenu(intStartGame);
    }

    else if (strColor == "Brown")
    {
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hStdOut, 6);
    StartMenu(intStartGame);
    }

    else if (strColor == "Gray")
    {
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hStdOut, 7);
    StartMenu(intStartGame);
    }

    else if (strColor == "DarkGray")
    {
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hStdOut, 8);
    StartMenu(intStartGame);
    }

    else if (strColor == "Blue")
    {
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hStdOut, 9);
    StartMenu(intStartGame);
    }

    else if (strColor == "NeonGreen")
    {
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hStdOut, 10);
    StartMenu(intStartGame);
    }

    else if (strColor == "LightBlue")
    {
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hStdOut, 11);
    StartMenu(intStartGame);
    }

    else if (strColor == "LightRed")
    {
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hStdOut, 12);
    StartMenu(intStartGame);
    }

    else if (strColor == "Purple")
    {
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hStdOut, 13);
    StartMenu(intStartGame);
    }

    else if (strColor == "Yellow")
    {
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hStdOut, 14);
    StartMenu(intStartGame);
    }

    else if (strColor == "White")
    {
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hStdOut, 15);
    StartMenu(intStartGame);
    }

    else
    {
    system("CLS");
    cout << "Incorrect color or it was spelled wrong please try again." << endl;
    system("Pause");
    system("CLS");
    GetColor();
    }
}

void Help()
{
system("CLS");

cout << "Type 'Black' for Black            " << endl;
cout << "Type 'DarkBlue' for Dark Blue     " << endl;
cout << "Type 'Green' for Green            " << endl;
cout << "Type 'Cyan' for Cyan              " << endl;
cout << "Type 'Red' for Red                " << endl;
cout << "Type 'DarkPurple' for Dark Purple " << endl;
cout << "Type 'Brown' for Brown            " << endl;
cout << "Type 'Gray' for Gray              " << endl;
cout << "Type 'DarkGray' for Dark Gray     " << endl;
cout << "Type 'Blue' for Blue              " << endl;
cout << "Type 'NeonGreen' for Neon Green   " << endl;
cout << "Type 'LightBlue' for Light Blue   " << endl;
cout << "Type 'LightRed' for Light Red     " << endl;
cout << "Type 'Purple' for Purple          " << endl;
cout << "Type 'Yellow' for Yellow          " << endl;
cout << "Type 'White' for White            " << endl;

system("Pause");
system("CLS");
GetColor();
}

//This is the start of the actual story, starting off with the News introducing the idea.

void News()
{
system("CLS");

int intNews;

cout << "Hello this is Florida Channel 9 News, we now have a major story on our hands.   " << endl;
cout << "On Oil Rigs across the world, anyone who gets touched by newly drilled oil      " << endl;
cout << "has been mysteriously turning into Weasels. Effective immediately, The President" << endl;
cout << "has ordered all gas stations to stop selling any form of gas. And ordered all   " << endl;
cout << "Oil Rigs to stop drilling, but hundreds have already been affected. We will now " << endl;
cout << "transfer to The Presidents' speech on the topic, but I will leave you with this:" << endl;
cout << "What in the world could have caused something like this..." << endl;
cout << endl;
cout << endl;
cout << "Shut off the TV or keep listening?" << endl;
cout << "(1) Shut off the TV" << endl;
cout << "(2) Keep Listening " << endl;
cout << endl;
cin >> intNews;

    if (intNews == 2)
    {

    system("CLS");

    cout << "This is The President speaking, today we have had an accident like no other.      " << endl;
    cout << "Even after 9/11 we knew what happened and how. Today is different, today we       " << endl;
    cout << "are left wondering, wondering how this happened, is there any solutions, and      " << endl;
    cout << "how will this affect us today? I don't have many answers for you but I will       " << endl;
    cout << "say this, I am here as your elected leader, i will do anything to keep this       " << endl;
    cout << "great country together and prospering. I know this is a controversial decision    " << endl;
    cout << "but starting today and until further notice, there will be no further selling     " << endl;
    cout << "or manufacturing of oil or gas in any form. I will be stopping all evictions      " << endl;
    cout << "of any form, in case people don't have another form of transportation. And I      " << endl;
    cout << "will be taking all the federal funding intended for oil and gas manufacturing     " << endl;
    cout << "and putting it towards a massive increase in electrical public transportation     " << endl;
    cout << "We advise against any driving, or anything else that can possibly expose you      " << endl;
    cout << "to oil or gas of any kind, but we understand that accidents happen. We have       " << endl;
    cout << "created a national hotline if you are exposed and transformed into a Weasel.      " << endl;
    cout << "This hotline is 1-800-I-AM-A-WEASEL, i repeat that is 1-800-I-AM-A-WEASEL.        " << endl;
    cout << "Before i go i advise everyone to stay calm, we will all get through this together." << endl;
    cout << endl;
    system("Pause");
    }
}

void NameSelection(string &strYourName, string &strYourGirlfriendsName, string &strYourHamstersName)
{
system("CLS");
cout << "Enter your Name: " << endl;
cin >> strYourName;

    if (strYourName == "Default")
    {

    strYourName = "Jimmy";

    }

system("CLS");
cout << "Enter your Girlfriends name: " << endl;
cin >> strYourGirlfriendsName;

    if (strYourGirlfriendsName == "Default")
    {

    strYourGirlfriendsName = "Marie";

    }

system("CLS");
cout << "Enter your Hamsters name: " << endl;
cin >> strYourHamstersName;

    if (strYourHamstersName == "Default")
    {

    strYourHamstersName = "Harry";
    }

}

void WorriesWithGirlfriend (string strYourName, string strYourGirlfriendsName, string strYourHamstersName)
{
system("CLS");

int FutureBeliefs;

cout << "You Shut off the TV and are sitting on the couch with " << strYourGirlfriendsName << ", she is holding " << strYourHamstersName << " and cuddling with him." << endl;
cout << "You tell her how much this worries you and you think that many people are going to start hurting each other." << endl;
cout << "She tells you that the government has a plan to keep everything under control and this will go back to normal soon." << endl;
cout << endl;
cout << endl;
cout << "What do you think will happen:" << endl;
cout << "(1) She's right this wont be a big deal" << endl;
cout << "(2) The world is gonna be forever changed" << endl;
cout << endl;
cin >> FutureBeliefs;

    if (FutureBeliefs == 1)
    {
    StayNormal(strYourName, strYourGirlfriendsName, strYourHamstersName);
    }

    if (FutureBeliefs == 2)
    {
    ForeverChanged (strYourName, strYourGirlfriendsName, strYourHamstersName);
    }
}

void StayNormal(string strYourName, string strYourGirlfriendsName, string strYourHamstersName)
{
system("CLS");

cout << "You respond telling her that she's right there's no way that this can last after all we recovered from 9/11." << endl;
cout << "And you tell her that you, " << strYourGirlfriendsName << " and " << strYourHamstersName << " will all be ok. She says 'I love you, " << strYourName << "' and hugs you." << endl;
cout << "Your hopeful that everything will all be ok. You put " << strYourHamstersName << " back in his cage and go to bed for the night." << endl;
cout << "You feel less worried and stressed, you''ll get through this." << endl;
cout << endl;

system("Pause");
}

void ForeverChanged(string strYourName, string strYourGirlfriendsName, string strYourHamstersName)
{
system("CLS");

cout << "You tell your girlfriend that you don't think that things will ever go back to the way they are. Unlike any other" << endl;
cout << "major event nobody knows why this happened or how. People had a huge change in their lives in an instant that will" << endl;
cout << "forever change the way we view science, one thing randomly turned into another with no logical explanation. She changes" << endl;
cout << "her mind and agrees with you, maybe things wont be the same as the way that they were. She puts " << strYourHamstersName << " in his cage" << endl;
cout << "for the night and you two go to bed worried about what the future may hold, how many more tomorrows will there be." << endl;
cout << endl;

system("Pause");
}

int WokenUp()
{
system("CLS");

int intStopCriminals;

cout << "You are woken up to the sound of rioters and looters outside, theres a local gas station up the street. You see many people" << endl;
cout << "acting like animals, breaking and destroying anything. They want to take everything they can for themselves, thinking it's" << endl;
cout << "gonna be the end of the world. You start to wonder if they're right..." << endl;
cout << endl;
cout << endl;
cout << "What will you do?" << endl;
cout << "(1) Stop them alone" << endl;
cout << "(2) Wake up your Girlfriend and get her opinion" << endl;
cout << "(3) Leave it alone and go back to bed" << endl;
cout << endl;
cin >> intStopCriminals;

    if (intStopCriminals == 1)
    {
    Loner(strYourName, strYourGirlfriendsName, intAdvice);
    }

    if (intStopCriminals == 2)
    {
    Advice(intAdvice, strYourName, strYourGirlfriendsName);
    }

    if (intStopCriminals == 3)
    {
    Cut(intHeroism, intAdvice);
    }
return intStopCriminals;
}

void Loner(string strYourName, string strYourGirlfriendsName, int intAdvice)
{
    if (intAdvice != 1)
    {
    system("CLS");

    cout << "You go out and walk down the road, with your Electric Shotgun, just in case you need it. You hope that these people will just" << endl;
    cout << "stop and go home. Your tired and don't want anyone including yourself to get hurt. You walk up to one of them and ask them to" << endl;
    cout << "stop and go home. They pull out different knives and guns and say 'Do you think your the boss of us? Don't you go around acting" << endl;
    cout << "like you can just tell people what to do' Your scared, you don't want to get hurt you were just trying to do the right thing." << endl;
    cout << "You slowly back up and they fire a warning shot a few feet from you. Another one Shouts 'What are you crazy? We ain't trying to" << endl;
    cout << "get caught! Come on boys let's get out of here.' They grab a bag full of stuff and walk away, they throw a glass bottle on the ground" << endl;
    cout << "and say 'Don't you ever come back thinkin your the boss of us! Got That?' You nod and start walking away. You walk back home shaking" << endl;
    cout << strYourGirlfriendsName << " runs up to you and gives you a huge hug, '" << strYourName << " you had me worried sick!, i heard the gunshots and woke up thinking you..." << endl;
    cout << "Just promise me you'll never do anything like that again?' You respond 'Yea i promise, let's try to get some sleep.' You say exhaustedly." << endl;
    cout << endl;

    system("Pause");
    }

    if (intAdvice == 1)
    {
    cout << "You go out and walk down the road, with your Electric Shotgun, just in case you need it. You hope that these people will just" << endl;
    cout << "stop and go home. Your tired and don't want anyone including yourself to get hurt. You walk up to one of them and ask them to" << endl;
    cout << "stop and go home. They pull out different knives and guns and say 'Do you think your the boss of us? Don't you go around acting" << endl;
    cout << "like you can just tell people what to do' Your scared, you don't want to get hurt you were just trying to do the right thing." << endl;
    cout << "You slowly back up and they fire a warning shot a few feet from you. Another one Shouts 'What are you crazy? We ain't trying to" << endl;
    cout << "get caught! Come on boys let's get out of here.' They grab a bag full of stuff and walk away, they throw a glass bottle on the ground" << endl;
    cout << "and say 'Don't you ever come back thinkin your the boss of us! Got That?' You nod and start walking away. You walk back home shaking" << endl;
    cout << strYourGirlfriendsName << " runs up to you and gives you a huge hug, '" << strYourName << " thank god your ok, i heard the gunshots and got so scared" << endl;
    cout << "I thought that i had killed you, I'm so sorry.' You respond 'it's ok, let's just try to get some sleep.' You say exhaustedly." << endl;
    cout << endl;

    system("Pause");
    }
}

void Advice(int &intAdvice, string strYourName, string strYourGirlfriendsName)
{
system("CLS");
srand(static_cast<int>(time(0)));
intAdvice = 1 + rand()%(3);

    if (intAdvice == 1)
    {
    cout << strYourGirlfriendsName << " tells you that you should go out and try to get them to stop. She tells you to be careful but still help stop bad people." << endl;

    Loner(strYourName, strYourGirlfriendsName, intAdvice);
    }

    if (intAdvice == 2)
    {
    cout << "She tells you not to worry about it it should be fine. They will probably leave you alone. She tells you to just try to get some sleep it's late." << endl;

    Cut(intHeroism, intAdvice);
    }

    if (intAdvice == 3)
    {
    system("CLS");

    cout << "She tells you to call the police. You call them and after waiting on hold for about 20 minutes. They tell you that they" << endl;
    cout << "have been getting hundreds of calls just like this. Not only are people all around the world taking advantage of this" << endl;
    cout << "event, but theres also been a huge amount of targeted attacks towards people that have been referred to as 'Weasel people'." << endl;
    cout << "They are being blamed for The President stopping all oil and gas. They say that they could really use all the help they can" << endl;
    cout << "get because this is happening Nationwide. But you feel like it's too much of a risk. You go to bed hoping to get some rest" << endl;
    cout << endl;
    system("Pause");
    }
}

void Cut(int &intHeroism, int intAdvice)
{
    if (intAdvice != 2)
    {

    system("CLS");

    intHeroism += 1;

    cout << "You do nothing and go back to bed. You hope that this will all blow over. Unfortunately this is not the case, they keep" << endl;
    cout << "Destroying the gas station, and it sounds like they are getting closer. There's a few houses between you and them but " << endl;
    cout << "you hear banging on your door. You try to grab your Electric Shotgun but they bust in before you can grab it. They slash" << endl;
    cout << "your hand with a knife. You have a huge cut on your hand and fall to the ground in pain. " << strYourGirlfriendsName << " grabs a towel and wraps your hand." << endl;
    cout << "They take whatever they want, first your wallets and then they grab your TV and load it into their truck. Eventually you" << endl;
    cout << "stop bleeding, and are able to get a few hours of sleep before you have to go to work the next day." << endl;
    cout << endl;
    system("Pause");
    }

    if (intAdvice == 2)
    {

    intHeroism += 1;

    cout << "You do nothing and go back to bed. You hope that this will all blow over. Unfortunately this is not the case, they keep" << endl;
    cout << "Destroying the gas station, and it sounds like they are getting closer. There's a few houses between you and them but " << endl;
    cout << "you hear banging on your door. You try to grab your Electric Shotgun but they bust in before you can grab it. They slash" << endl;
    cout << "your hand with a knife. You have a huge cut on your hand and fall to the ground in pain. " << strYourGirlfriendsName << " grabs a towel and wraps your hand." << endl;
    cout << "They take whatever they want, first your wallets and then they grab your TV and load it into their truck. Eventually you" << endl;
    cout << "stop bleeding, and are able to get a few hours of sleep before you have to go to work the next day." << endl;
    cout << endl;
    system("Pause");
    }

}

void Day2(string strYourName, string strYourGirlfriendsName)
{
system("CLS");

int intWorldsFate;

cout << "You wake up after only a few hours of sleep last night. You take a shower and try to calm down after a long night of stress. You walk out the door" << endl;
cout << "only to get a phone call from your boss. 'Sorry " << strYourName << " we are shutting down, with all the chaos going on we cannot keep up, our products are" << endl;
cout << "getting stolen and we have no transportation.' You walk back in and tell " << strYourGirlfriendsName << " about what happened. She is worried about whats happening to the world." << endl;
cout << endl;
cout << endl;
cout << "How will you Respond?" << endl;
cout << "(1) Comfort her, and tell her it'll be ok" << endl;
cout << "(2) Tell her you agree it won't be normal again" << endl;
cout << "(3) Suggest helping the police deal with this" << endl;
cout << endl;
cin >> intWorldsFate;

    if (intWorldsFate == 1)
    {
    Comfort(strYourHamstersName, strYourGirlfriendsName);
    }

    if (intWorldsFate == 2)
    {
    NeverBeTheSame(strYourHamstersName, strYourGirlfriendsName);
    }

    if (intWorldsFate == 3)
    {
    PoliceChance(intPoliceChance, strYourGirlfriendsName);
    }
}

void Comfort(string strYourHamstersName, string strYourGirlfriendsName)
{
system("CLS");

int intFood;

cout << "You sit on the couch with her and tell her it'll be ok. You pull " << strYourHamstersName << " out of his cage, and start playing with him." << endl;
cout << "You put him in a big plastic ball and watch where he goes. This helps distract her from all the chaos. You feed " << strYourHamstersName << endl;
cout << "some Jell-O, remembering how crazy it makes him. You two laugh together as he runs around and starts running into walls and runs under" << endl;
cout << "the bottom of the couch. You take him out of the plastic ball and put him back into his cage. He starts running on his hamster wheel and" << endl;
cout << "you see it create a spark. You realize your hungry and want to cook lunch." << endl;
cout << endl;
cout << endl;
cout << "What will you eat?" << endl;
cout << "(1) Pizza" << endl;
cout << "(2) Cheeseburger" << endl;
cout << "(3) " << strYourHamstersName << endl;
cout << endl;
cin >> intFood;

    if (intFood == 1)
    {
    system("CLS");

    cout << "You put a pizza in the oven and wait for it to be done cooking." << endl;
    cout << "You play a game on your phone while you wait. 'Hey " << strYourGirlfriendsName << " I'm cooking pizza," << endl;
    cout << "do you want some too?' She responds 'Sure!' It finishes cooking and" << endl;
    cout << "you put some on a plate for her and hand it to her. You watch some TV while you eat." << endl;
    cout << endl;
    system("Pause");
    }

    if (intFood == 2)
    {
    system("CLS");

    cout << "You start up the burners and place a metal tray on the stove." << endl;
    cout << "You put the patties on the tray '" << strYourGirlfriendsName << " do you want a Cheeseburger?'" << endl;
    cout << "She responds 'Actually, do you mind putting a Pizza in the oven for me?'" << endl;
    cout << "'Sure, I can do that.' You say. You finish cooking up all the food" << endl;
    cout << "you put some on a plate for her and hand it to her. You watch some TV while you eat." << endl;
    cout << endl;
    system("Pause");
    }

    if (intFood == 3)
    {
    system("CLS");

    cout << "You take " << strYourHamstersName << " out of his cage and turn the burners on." << endl;
    cout << strYourGirlfriendsName << " pulls out your Electric Shotgun and asks you" << endl;
    cout << "'What the hell are you doing?' and shoots you in the head." << endl;
    cout << endl;
    cout << endl;
    cout << "You Died!" << endl;
    cout << endl;
    system("Pause");
    Death(intDied);
    }
}

void Death(int &intDied)
{
system("CLS");

cout << "                                                                                                    _,.-----.,_               " << endl;
cout << "                                                                                                 ,-~           ~-.            " << endl;
cout << "                                                                                                ,^___           ___^.         " << endl;
cout << "                                                                                              /~'   ~'   .   '~   '~\\        " << endl;
cout << "                                                                                             Y  ,--._    I    _.--.  Y        " << endl;
cout << "                                                                                              | Y     ~-. | ,-~     Y |       " << endl;
cout << "                                                                                              | |        }:{        | |       " << endl;
cout << "                                                                                              j l       / | \\       ! l      " << endl;
cout << "                                                                                           .-~  (__,.--' .^. '--.,__)  ~-.    " << endl;
cout << "                                                                                          (           / / | \\ \\           ) " << endl;
cout << "                                                                                           \\.____,   ~  \\/'\\/  ~   .____,/ " << endl;
cout << "                                                                                            ^.____                 ____.^     " << endl;
cout << "                                                                                               | |T ~\\  !   !  /~ T| |       " << endl;
cout << "                                                                                               | |l   _ _ _ _ _   !| |        " << endl;
cout << "                                                                                               | l \\/V V V V V V\\/ j |      " << endl;
cout << "                                                                                               l  \\ \\|_|_|_|_|_|/ /  !      " << endl;
cout << "                                                                                                \\  \\[T T T T T TI/  /       " << endl;
cout << "                                                                                                 \\  `^-^-^-^-^-^'  /         " << endl;
cout << "                                                                                                  \\               /          " << endl;
cout << "                                                                                                   \\.           ,/           " << endl;
cout << "                                                                                                     '^-.___,-^'              " << endl;
cout << endl;
cout << endl;
cout << endl;
cout << endl;
cout << "                                            ___        ___   ____________     ___      ___          _____________        ____________     ____________     _____________        ___     " << endl;
cout << "                                            \\  \\      /  /  |    ____    |   |   |    |   |        |             \\      |____    ____|   |   _________|   |             \\      |   |" << endl;
cout << "                                             \\  \\    /  /   |   |    |   |   |   |    |   |        |   _________  \\          |  |        |  |             |   _________  \\     |   |" << endl;
cout << "                                              \\  \\  /  /    |   |    |   |   |   |    |   |        |  |         |  \\         |  |        |  |_________    |  |         |  \\    |   |" << endl;
cout << "                                               \\  \\/  /     |   |    |   |   |   |    |   |        |  |         |   |        |  |        |   _________|   |  |         |   |   \\___/ " << endl;
cout << "                                                |    |      |   |    |   |   |   |    |   |        |  |_________|  /         |  |        |  |             |  |_________|  /             " << endl;
cout << "                                                |    |      |   |____|   |   |   |____|   |        |              /      ____|  |____    |  |_________    |              /      ___     " << endl;
cout << "                                                |____|      |____________|   |____________|        |_____________/      |____________|   |____________|   |_____________/      |___|    " << endl;
system("Pause");
intDied = 1;
StartMenu(intStartGame);
}

void NeverBeTheSame(string strYourHamstersName, string strYourGirlfriendsName)
{
system("CLS");

int intSpendLastDay;

cout << "You tell her 'I don't think that things will ever be the same again. Everything is going insane people are hurting each other, stealing others" << endl;
cout << "stuff, threatening people if they don't do what they want etc. How will the world ever be the same?' " << strYourGirlfriendsName << " responds 'I don't know I'm just" << endl;
cout << "trying to stay hopeful.' You hug her, 'I know, it's ok.' Do you wanna eat Lunch or play with " << strYourHamstersName << "?" << endl;
cout << endl;
cout << endl;
cout << "Choose what " << strYourGirlfriendsName << " wants to do:" << endl;
cout << "(1) Eat Lunch" << endl;
cout << "(2) Play with " << strYourHamstersName << endl;
cout << endl;
cin >> intSpendLastDay;

    if (intSpendLastDay == 1)
    {
    system("CLS");

    int intFood;

    cout << "She says that she wants to eat Lunch. You decide to get up and start cooking lunch for the both of you." << endl;
    cout << "You don't have a lot of food, horrible time to run out of groceries. All you have is Cheeseburgers and Pizza" << endl;
    cout << "Well you also have... " << strYourHamstersName << " ,but will you really eat him?" << endl;
    cout << endl;
    cout << endl;
    cout << "What will you eat?" << endl;
    cout << "(1) Pizza" << endl;
    cout << "(2) Cheeseburger" << endl;
    cout << "(3) " << strYourHamstersName << endl;
    cout << endl;
    cin >> intFood;

        if (intFood == 1)
        {
        system("CLS");

        cout << "You put a pizza in the oven and wait for it to be done cooking." << endl;
        cout << "You play a game on your phone while you wait. 'Hey " << strYourGirlfriendsName << " I'm cooking pizza," << endl;
        cout << "do you want some too?' She responds 'Sure!' It finishes cooking and" << endl;
        cout << "you put some on a plate for her and hand it to her. You watch some TV while you eat." << endl;
        cout << endl;
        system("Pause");
        }

        if (intFood == 2)
        {
        system("CLS");

        cout << "You start up the burners and place a metal tray on the stove." << endl;
        cout << "You put the patties on the tray '" << strYourGirlfriendsName << " do you want a Cheeseburger?'" << endl;
        cout << "She responds 'Actually, do you mind putting a Pizza in the oven for me?'" << endl;
        cout << "'Sure, I can do that.' You say. You finish cooking up all the food" << endl;
        cout << "you put some on a plate for her and hand it to her. You watch some TV while you eat." << endl;
        cout << endl;
        system("Pause");
        }

        if (intFood == 3)
        {
        system("CLS");

        cout << "You take " << strYourHamstersName << " out of his cage and turn the burners on." << endl;
        cout << strYourGirlfriendsName << " pulls out your Electric Shotgun and asks you" << endl;
        cout << "'What the hell are you doing?' and shoots you in the head." << endl;
        cout << endl;
        cout << endl;
        cout << "You Died!" << endl;
        cout << endl;
        system("Pause");
        Death(intDied);
        }
    }

    if (intSpendLastDay == 2)
    {
    system("CLS");

    cout << "You sit on the couch with her and tell her it'll be ok. You pull " << strYourHamstersName << " out of his cage, and start playing with him." << endl;
    cout << "You put him in a big plastic ball and watch where he goes. This helps distract her from all the chaos. You feed " << strYourHamstersName << endl;
    cout << "some Jell-O, remembering how crazy it makes him. You two laugh together as he runs around and starts running into walls and runs under" << endl;
    cout << "the bottom of the couch. You take him out of the plastic ball and put him back into his cage." << endl;
    cout << endl;
    system("Pause");
    }
}

void PoliceChance(int &intPoliceChance, string strYourGirlfriendsName)
{
srand(static_cast<int>(time(0)));
    for (int intPoliceLoop = 0; intPoliceLoop < 10; ++intPoliceLoop)
    {
    intPoliceChance = 1 + rand() % (5);
    }

    if (intPoliceChance == 1 || intPoliceChance == 2)
    {
    system("CLS");

    int intPoliceStart;

    cout << "You ask " << strYourGirlfriendsName << " what she thinks. She tells you that it's a great idea and that she wants to join you. You say 'Sounds good'" << endl;
    cout << "and pull out your phone, dialing the nearest police station. You call the Police and ask them if they are letting citizens help with the massive increase in crime." << endl;
    cout << "Surprisingly they tell you 'Absolutely do you wanna help us?' You respond 'Sure' and go out and start walking to the nearest Police Station. It's about half" << endl;
    cout << "a mile away but it's worth the walking. You make sure that you grab your Electric Shotgun, hoping you wont have to use it. You get there and ask them what they want you to do." << endl;
    cout << "The Police captain tells you that you have a few options, Go take shooting practice, Listen to the rules and regulations or Go straight to helping defend different communities." << endl;
    cout << endl;
    cout << endl;
    cout << "What will you do?" << endl;
    cout << "(1) Go to Shooting Practice" << endl;
    cout << "(2) Listen to the Rules and Regulations" << endl;
    cout << "(3) Go Straight to Helping Different Communities" << endl;
    cout << endl;
    cin >> intPoliceStart;

        if (intPoliceStart == 1)
        {
        ShootingPractice(strYourGirlfriendsName);
        }

        if (intPoliceStart == 2)
        {
        RulesAndRegulations(strYourGirlfriendsName);
        }

        if (intPoliceStart == 3)
        {
        CommunityHelp();
        }
    }
    if (intPoliceChance == 3 || intPoliceChance == 4 || intPoliceChance == 5)
    {
    system("CLS");

    cout << "You ask " << strYourGirlfriendsName << " what she thinks. She tells you that it's a great idea and that she wants to join you. You say 'Sounds good' and pull out your phone," << endl;
    cout << "dialing the nearest police station. You get nothing, but try again. You think to yourself, 'should I go and check on them and see if they're ok?' you decide it's the best option." << endl;
    cout << "You grab your Electric Shotgun and start walking to the local Police Station with " << strYourGirlfriendsName << " nothing seems to be out of the ordinary. You go inside and ask why they weren't answering their phones." << endl;
    cout << "They tell you it's because the phone lines are down. Then BLAM! you and " << strYourGirlfriendsName << " are shot in the head, the police station was taken over by criminals who didn't want you digging around." << endl;
    cout << endl;
    cout << endl;
    cout << "You Died!" << endl;
    cout << endl;
    system("Pause");
    Death(intDied);
    }
}

void ShootingPractice(string strYourGirlfriendsName)
{
system("CLS");

cout << "You go with " << strYourGirlfriendsName << " to the shooting range in the basement. It's full of people trying to learn how to shoot so they can help defend their communities." << endl;
cout << "You wait for someone to come and help you. A Lieutenant comes in and see's you. They tell you to come up to where you fire and hand you a pistol and put kevlar on" << endl;
cout << "You start shooting aiming at the targets that are surprisingly small, you try aiming for both the head and chest you find that it's a lot more difficult then you thought. " << strYourGirlfriendsName << " seems to be better then you are at it." << endl;
cout << "you so that you get used to shooting with extra weight. They do the same for " << strYourGirlfriendsName << ". You give it another shot asking the Lieutenant if you can try doing it with an Assault Rifle, they let you, with the pure insanity" << endl;
cout << "out there your gonna need the best you can get to stop others who might have other dangerous guns as well. You seem to be a better at shooting with this, maybe it's easier " << endl;
cout << "because it's held against your shoulder you wonder. You and " << strYourGirlfriendsName << " decide to go home it's starting to get late and you are both tired." << endl;
cout << endl;
system("Pause");
}

void RulesAndRegulations(string strYourGirlfriendsName)
{
system("CLS");

cout << "You and " << strYourGirlfriendsName << " go to a room with a white board and a deputy who's there in a small room. You have to sit there and listen to this. The first thing they are going over is what you have to say when making an arrest." << endl;
cout << "You have to say 'You are under arrest, you have the right to remain silent. Anything you say can and will be used against you in a court of law. You have the right to an attorney," << endl;
cout << "if you cannot afford one, one will be appointed to you. Do you understand the rights i have just read to you? With these rights in mind, do you wish to speak to me?' This is surprisingly more" << endl;
cout << "boring then school was, especially that dumb old coding class. They tell you that this is all for today and that you can come back tomorrow or another day to learn more." << endl;
cout << "You decide to go home it's getting late and there's not much more that you can do here anyway." << endl;
cout << endl;
system("Pause");
}

void CommunityHelp()
{
system("CLS");

cout << "The Captain personally takes you and " << strYourGirlfriendsName << " on a ride into a nearby community where they got a phone call about someone siphoning gas from other peoples cars without permission. Leaving the rest of us with less gas," << endl;
cout << "and during a shortage too. We drive together through a neighborhood looking for this person. We see someone ducked down next to a car with a hose and a few Gas cans." << endl;
cout << "We have to try to make sure that none of us or the suspect is exposed to the Gas getting any on us or anyone else. The Captain gets out slowly trying not to frighten the suspect," << endl;
cout << "unfortunately he fails. The suspect runs away grabbing the gas, due to the risk of being turned into a Weasel The Police have been ordered to proceed with caution. unfortunately" << endl;
cout << "it's not sealed. The gas spills over him, and you and " << strYourGirlfriendsName << " see someone turned into a Weasel for the first time. It's fairly small and runs away fast. We ask if we should go after it, The captain says no, we have to" << endl;
cout << "report it to the FBI. We get back in the car and go back to the station, disappointed that this is real and we failed. The Captain tells us to go home, that we did a good job" << endl;
cout << "trying to help but he's worried, he's never seen anything like this. He wonders how long society will last. You return home worried about the same thing. How long will we last..." << endl;
cout << endl;
system("Pause");
}

void Fire(string strYourHamstersName, string strYourGirlfriendsName)
{
system("CLS");

cout << "Your home trying to get some rest with " << strYourGirlfriendsName << " it's late and it's been another long day. You hope that every day wont be like yesterday and today, long, tiring and scary. " << endl;
cout << "You finally fall asleep for a few hours when all the sudden... Your woken up to the smell of fire. You immediately wake up and shout '" << strYourGirlfriendsName << " theres a fire we need to get out now!' You and her both" << endl;
cout << "immediately go to " << strYourHamstersName << "'s cage. He's there but he's dead. No time no mourn now. You have to grab whatever you can in a short period of time.Thinking fast you think about the essentials, what will you need?" << endl;
cout << "You grab a backpack to put things in first. Food, you go into the fridge all you have is a Jell-O. Drink, all you have is an empty bottle, it'll have to do. Protection, you grab your Electric Shotgun. Wait,"<< endl;
cout << "where's " << strYourGirlfriendsName << ", you shout 'Babe where are you?' She responds 'In the bathroom grabbing a few things.' You reply 'Hurry!' and continue Heat, it's almost winter, you grab a blanket. And then for the memories" << endl;
cout << "you grab " << strYourHamstersName << "'s Wheel. And most importantly your engagement ring for" << strYourGirlfriendsName << ". 'Babe we have to go now!, it's getting bad.' you say. You run outside and get away" << endl;
cout << "from the fire. Of course the things your girlfriend grabs are a Hair Straightener and Hairband. You throw them in the backpack. 'What do we do?' you say. She responds 'I don't know.' You sit there in pure awe" << endl;
cout << "staring at the fire watching everything you've built turn to ashes. You feel a mix of fear, adrenaline and anger at whoever caused this. You have no idea who or what caused this, but it was likely another" << endl;
cout << "person just trying to cause chaos." << endl;
cout << endl;
system("Pause");
}

void NameSelection2(string &strWeaselsName, string &strLlamasName)
{
system("CLS");
cout << "Enter The Weasels Name: " << endl;
cin >> strWeaselsName;

    if (strWeaselsName == "Default")
    {

    strWeaselsName = "Bob";

    }

system("CLS");
cout << "Enter The Llamas name: " << endl;
cin >> strLlamasName;
    if (strLlamasName != "Default")
    {

    strLlamasName = strLlamasName + " The Llama";

    }

    if (strLlamasName == "Default")
    {

    strLlamasName = "Jennifer The Llama";

    }
}

void Walmart(string strWeaselsName, string strLlamasName, string strYourGirlfriendsName, string strYourHamstersName)
{
system("CLS");

cout << "You and " << strYourGirlfriendsName << " decide to go to Walmart, maybe you can get some supplies to keep you going. Both of you are still morning the loss of " << strYourHamstersName << " your still in shock" << endl;
cout << "not sure how to handle any of this. It feels like the world is crumbling causing your life to crumble with it. You think all of this while walking to Walmart." << endl;
cout << strYourGirlfriendsName << " is still really shaken up over the death of " << strYourHamstersName << ". You ask her 'Hey are you doing all right?' She starts crying, 'No i miss " << strYourHamstersName << ", he was so cute," << endl;
cout << "and little and now he's gone because of some stupid thing where people are turning into Weasels. Who would even think of something like that?' You respond 'I know it's" << endl;
cout << "stupid but we can't do anything to change it.' You finally get to Walmart, and somehow the day gets even worse. You look to see the Walmart up in flames, just like" << endl;
cout << "your house. It's a mess, with people fighting everywhere. You see a group attacking a Weasel riding a Llama. After what just happened to " << strYourHamstersName << " " << strYourGirlfriendsName << " runs towards them. She starts " << endl;
cout << "Shouting 'Hey leave those poor animals alone.' They look at your girlfriend in shock as you think to yourself 'Oh no, we're dead.' They respond to her 'Who do you think" << endl;
cout << "you are?' She responds 'Someone who doesn't put up with bullies.' The Weasel introduces himself 'I'm " << strWeaselsName << " and She's " << strLlamasName << ". Lets fight these suckers!'"<< endl;
cout << endl;

system("Pause");
system("CLS");
cout << "You are presented with your first real fight. " << strYourName << ", " << strYourGirlfriendsName << ", " << strWeaselsName << " and " << strLlamasName << " are all together. Lets go through all their differences:" << endl;
Tutorial(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, strYourHamstersName);
}

void Tutorial(string strWeaselsName, string strLlamasName, string strYourGirlfriendsName, string strYourName, string strYourHamstersName)
{
char chrUnderstand;


cout << endl;
cout << strYourName << " is equipped with your Electric Shotgun, but keep in mind it's powered by Electricity so it doesn't have infinite power. Oh wait didn't you grab" << endl;
cout << strYourHamstersName << "'s wheel? You attach it to your Electric Shotgun. You can now team up with " << strWeaselsName << " and he can (reluctantly) generate power to recharge it, at the cost of his turn." << endl;
cout << endl;
cout << endl;
cout << strYourGirlfriendsName << " is next, she uses her hair straightener to burn enemies. Not doing as much damage but stunning the enemy targeted once. This has a longer charge," << endl;
cout << "but still needs to be charged occasionally. You also have her hairband who knows what this can be used for, but maybe you can find a use somehow" << endl;
cout << endl;
cout << endl;
cout << strWeaselsName << " has a small knife he can use, which deals less damage but can deal multiple hits. This can lead to him being occasionally more powerful then " << strYourName << ", but rarely." << endl;
cout << "Keep in mind that if he is charging another characters weapon his turn is skipped." << endl;
cout << endl;
cout << endl;
cout << strLlamasName << " is useless... Ok not completely useless but the good thing is she will grow and gain more abilities as time goes on and can learn more as your level goes up." << endl;
cout << "But her primary attack is a spit that decreases the accuracy of the enemies attacks. And eventually it will go down to zero, but chances are you'll kill them first." << endl;
cout << endl;
cout << endl;
cout << "All characters will have access to their Primary Attack (Shoot, Stun, Slice and Spit), Items, Stats, a Help screen in case you forget how to play and Exit so you can leave a battle." << endl;
cout << "Please note that all items will be used up and removed unless otherwise stated, should be pretty much common sense as to what's consumable and what stays for good." << endl;
cout << "Stats will show your current Attack, Stun, Hit Count and Accuracy Reduction for their corresponding characters. And you will gain money after each fight. And Exiting the battle" << endl;
cout << "Will result in no Experience (EXP) earned, but will also result in no Damage (loss in HP) done to you. The story will continue as normal as if you won normally." << endl;
cout << "Speaking of Experience (EXP) Leveling up may occur after gaining enough Experience (EXP), this will increase the Stats for the character that Leveled up and maybe" << endl;
cout << "Abilities for " << strLlamasName << endl;
cout << endl;
cout << endl;
cout << "Do you understand the tutorial? (Y/N)" << endl;
cout << endl;
cin >> chrUnderstand;

chrUnderstand = toupper(chrUnderstand);

    if (chrUnderstand == 'Y')
    {

    FirstFight(strYourName, strYourGirlfriendsName, strWeaselsName, strLlamasName, intYourHP, intGFHP, intWeaselHP, intLlamaHP, intStun1, intStun2, intStun3, intStunned, intYourLevel, intYourEXP, intAttack, intGFLevel, intGFEXP, intStunChance, intWeaselLevel, intWeaselEXP, intHitCount, intLlamaLevel, intLlamaEXP, intAccuracyLowered, intRecharge);

    }

    if (chrUnderstand == 'N')
    {
    char chrReread;

    system("CLS");

    cout << "Would you like to reread the Tutorial? (Y/N)" << endl;
    cout << endl;
    cin >> chrReread;
    chrReread = toupper(chrReread);

        if (chrReread == 'Y')
        {

        Tutorial(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, strYourHamstersName);

        }

        if (chrReread == 'N')
        {
        system("CLS");

        cout << "Proceeding to fight..." << endl;
        cout << endl;
        system("Pause");

        FirstFight(strYourName, strYourGirlfriendsName, strWeaselsName, strLlamasName, intYourHP, intGFHP, intWeaselHP, intLlamaHP, intStun1, intStun2, intStun3, intStunned, intYourLevel, intYourEXP, intAttack, intGFLevel, intGFEXP, intStunChance, intWeaselLevel, intWeaselEXP, intHitCount, intLlamaLevel, intLlamaEXP, intAccuracyLowered, intRecharge);
        }
    }
}

void FirstFight(string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, int &intStun1, int &intStun2, int &intStun3, int &intStunned, int &intYourLevel, int &intYourEXP, int &intAttack, int &intGFLevel, int &intGFEXP, int &intStunChance, int &intWeaselLevel, int &intWeaselEXP, int &intHitCount, int &intLlamaLevel, int &intLlamaEXP, int &intAccuracyLowered, int &intRecharge)
{
system("CLS");

int intYourMoveChoice;
int intGFMoveChoice;
int intWeaselChoice;
int intLlamaChoice;

cout << "You are Presented with 3 Thugs to fight." << endl;
cout << "They have 1 Attack and 10 Health each." << endl;
cout << endl;
system("Pause");
    do
    {
        if (intYourHP > 0)
        {
        intYourMoveChoice = YourFightMenu(intRecharge, intElectricShotgunCharge, intAttack, intThug1HP, intThug2HP, intThug3HP, strYourName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intYourHP, intYourEXP, intJello);
        }

        if (intYourHP < 0)
        {
        system("CLS");
        cout << strYourName << " is Knocked out!" << endl;
        system("Pause");
        }

        if (intYourMoveChoice == 5)
        {
        break;
        }

        if (intGFHP > 0)
        {
        intGFMoveChoice = GFFightMenu(intRecharge, intHairStraightenerCharge, intStunChance, intStun1, intStun2, intStun3, strYourGirlfriendsName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intGFHP, intGFEXP, intJello);
        }

        if (intGFHP < 0)
        {
        system("CLS");
        cout << strYourGirlfriendsName << " is Knocked out!" << endl;
        system("Pause");
        }

        if (intGFMoveChoice == 5)
        {
        break;
        }

        if (intRecharge != 1 && intWeaselHP > 0)
        {
        intWeaselChoice = WeaselFightMenu(intHitCount, intThug1HP, intThug2HP, intThug3HP, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intWeaselHP, intWeaselEXP, intJello);
        }

        if (intWeaselHP < 0)
        {
        system("CLS");
        cout << strWeaselsName << " is Knocked out!" << endl;
        system("Pause");
        }

        if (intWeaselChoice ==5)
        {
        break;
        }

        if (intRecharge == 1)
        {
        system("CLS");
        cout << "Weasel is recharging someones weapon, he cannot preform any actions this turn." << endl;
        cout << endl;
        system("Pause");
        intRecharge = 0;
        }

        if (intLlamaHP > 0)
        {
        intLlamaChoice = LlamaFightMenu(intAccuracyLowered, intThug1Accuracy, intThug2Accuracy, intThug3Accuracy, strLlamasName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intLlamaHP, intLlamaEXP, intJello);
        }

        if (intLlamaHP < 0)
        {
        system("CLS");
        cout << strLlamasName << " is Knocked out!" << endl;
        system("Pause");
        }

        if (intLlamaChoice == 5)
        {
        break;
        }

        if (intYourHP < 0 && intGFHP < 0 && intWeaselHP < 0 && intLlamaHP < 0)
        {
        Death(intDied);
        }

        if (intStun1 <= 4 && intStunned == 0)
        {
        Thug1(intThug1HP, intThug1Accuracy, intYourHP, intGFHP, intWeaselHP, intLlamaHP, strYourName, strYourGirlfriendsName, strWeaselsName, strLlamasName);
        }

        if (intStun2 <= 4 && intStunned == 0)
        {
        Thug2(intThug2HP, intThug2Accuracy, intYourHP, intGFHP, intWeaselHP, intLlamaHP, strYourName, strYourGirlfriendsName, strWeaselsName, strLlamasName);
        }

        if (intStun3 <= 4 && intStunned == 0)
        {
        Thug3(intThug3HP, intThug3Accuracy, intYourHP, intGFHP, intWeaselHP, intLlamaHP, strYourName, strYourGirlfriendsName, strWeaselsName, strLlamasName);
        }
        intStun1 = 0;
        intStun2 = 0;
        intStun3 = 0;
        intStunned = 0;

    } while (intThug1HP > 0 || intThug2HP > 0 || intThug3HP > 0 && intYourMoveChoice != 5 && intGFMoveChoice != 5 && intWeaselChoice != 5 && intLlamaChoice != 5);

    intYourEXP += 500;
    intGFEXP += 500;
    intWeaselEXP += 500;
    intLlamaEXP += 500;

    if (intYourEXP >= 500)
    {
    intYourEXP = 0;
    intYourLevel += 1;
    intAttack += 1;
    intMoney += 50;

    system("CLS");
    cout << "You Leveled Up! " << strYourName << " is now Level " << intYourLevel << endl;
    cout << strYourName << " Attack increased to " << intAttack << endl;
    cout << "You gained 50 Bucks! You have " << intMoney << " bucks" << endl;
    system("Pause");
    }

    if (intGFEXP >= 500)
    {
    intGFEXP = 0;
    intGFLevel += 1;
    intStunChance += 1;

    system("CLS");
    cout << strYourGirlfriendsName << " Leveled Up! " << strYourGirlfriendsName << " is now Level " << intGFLevel << endl;
    cout << strYourGirlfriendsName << "'s Stun Chance increased to " << intStunChance << endl;
    system("Pause");
    }

    if (intWeaselEXP >= 500)
    {
    intWeaselEXP = 0;
    intWeaselLevel += 1;
    intHitCount += 1;

    system("CLS");
    cout << strWeaselsName << " Leveled Up! " << strWeaselsName << " is now Level " << intWeaselLevel << endl;
    cout << strWeaselsName << "'s Hit Count increased to " << intHitCount << endl;
    system("Pause");
    }

    if (intLlamaEXP >= 500)
    {
    intLlamaEXP = 0;
    intLlamaLevel += 1;
    intAccuracyLowered += 1;

    system("CLS");
    cout << strLlamasName << " Leveled Up! " << strLlamasName << " is now Level " << intLlamaLevel << endl;
    cout << strLlamasName << "'s Accuracy Lowering increased to " << intAccuracyLowered << endl;
    system("Pause");
    }

    intYourHP = 15;
    intGFHP = 15;
    intWeaselHP = 15;
    intLlamaHP = 15;

CharactersMeet(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName);
}

int YourFightMenu(int &intRecharge, int &intElectricShotgunCharge, int intAttack, int &intThug1HP, int &intThug2HP, int &intThug3HP, string strYourName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intYourHP, int intYourEXP, int intJello)
{
int intYourMoveChoice;
system("CLS");

cout << "It is " << strYourName << "'s Turn." << endl;
cout << "What will you do?" << endl;
cout << "(1) Shoot" << endl;
cout << "(2) Items" << endl;
cout << "(3) Stats" << endl;
cout << "(4) Help" << endl;
cout << "(5) Exit" << endl;
cout << endl;
cin >> intYourMoveChoice;

    if (intYourMoveChoice == 1 && intElectricShotgunCharge == 0)
    {
    system("CLS");
    cout << "You have no Charge Left in your Electric Shotgun, Please Recharge it." << endl;
    intYourMoveChoice = 2;
    cout << "Going to items so you can Recharge..." << endl;
    cout << endl;
    system("Pause");
    }

    if (intYourMoveChoice == 1)
    {
    int intEnemyChoice;
    system("CLS");
    cout << "Target an enemy: " << endl;
    cout << "(1) Thug 1 (" << intThug1HP << " HP)" << endl;
    cout << "(2) Thug 2 (" << intThug2HP << " HP)" << endl;
    cout << "(3) Thug 3 (" << intThug3HP << " HP)" << endl;
    cout << endl;
    cin >> intEnemyChoice;

        if (intEnemyChoice == 1)
        {
        int intYourDamage;
        srand(static_cast<int>(time(0)));
        intYourDamage = intAttack + rand()%(3);
        intElectricShotgunCharge -= 1;
        intThug1HP -= intYourDamage;

        intYourEXP = intYourDamage * 20;
        system("CLS");
        cout << "You dealt " << intYourDamage << " Damage, Thug 1 has " << intThug1HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 2)
        {
        int intYourDamage;
        srand(static_cast<int>(time(0)));
        intYourDamage = intAttack + rand()%(3);
        intElectricShotgunCharge -= 1;
        intThug2HP -= intYourDamage;

        intYourEXP += intYourDamage * 20;
        system("CLS");
        cout << "You dealt " << intYourDamage << " Damage, Thug 2 has " << intThug2HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 3)
        {
        int intYourDamage;
        srand(static_cast<int>(time(0)));
        intYourDamage = intAttack + rand()%(3);
        intElectricShotgunCharge -= 1;
        intThug3HP -= intYourDamage;

        intYourEXP += intYourDamage * 20;
        system("CLS");
        cout << "You dealt " << intYourDamage << " Damage, Thug 3 has " << intThug3HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }
    }
    if (intYourMoveChoice == 2)
    {
    int intItemChoice;
    system("CLS");
    cout << "Items:" << endl;
    cout << "(1) " << strYourHamstersName << "'s Wheel (Will recharge your Electric Shotgun)" << endl;
        if (intJello != 0)
        {
        cout << "(2) A Jell-O Pack (Will increase the hits of " << strWeaselsName << "'s Knife)" << endl;
        }
        if (intBlanket != 0)
        {
        cout << "(3) A Blanket (Will trap the enemy for a turn, will be used up)" << endl;
        }
        cout << endl;
        cin >> intItemChoice;

        if (intItemChoice == 2)
        {
        system("CLS");
        cout << "You are not " << strWeaselsName << ". Returning back to Attack Menu..." << endl;
        cout << endl;
        system("Pause");
        intYourMoveChoice = YourFightMenu(intRecharge, intElectricShotgunCharge, intAttack, intThug1HP, intThug2HP, intThug3HP, strYourName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intYourHP, intYourEXP, intJello);
        }

        if (intItemChoice == 1)
        {
        system("CLS");
        intRecharge += 1;
        intElectricShotgunCharge = 5;
        cout << "You successfully recharge your Electric Shotgun" << endl;
        cout << endl;
        system("Pause");
        }

        if (intItemChoice == 3)
        {
        system("CLS");
        cout << "You stunned Thugs Your blanket can no longer be used. It was torn up while they were trying to escape." << endl;
        intBlanket -= 1;
        intStunned += 1;
        cout << endl;
        system("Pause");
        }
    }

    if (intYourMoveChoice == 3)
    {
    system("CLS");
    cout << strYourName << ":" << endl;
    cout << "Stats:" << endl;
    cout << "Attack: " << intAttack << " To " << intAttack + 2 << endl;
    cout << "HP: " << intYourHP << endl;
    cout << "EXP: " << intYourEXP << endl;
    cout << endl;
    system("Pause");
    intYourMoveChoice = YourFightMenu(intRecharge, intElectricShotgunCharge, intAttack, intThug1HP, intThug2HP, intThug3HP, strYourName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intYourHP, intYourEXP, intJello);
    }

    if (intYourMoveChoice == 4)
    {

    FightHelp(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, strYourHamstersName);
    intYourMoveChoice = YourFightMenu(intRecharge, intElectricShotgunCharge, intAttack, intThug1HP, intThug2HP, intThug3HP, strYourName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intYourHP, intYourEXP, intJello);
    }

    if (intYourMoveChoice == 5)
    {
    system("CLS");
    }
    return (intYourMoveChoice);
}

void FightHelp(string strWeaselsName, string strLlamasName, string strYourGirlfriendsName, string strYourName, string strYourHamstersName)
{
system("CLS");
cout << strYourName << " is equipped with your Electric Shotgun, but keep in mind it's powered by Electricity so it doesn't have infinite power. Oh wait didn't you grab" << endl;
cout << strYourHamstersName << "'s wheel? You attach it to your Electric Shotgun. You can now team up with " << strWeaselsName << " and he can (reluctantly) generate power to recharge it, at the cost of his turn." << endl;
cout << endl;
cout << endl;
cout << strYourGirlfriendsName << " is next, she uses her hair straightener to burn enemies. Not doing as much damage but stunning the enemy targeted once. This has a longer charge," << endl;
cout << "but still needs to be charged occasionally. You also have her hairband who knows what this can be used for, but maybe you can find a use somehow" << endl;
cout << endl;
cout << endl;
cout << strWeaselsName << " has a small knife he can use, which deals less damage but can deal multiple hits. This can lead to him being occasionally more powerful then " << strYourName << ", but rarely." << endl;
cout << "Keep in mind that if he is charging another characters weapon his turn is skipped." << endl;
cout << endl;
cout << endl;
cout << strLlamasName << " is useless... Ok not completely useless but the good thing is she will grow and gain more abilities as time goes on and can learn more as your level goes up." << endl;
cout << "But her primary attack is a spit that decreases the accuracy of the enemies attacks. And eventually it will go down to zero, but chances are you'll kill them first." << endl;
cout << endl;
cout << endl;
cout << "All characters will have access to their Primary Attack (Shoot, Stun, Slice and Spit), Items, Stats, a Help screen in case you forget how to play and Exit so you can leave a battle." << endl;
cout << "Please note that all items will be used up and removed unless otherwise stated, should be pretty much common sense as to what's consumable and what stays for good." << endl;
cout << "Stats will show your current Attack, Stun, Hit Count and Accuracy Reduction for their corresponding characters. And you will gain money after each fight. And Exiting the battle" << endl;
cout << "Will result in no Experience (EXP) earned, but will also result in no Damage (loss in HP) done to you. The story will continue as normal as if you won normally." << endl;
cout << "Speaking of Experience (EXP) Leveling up may occur after gaining enough Experience (EXP), this will increase the Stats for the character that Leveled up and maybe" << endl;
cout << "Abilities for " << strLlamasName << endl;
cout << endl;
system("Pause");
}

int GFFightMenu(int &intRecharge, int &intHairStraightenerCharge, int intStunChance, int &intStun1, int &intStun2, int &intStun3, string strYourGirlfriendsName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intGFHP, int intGFEXP, int intJello)
{
system("CLS");
int intGFMoveChoice;

cout << "It is " << strYourGirlfriendsName << "'s Turn." << endl;
cout << "What will you do?" << endl;
cout << "(1) Stun" << endl;
cout << "(2) Items" << endl;
cout << "(3) Stats" << endl;
cout << "(4) Help" << endl;
cout << "(5) Exit" << endl;
cout << endl;
cin >> intGFMoveChoice;

    if (intGFMoveChoice == 1 && intHairStraightenerCharge == 0)
    {
    system("CLS");
    cout << strYourGirlfriendsName << " has no Charge Left in your Hair Straightener, Please Recharge it." << endl;
    intGFMoveChoice = 2;
    cout << "Going to items so you can Recharge..." << endl;
    cout << endl;
    system("Pause");
    }

    if (intGFMoveChoice == 1)
    {
    int intEnemyChoice;
    system("CLS");
    cout << "Target an enemy: " << endl;
    cout << "(1) Thug 1 (" << intThug1HP << " HP)" << endl;
    cout << "(2) Thug 2 (" << intThug2HP << " HP)" << endl;
    cout << "(3) Thug 3 (" << intThug3HP << " HP)" << endl;
    cout << endl;
    cin >> intEnemyChoice;

        if (intEnemyChoice == 1)
        {
        system("CLS");
        srand(static_cast<int>(time(0)));
        intStun1 = intStunChance + rand()%(10);
        intHairStraightenerCharge -= 1;
            if (intStun1 >= 5)
            {
            intGFEXP += intStun1 * 20;
            cout << strYourGirlfriendsName << " Stunned Thug 1" << endl;
            cout << endl;
            system("Pause");
            }
            else if (intStun1 <= 5)
            {
            cout << strYourGirlfriendsName << " failed to stun Thug 1" << endl;
            cout << endl;
            system("Pause");
            }
        }

        if (intEnemyChoice == 2)
        {
        system("CLS");
        srand(static_cast<int>(time(0)));
        intStun2 = intStunChance + rand()%(10);
        intHairStraightenerCharge -= 1;
            if (intStun2 >= 5)
            {
            intGFEXP += intStun2 * 20;
            cout << strYourGirlfriendsName << " Stunned Thug 2" << endl;
            cout << endl;
            system("Pause");
            }
            else if (intStun2 <= 5)
            {
            cout << strYourGirlfriendsName << " failed to stun Thug 2" << endl;
            cout << endl;
            system("Pause");
            }
        }

        if (intEnemyChoice == 3)
        {
        system("CLS");
        srand(static_cast<int>(time(0)));
        intStun3 = intStunChance + rand()%(10);
        intHairStraightenerCharge -= 1;
            if (intStun3 >= 5)
            {
            intGFEXP += intStun3 * 20;
            cout << strYourGirlfriendsName << " Stunned Thug 3" << endl;
            cout << endl;
            system("Pause");
            }
            else if (intStun3 <= 5)
            {
            cout << strYourGirlfriendsName << " failed to stun Thug 3" << endl;
            cout << endl;
            system("Pause");
            }
        }
    }

    if (intGFMoveChoice == 2)
    {
    int intItemChoice;
    system("CLS");
    cout << "Items:" << endl;
    cout << "(1) " << strYourHamstersName << "'s Wheel (Will recharge your Hair Straightener)" << endl;
        if (intJello != 0)
        {
        cout << "(2) A Jell-O Pack (Will increase the hits of " << strWeaselsName << "'s Knife)" << endl;
        }
        if (intBlanket != 0)
        {
        cout << "(3) A Blanket (Will trap the enemy for a turn, will be used up)" << endl;
        }
        cout << endl;
        cin >> intItemChoice;
        if (intItemChoice == 2)
        {
        system("CLS");
        cout << strYourGirlfriendsName << " is not " << strWeaselsName << ". Returning back to Attack Menu..." << endl;
        cout << endl;
        system("Pause");
        intGFMoveChoice = GFFightMenu(intRecharge, intHairStraightenerCharge, intStunChance, intStun1, intStun2, intStun3, strYourGirlfriendsName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intGFHP, intGFEXP, intJello);
        }

        if (intItemChoice == 1)
        {
        system("CLS");
        intRecharge += 1;
        intHairStraightenerCharge = 10;
        cout << strYourGirlfriendsName << " successfully recharge your Hair Straightener" << endl;
        cout << endl;
        system("Pause");
        }

        if (intItemChoice == 3)
        {
        system("CLS");
        cout << strYourGirlfriendsName << " stunned Thugs Your blanket can no longer be used. It was torn up while they were trying to escape." << endl;
        cout << endl;
        intBlanket -= 1;
        intStunned += 1;
        system("Pause");
        }
    }

    if (intGFMoveChoice == 3)
    {
    system("CLS");
    cout << strYourGirlfriendsName << ":" << endl;
    cout << "Stats:" << endl;
    cout << "Stun Chance: " << intStunChance << " To 10" << endl;
    cout << "HP: " << intGFHP << endl;
    cout << "EXP: " << intGFEXP << endl;
    cout << endl;
    system("Pause");
    intGFMoveChoice = GFFightMenu(intRecharge, intHairStraightenerCharge, intStunChance, intStun1, intStun2, intStun3, strYourGirlfriendsName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intGFHP, intGFEXP, intJello);
    }

    if (intGFMoveChoice == 4)
    {
    FightHelp(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, strYourHamstersName);
    intGFMoveChoice = GFFightMenu(intRecharge, intHairStraightenerCharge, intStunChance, intStun1, intStun2, intStun3, strYourGirlfriendsName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intGFHP, intGFEXP, intJello);
    }

    if (intGFMoveChoice == 5)
    {
    system("CLS");
    }
return (intGFMoveChoice);
}

int WeaselFightMenu(int &intHitCount, int &intThug1HP, int &intThug2HP, int &intThug3HP, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intWeaselHP, int intWeaselEXP, int &intJello)
{
system("CLS");
int intWeaselChoice;

cout << "It is " << strWeaselsName << "'s Turn." << endl;
cout << "What will you do?" << endl;
cout << "(1) Slice" << endl;
cout << "(2) Items" << endl;
cout << "(3) Stats" << endl;
cout << "(4) Help" << endl;
cout << "(5) Exit" << endl;
cout << endl;
cin >> intWeaselChoice;

    if (intWeaselChoice == 1)
    {
    int intEnemyChoice;
    system("CLS");
    cout << "Target an enemy: " << endl;
    cout << "(1) Thug 1 (" << intThug1HP << " HP)" << endl;
    cout << "(2) Thug 2 (" << intThug2HP << " HP)" << endl;
    cout << "(3) Thug 3 (" << intThug3HP << " HP)" << endl;
    cout << endl;
    cin >> intEnemyChoice;

        if (intEnemyChoice == 1)
        {
        int intDamage;
        srand(static_cast<int>(time(0)));
        intDamage = 1 + rand()%(2);

        intThug1HP -= intHitCount * intDamage;

        intWeaselEXP += intDamage * intHitCount * 20;
        system("CLS");
        cout << strWeaselsName << " dealt " << intDamage * intHitCount << " Damage, with " << intHitCount << " Hits, Thug 1 has " << intThug1HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 2)
        {
        int intDamage;
        srand(static_cast<int>(time(0)));
        intDamage = 1 + rand()%(2);

        intThug2HP -= intHitCount * intDamage;

        intWeaselEXP += intDamage * intHitCount * 20;
        system("CLS");
        cout << strWeaselsName << " dealt " << intDamage * intHitCount << " Damage, with " << intHitCount << " Hits, Thug 2 has " << intThug2HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 3)
        {
        int intDamage;
        srand(static_cast<int>(time(0)));
        intDamage = 1 + rand()%(2);

        intThug3HP -= intHitCount * intDamage;

        intWeaselEXP += intDamage * intHitCount * 20;
        system("CLS");
        cout << strWeaselsName << " dealt " << intDamage * intHitCount << " Damage, with " << intHitCount << " Hits, Thug 3 has " << intThug3HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }
    }

    if (intWeaselChoice == 2)
    {
    int intItemChoice;
    system("CLS");
    cout << "Items:" << endl;
    cout << "(1) " << strYourHamstersName << "'s Wheel" << endl;
        if (intJello != 0)
        {
        cout << "(2) A Jell-O Pack (Will increase the hits of " << strWeaselsName << "'s Knife)" << endl;
        }
        if (intBlanket != 0)
        {
        cout << "(3) A Blanket (Will trap the enemy for a turn, will be used up)" << endl;
        }
        cout << endl;
        cin >> intItemChoice;
        if (intItemChoice == 2)
        {
        system("CLS");
        cout << "You are " << strWeaselsName << ". Increasing Hit Count..." << endl;
        cout << endl;
        intHitCount += 2;
        intJello = 0;
        system("Pause");
        }

        if (intItemChoice == 1)
        {
        system("CLS");
        cout << strWeaselsName << " has nothing to recharge..." << endl;
        system("Pause");
        intWeaselChoice = WeaselFightMenu(intHitCount, intThug1HP, intThug2HP, intThug3HP, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intWeaselHP, intWeaselEXP, intJello);
        }

        if (intItemChoice == 3)
        {
        system("CLS");
        cout << strWeaselsName << " stunned Thugs Your blanket can no longer be used. It was torn up while they were trying to escape." << endl;
        intBlanket -= 1;
        intStunned += 1;
        system("Pause");
        system("CLS");
        }
    }

    if (intWeaselChoice == 3)
    {
    system("CLS");
    cout << strWeaselsName << ":" << endl;
    cout << "Stats:" << endl;
    cout << "Hit Count: " << intHitCount << endl;
    cout << "HP: " << intWeaselHP << endl;
    cout << "EXP: " << intWeaselEXP << endl;
    cout << endl;
    system("Pause");
    intWeaselChoice = WeaselFightMenu(intHitCount, intThug1HP, intThug2HP, intThug3HP, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intWeaselHP, intWeaselEXP, intJello);
    }

    if (intWeaselChoice == 4)
    {
    FightHelp(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, strYourHamstersName);
    intWeaselChoice = WeaselFightMenu(intHitCount, intThug1HP, intThug2HP, intThug3HP, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intWeaselHP, intWeaselEXP, intJello);
    }

    if (intWeaselChoice == 5)
    {
    system("CLS");
    }
return (intWeaselChoice);
}

int LlamaFightMenu(int intAccuracyLowered, int &intThug1Accuracy, int &intThug2Accuracy, int &intThug3Accuracy, string strLlamasName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intLlamaHP, int intLlamaEXP, int intJello)
{
system("CLS");
int intLlamaChoice;

cout << "It is " << strLlamasName << "'s Turn." << endl;
cout << "What will you do?" << endl;
cout << "(1) Spit" << endl;
cout << "(2) Items" << endl;
cout << "(3) Stats" << endl;
cout << "(4) Help" << endl;
cout << "(5) Exit" << endl;
cout << endl;
cin >> intLlamaChoice;

    if (intLlamaChoice == 1)
    {
    int intEnemyChoice;
    system("CLS");
    cout << "Target an enemy: " << endl;
    cout << "(1) Thug 1 (" << intThug1HP << " HP)" << endl;
    cout << "(2) Thug 2 (" << intThug2HP << " HP)" << endl;
    cout << "(3) Thug 3 (" << intThug3HP << " HP)" << endl;
    cout << endl;
    cin >> intEnemyChoice;

        if (intEnemyChoice == 1)
        {
        int intAccuracy;
        srand(static_cast<int>(time(0)));
        intAccuracy = 1 + rand()%(2);

        intThug1Accuracy -= intAccuracy * intAccuracyLowered;

        intLlamaEXP += intAccuracy * intAccuracyLowered * 20;
        system("CLS");
        cout << strLlamasName << " lowered Thug 1's Accuracy by " << intAccuracy * intAccuracyLowered << ", Thug 1 has " << intThug1HP << " HP left." << endl;
        cout << endl;
        system("Pause");

        }

        if (intEnemyChoice == 2)
        {
        int intAccuracy;
        srand(static_cast<int>(time(0)));
        intAccuracy = 1 + rand()%(2);

        intThug2Accuracy -= intAccuracy * intAccuracyLowered;

        intLlamaEXP += intAccuracy * intAccuracyLowered * 20;
        system("CLS");
        cout << strLlamasName << " lowered Thug 2's Accuracy by " << intAccuracy * intAccuracyLowered << ", Thug 2 has " << intThug2HP << " HP left." << endl;
        cout << endl;
        system("Pause");

        }

        if (intEnemyChoice == 3)
        {
        int intAccuracy;
        srand(static_cast<int>(time(0)));
        intAccuracy = 1 + rand()%(2);

        intThug3Accuracy -= intAccuracy * intAccuracyLowered;

        intLlamaEXP += intAccuracy * intAccuracyLowered * 20;
        system("CLS");
        cout << strLlamasName << " lowered Thug 3's Accuracy by " << intAccuracy * intAccuracyLowered << ", Thug 3 has " << intThug3HP << " HP left." << endl;
        cout << endl;
        system("Pause");

        }
    }

    if (intLlamaChoice == 2)
    {
    int intItemChoice;
    system("CLS");
    cout << "Items:" << endl;
    cout << "(1) " << strYourHamstersName << "'s Wheel" << endl;
        if (intJello != 0)
        {
        cout << "(2) A Jell-O Pack (Will increase the hits of " << strWeaselsName << "'s Knife)" << endl;
        }
        if (intBlanket != 0)
        {
        cout << "(3) A Blanket (Will trap the enemy for a turn, will be used up)" << endl;
        }
        cout << endl;
        cin >> intItemChoice;

        if (intItemChoice == 2)
        {
        system("CLS");
        cout << strLlamasName << " is not " << strWeaselsName << ". Returning back to Attack Menu..." << endl;
        cout << endl;
        system("Pause");
        intLlamaChoice = LlamaFightMenu(intAccuracyLowered, intThug1Accuracy, intThug2Accuracy, intThug3Accuracy, strLlamasName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intLlamaHP, intLlamaEXP, intJello);
        }

        if (intItemChoice == 1)
        {
        system("CLS");
        cout << strLlamasName << " has nothing to recharge. Returning back to Attack Menu..." << endl;
        cout << endl;
        system("Pause");
        intLlamaChoice = LlamaFightMenu(intAccuracyLowered, intThug1Accuracy, intThug2Accuracy, intThug3Accuracy, strLlamasName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intLlamaHP, intLlamaEXP, intJello);
        }

        if (intItemChoice == 3)
        {
        system("CLS");
        cout << strLlamasName << " stunned Thugs Your blanket can no longer be used. It was torn up while they were trying to escape." << endl;
        cout << endl;
        intBlanket -= 1;
        intStunned += 1;
        system("Pause");
        }
    }

    if (intLlamaChoice == 3)
    {
    system("CLS");
    cout << strLlamasName << ":" << endl;
    cout << "Stats:" << endl;
    cout << "Accuracy Lowered: " << intAccuracyLowered << endl;
    cout << "HP: " << intLlamaHP << endl;
    cout << "EXP: " << intLlamaEXP << endl;
    cout << endl;
    system("Pause");
    intLlamaChoice = LlamaFightMenu(intAccuracyLowered, intThug1Accuracy, intThug2Accuracy, intThug3Accuracy, strLlamasName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intLlamaHP, intLlamaEXP, intJello);
    }

    if (intLlamaChoice == 4)
    {
    FightHelp(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, strYourHamstersName);
    intLlamaChoice = LlamaFightMenu(intAccuracyLowered, intThug1Accuracy, intThug2Accuracy, intThug3Accuracy, strLlamasName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intLlamaHP, intLlamaEXP, intJello);
    }

    if (intLlamaChoice == 5)
    {
    system("CLS");
    }
return (intLlamaChoice);
}

void Thug1(int intThug1HP, int intThug1Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName)
{
    if (intThug1HP > 0)
    {
    system("CLS");

    int intCharacterHit;

    srand(static_cast<int>(time(0)));
    intCharacterHit = 1 + rand()%(4);

        if (intCharacterHit == 1)
        {
            if (intThug1Accuracy <= 0)
            {

            cout << "Thug 1 tried to hit " << strYourName << " with a Baseball Bat but missed! Your HP is still at " << intYourHP << endl;
            cout << endl;
            system("Pause");

            }

            if (intThug1Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intThug1Accuracy;

                if (intChanceToHit <= 0)
                {
                intYourHP -= 1;

                cout << "Thug 1 hit " << strYourName << " with a Baseball Bat! You lost 1 HP. Your HP is now " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Thug 1 tried to hit " << strYourName << " with a Baseball Bat but missed! Your HP is still at " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 2)
        {
            if (intThug1Accuracy <= 0)
            {
            cout << "Thug 1 tried to hit " << strYourGirlfriendsName << " with a Baseball Bat but missed! Your HP is still " << intGFHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intThug1Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intThug1Accuracy;

                if (intChanceToHit <= 0)
                {
                intGFHP -= 1;

                cout << "Thug 1 hit " << strYourGirlfriendsName << " with a Baseball Bat! You lost 1 HP. Your HP is now " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Thug 1 tried to hit " << strYourGirlfriendsName << " with a Baseball Bat but missed! Your HP is still at " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 3)
        {
            if (intThug1Accuracy <= 0)
            {
            cout << "Thug 1 tried to hit " << strWeaselsName << " with a Baseball Bat but missed! Your HP is still at " << intWeaselHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intThug1Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intThug1Accuracy;

                if (intChanceToHit <= 0)
                {
                intWeaselHP -= 1;

                cout << "Thug 1 hit " << strWeaselsName << " with a Baseball Bat! You lost 1 HP. Your HP is now " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Thug 1 tried to hit " << strWeaselsName << " with a Baseball Bat but missed! Your HP is still at " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 4)
        {

            if (intThug1Accuracy <= 0)
            {
            cout << "Thug 1 tried to hit " << strLlamasName << " with a Baseball Bat but missed! Your HP is still at " << intLlamaHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intThug1Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intThug1Accuracy;

                if (intChanceToHit <= 0)
                {
                intLlamaHP -= 1;

                cout << "Thug 1 hit " << strLlamasName << " with a Baseball Bat! You lost 1 HP. Your HP is now " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Thug 1 tried to hit " << strLlamasName << " with a Baseball Bat but missed! Your HP is still at " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }
    }
    if (intThug1HP < 0)
    {
    system("CLS");
    cout << "Thug 1 is Dead!" << endl;
    cout << endl;
    system("Pause");
    }
}

void Thug2(int intThug2HP, int intThug2Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName)
{
    if (intThug2HP > 0)
    {
    system("CLS");

    int intCharacterHit;

    srand(static_cast<int>(time(0)));
    intCharacterHit = 1 + rand()%(4);

        if (intCharacterHit == 1)
        {
            if (intThug2Accuracy <= 0)
            {

            cout << "Thug 2 tried to hit " << strYourName << " with a Baseball Bat but missed! Your HP is still at " << intYourHP << endl;
            cout << endl;
            system("Pause");

            }

            if (intThug2Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intThug2Accuracy;

                if (intChanceToHit <= 0)
                {
                intYourHP -= 1;

                cout << "Thug 2 hit " << strYourName << " with a Baseball Bat! You lost 1 HP. Your HP is now " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Thug 2 tried to hit " << strYourName << " with a Baseball Bat but missed! Your HP is still at " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 2)
        {
            if (intThug2Accuracy <= 0)
            {
            cout << "Thug 2 tried to hit " << strYourGirlfriendsName << " with a Baseball Bat but missed! Your HP is still " << intGFHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intThug2Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intThug2Accuracy;

                if (intChanceToHit <= 0)
                {
                intGFHP -= 1;

                cout << "Thug 2 hit " << strYourGirlfriendsName << " with a Baseball Bat! You lost 1 HP. Your HP is now " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Thug 2 tried to hit " << strYourGirlfriendsName << " with a Baseball Bat but missed! Your HP is still at " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 3)
        {
            if (intThug2Accuracy <= 0)
            {
            cout << "Thug 2 tried to hit " << strWeaselsName << " with a Baseball Bat but missed! Your HP is still at " << intWeaselHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intThug2Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intThug2Accuracy;

                if (intChanceToHit <= 0)
                {
                intWeaselHP -= 1;

                cout << "Thug 2 hit " << strWeaselsName << " with a Baseball Bat! You lost 1 HP. Your HP is now " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Thug 2 tried to hit " << strWeaselsName << " with a Baseball Bat but missed! Your HP is still at " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 4)
        {

            if (intThug2Accuracy <= 0)
            {
            cout << "Thug 2 tried to hit " << strLlamasName << " with a Baseball Bat but missed! Your HP is still at " << intLlamaHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intThug2Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intThug2Accuracy;

                if (intChanceToHit <= 0)
                {
                intLlamaHP -= 1;

                cout << "Thug 2 hit " << strLlamasName << " with a Baseball Bat! You lost 1 HP. Your HP is now " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Thug 2 tried to hit " << strLlamasName << " with a Baseball Bat but missed! Your HP is still at " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }
    }
    if (intThug2HP < 0)
    {
    system("CLS");
    cout << "Thug 2 is Dead!" << endl;
    cout << endl;
    system("Pause");
    }
}

void Thug3(int intThug3HP, int intThug3Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName)
{
    if (intThug3HP > 0)
    {
    system("CLS");

    int intCharacterHit;

    srand(static_cast<int>(time(0)));
    intCharacterHit = 1 + rand()%(4);

        if (intCharacterHit == 1)
        {
            if (intThug3Accuracy <= 0)
            {

            cout << "Thug 3 tried to hit " << strYourName << " with a Baseball Bat but missed! Your HP is still at " << intYourHP << endl;
            cout << endl;
            system("Pause");

            }

            if (intThug3Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intThug3Accuracy;

                if (intChanceToHit <= 0)
                {
                intYourHP -= 1;

                cout << "Thug 3 hit " << strYourName << " with a Baseball Bat! You lost 1 HP. Your HP is now " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Thug 3 tried to hit " << strYourName << " with a Baseball Bat but missed! Your HP is still at " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 2)
        {
            if (intThug3Accuracy <= 0)
            {
            cout << "Thug 3 tried to hit " << strYourGirlfriendsName << " with a Baseball Bat but missed! Your HP is still " << intGFHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intThug3Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intThug3Accuracy;

                if (intChanceToHit <= 0)
                {
                intGFHP -= 1;

                cout << "Thug 3 hit " << strYourGirlfriendsName << " with a Baseball Bat! You lost 1 HP. Your HP is now " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Thug 3 tried to hit " << strYourGirlfriendsName << " with a Baseball Bat but missed! Your HP is still at " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 3)
        {
            if (intThug3Accuracy <= 0)
            {
            cout << "Thug 3 tried to hit " << strWeaselsName << " with a Baseball Bat but missed! Your HP is still at " << intWeaselHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intThug3Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intThug3Accuracy;

                if (intChanceToHit <= 0)
                {
                intWeaselHP -= 1;

                cout << "Thug 3 hit " << strWeaselsName << " with a Baseball Bat! You lost 1 HP. Your HP is now " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Thug 3 tried to hit " << strWeaselsName << " with a Baseball Bat but missed! Your HP is still at " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 4)
        {

            if (intThug3Accuracy <= 0)
            {
            cout << "Thug 3 tried to hit " << strLlamasName << " with a Baseball Bat but missed! Your HP is still at " << intLlamaHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intThug3Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intThug3Accuracy;

                if (intChanceToHit <= 0)
                {
                intLlamaHP -= 1;

                cout << "Thug 3 hit " << strLlamasName << " with a Baseball Bat! You lost 1 HP. Your HP is now " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Thug 3 tried to hit " << strLlamasName << " with a Baseball Bat but missed! Your HP is still at " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }
    }
    if (intThug3HP < 0)
    {
    system("CLS");
    cout << "Thug 3 is Dead!" << endl;
    cout << endl;
    system("Pause");
    }
}

void CharactersMeet(string strWeaselsName, string strLlamasName, string strYourGirlfriendsName, string strYourName)
{
system("CLS");

cout << strYourName << ", " << strYourGirlfriendsName << ", " << strWeaselsName << " and " << strLlamasName << " all finally meet properly. " << strWeaselsName << " tells you how he was working on an oil rig when all the sudden he got turned into a Weasel." << endl;
cout << "He also explains that " << strLlamasName << " is a Llama that he happened to come across while trying to get to safety. They traveled together through Florida" << endl;
cout << "until they ended up here. She can communicate with him, but only him and other Weasels. He has to interpret what she says for others. He says that he wants" << endl;
cout << "to figure out why this happened and get to somewhere safe where he wont be attacked. What will you do next?" << endl;
cout << endl;
system("Pause");
MainDirection(intDirection);
}

void MainDirection(int &intDirection)
{
system("CLS");



srand(static_cast<int>(time(0)));
intDirection = 1 + rand()%(3);

    if (intDirection == 1)
    {
    GoSouth();
    }

    if (intDirection == 2)
    {
    GoNorthWest(strYourGirlfriendsName);
    }


    if (intDirection == 3)
    {
    GoNorth();
    }

}

void GoSouth()
{
system("CLS");

cout << "You decide to go South, it may not be the easiest but it will probably be the fastest and least risky path to take to get to the Midwest. If you can try to find a Boat and sail there." << endl;
cout << "The only problem is you will have to go through the Everglades. Likely coming across some pretty bad creatures like Alligators, Snakes and other creatures like Poisonous Spiders." << endl;
cout << "But your taking the risks you can to get to safety. You have been traveling for a few weeks and in the meantime society has crumbled. People have been killing each other so" << endl;
cout << "much that the population has dwindled there's not many people left." << endl;
cout << endl;
system("Pause");
Traveling(intDirection, strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, intRing);
}

void GoNorthWest(string strYourGirlfriendsName)
{
system("CLS");

cout << "You decide to go NorthWest, after all it is the most direct path Midwest. You plan to go through the panhandle then head straight west until you find a good open desert that you can be" << endl;
cout << "completely sure is safe. You wanna play things safe and try not to get into any trouble. you just wanna be safe somewhere so that you can propose to " << strYourGirlfriendsName << " and live a good life together." << endl;
cout << "But unfortunately your worried that wont ever happen. You have been traveling for a few weeks and in the meantime society has crumbled. People have been killing each other so" << endl;
cout << "much that the population has dwindled there's not many people left." << endl;
cout << endl;
system("Pause");
Traveling(intDirection, strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, intRing);

}

void GoNorth()
{
system("CLS");

cout << "You decide to go North, your determined to find out answers about how and why this happened. Was it just random? Was it some kind of conspiracy? Who knows? You wanna go through any state" << endl;
cout << "capitols you can find. After that you wanna get to DC, talk to The President if you can, but it might be taken over by then. Who knows with the way the world is going. But your focused on" << endl;
cout << "one thing and one thing only, Finding Answers. You have been traveling for a few weeks and in the meantime society has crumbled. People have been killing each other so" << endl;
cout << "much that the population has dwindled there's not many people left." << endl;
cout << endl;
system("Pause");
Traveling(intDirection, strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, intRing);

}

void Traveling(int intDirection, string strWeaselsName, string strLlamasName, string strYourGirlfriendsName, string strYourName, int &intRing)
{
    if (intDirection == 1)
    {
    system("CLS");

    int intPettingResponse;

    cout << "You start heading down towards The Everglades, its gonna be a long walk down there. You start talking with " << strWeaselsName << " trying to get to know him better. You ask him if he" << endl;
    cout << "has any family or anyone out there. He tells you that he had a wife and kid but he went through a messy divorce and hasn't seen his daughter in years. You feel sorry for him" << endl;
    cout << "and slightly worried that you'll end up like him all alone out there. Even worse he got turned into a Weasel and there isn't any way to change him back. " << strYourGirlfriendsName << endl;
    cout << "scoops him up in her arms and starts petting him. " << strWeaselsName << " yells 'Hey put me down! Just because I'm an animal doesn't mean you can treat me like one.' But he gives up" << endl;
    cout << strWeaselsName << " knows that " << strYourGirlfriendsName << " wont put him down no matter what he does. She says '" << strWeaselsName << " your so cute as a Weasel! I can't help myself and your fur is so soft." << endl;
    cout << "Someone has got to pet you, doesn't it feel good like a massage?' " << strWeaselsName << " mutters 'I guess it does feel pretty nice' and then thanks her. " << strYourGirlfriendsName << " says" << endl;
    cout << "'Of course, I love helping people' as she gives you a hug, squishing " << strWeaselsName << " in between us. 'HEY, I'm getting squished in here!' " << strYourGirlfriendsName << " laughs 'I know." << endl;
    cout << "Just because I'm nice doesn't mean I'm not gonna mess with you'" << endl;
    cout << endl;
    cout << endl;
    cout << "How will you respond?" << endl;
    cout << "(1) Agree with your Girlfriend, its ok to mess around" << endl;
    cout << "(2) Agree with the Weasel, leave him alone" << endl;
    cout << "(3) Change the subject hoping that they'll stop arguing" << endl;
    cout << endl;
    cin >> intPettingResponse;

        if (intPettingResponse == 1)
        {
        GirlfriendPet(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName);
        }

        if (intPettingResponse == 2)
        {
        WeaselPet(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName);
        }

        if (intPettingResponse == 3)
        {
        StopPetting(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName);
        }
    }

    if (intDirection == 2)
    {
    system("CLS");

    int intProposal;

    cout << "You start heading towards the Midwest, hopefully this is the fastest most direct way to get there. You start talking with " << strYourGirlfriendsName << " 'The whole world really has" << endl;
    cout << "changed. I was hoping for us to get married have kids and live a normal life together. Now I'm just hoping that we survive and make it through the next day together.' She responds" << endl;
    cout << "'Don't worry Babe, we'll get through this. You and me have been through some pretty tough things, I'm not leaving you now or ever. We got this as long as we stick together.'" << endl;
    cout << "You remember that you have a ring ready to propose. This might be a good time..." << endl;
    cout << endl;
    cout << endl;
    cout << "Will you propose?" << endl;
    cout << "(1) Yes, propose to " << strYourGirlfriendsName << endl;
    cout << "(2) No, just keep going" << endl;
    cout << "(3) Offer to see if you can sell it for supplies" << endl;
    cout << endl;
    cin >> intProposal;

        if (intProposal == 1)
        {
        intRing = 1;
        Proposal(strYourGirlfriendsName, strWeaselsName);
        }

        if (intProposal == 2)
        {
        KeepGoing();
        }

        if (intProposal == 3)
        {
        SellRing(strYourGirlfriendsName, intRing);
        }
    }

    if (intDirection == 3)
    {
    system("CLS");

    int intDreamAnswer;

    cout << "You ask " << strLlamasName << " what you think that they'll find when they get to the capitol? She communicates with " << strWeaselsName << " and tells him that she thinks 'We will find a bunch of Llama's" << endl;
    cout << "are responsible for all this.' You ask her why she thinks that. " << strWeaselsName << " says 'Nope no way thats true, she must be crazy' You ask him 'What?' and he says 'Aliens have been slowly" << endl;
    cout << "replacing Llama's and she's one of them.' You are amazed, there's no way that's true, is there? Suddenly you wake up, 'Oh that was a crazy dream, I have to stop thinking about so many" << endl;
    cout << "conspiracy theories or I'm gonna start going insane.' " <<strYourGirlfriendsName << "asks you 'What happened you were tossing and turning in your sleep?'" << endl;
    cout << endl;
    cout << endl;
    cout << "How will you respond:" << endl;
    cout << "(1) It was just a bad dream" << endl;
    cout << "(2) I dreamed aliens were replacing Llama's" << endl;
    cout << "(3) It was about you" << endl;
    cout << endl;
    cin >> intDreamAnswer;


        if (intDreamAnswer == 1)
        {
        TalkAboutDream(strWeaselsName, strLlamasName, strYourGirlfriendsName);
        }

        if (intDreamAnswer == 2)
        {
        StrangeDream(strWeaselsName, strLlamasName, strYourGirlfriendsName);
        }

        if (intDreamAnswer == 3)
        {
        DreamLie(strWeaselsName, strYourGirlfriendsName);
        }
    }
}

void GirlfriendPet(string strWeaselsName, string strLlamasName, string strYourGirlfriendsName, string strYourName)
{
system("CLS");

cout << "'I have to agree with " << strYourGirlfriendsName << " on this one, there's nothing wrong with us joking around together. After all who knows how long we're gonna be stuck together' " << strWeaselsName << " responds" << endl;
cout << "'Yea i guess this old grump has to get used to being around young people again' " << strYourGirlfriendsName << " laughs 'Your aging yourself " << strWeaselsName << ", don't you think?' He giggles 'Yea, guess I am, thanks" << endl;
cout << "for keeping my spirits up.' You respond 'No problem thats what we're here for. Well that and getting somewhere safe.' You look at a map you found on the road..." << endl;
cout << endl;
cout << endl;
Map1();
cout << endl;
cout << endl;
cout << "Your getting really close to the Everglades. Hopefully we can get there fast, we don't wanna get hurt." << endl;
cout << endl;
system("Pause");
Crocodiles();
}

void Map1()
{
cout << "                _                                                               " << endl;
cout << "You are here: '|!|'                                                             " << endl;
cout <<                                                                                       endl;
cout << " %@@@@@@@@@@@@@@@@@@@@@@@@@@@@                                                  " << endl;
cout << "  @@&                        @@@@&&&&#/,..               &@,@@@@/               " << endl;
cout << "    @&                                         .,*(%@@@@@@%    @@               " << endl;
cout << "   @@&@@@@@@@@@@@@#                                            .@/              " << endl;
cout << "                   *@@@/           #@@@%.                       &@              " << endl;
cout << "                        @@,    .@@@     .@@,                     @&             " << endl;
cout << "                         @@@@@@.           @@                    ,@#            " << endl;
cout << "                                            .@@                   /@*           " << endl;
cout << "                                              /@@#/                /@/          " << endl;
cout << "                                                  (@                .@@         " << endl;
cout << "                                                  *@*                 %@(       " << endl;
cout << "                                                   (@                   @@      " << endl;
cout << "                                                   @@         _        ,@*      " << endl;
cout << "                                                  @@         |!|        @@      " << endl;
cout << "                                                  @&                     @&     " << endl;
cout << "                                                  @@                      @%    " << endl;
cout << "                                                  .@&                     ,@#   " << endl;
cout << "                                                    @@                     *@#  " << endl;
cout << "                                                     *@/                    *@* " << endl;
cout << "                                                      .@/                    &@ " << endl;
cout << "                                                       /@*                   #@ " << endl;
cout << "                                                         *@@@                @@ " << endl;
cout << "                                                           .@(               @& " << endl;
cout << "                                                            @@(             .@% " << endl;
cout << "                                                               ,@@*        %@#  " << endl;
cout << "                                                                 .@%       @#   " << endl;
cout << "                                                                  @%     /@@    " << endl;
cout << "                                                                  *@@@,#/       " << endl;
}

void WeaselPet(string strWeaselsName, string strLlamasName, string strYourGirlfriendsName, string strYourName)
{
system("CLS");

cout << "'I have to agree with " << strWeaselsName << " here. Leave the poor old man alone. He responds 'Hey who are you calling Old?' You stay there silent. 'Sorry' you mutter. He replies 'Don't worry" << endl;
cout << "about it kid. If your gonna mess with me, cant I mess with you?' He gives you a hug. 'Thanks for sticking up for me kiddo.' " << strYourGirlfriendsName << " juts in 'Hey what about me?'" << endl;
cout << "he responds 'Your just a pain' half kidding. You see a map dragging across the ground in the wind. 'Hey we should see how close we are..." << endl;
cout << endl;
cout << endl;
Map1();
cout << endl;
cout << endl;
cout << "We're getting really close to the Everglades. Hopefully we can get there and find a boat without issues.'" << endl;
cout << endl;
system("Pause");
Crocodiles();
}

void StopPetting(string strWeaselsName, string strLlamasName, string strYourGirlfriendsName, string strYourName)
{
system("CLS");

cout << "You say nothing. " << strWeaselsName << " shrugs 'Whatever, thanks for sticking up for me " << strYourName << "' he says sarcastically. You respond 'Sorry, i just didn't want to make someone" << endl;
cout << "more upset.' He says 'At least I have " << strLlamasName << " on my side.' After he says that, " << strLlamasName << " spits on him and everyone bursts into laughter. 'What do you mean stop" << endl;
cout << "being a jerk, you just spat on me.' He shakes off all the spit and hops on " << strLlamasName << "'For that your giving me a ride for a while.' The llama picks up a map on the ground. He says" << endl;
cout << endl;
cout << endl;
Map1();
cout << endl;
cout << endl;
cout << "'Hey look at how close we are. We should be to the southern ports in the next few days.'" << endl;
cout << endl;
system("Pause");
Crocodiles();
}

void Proposal(string strYourGirlfriendsName, string strWeaselsName)
{
system("CLS");

cout << "You pull out the box and start to lower down to your knee, " << strWeaselsName << " says 'Oh god, the lovebirds are at it again' You ignore him and say '" << strYourGirlfriendsName << " will you marry me?'" << endl;
cout << strYourGirlfriendsName << " gives you a huge hug and kisses you. She puts the Ring on and is super happy and excited. She asks 'How are we gonna get married when the world is in ruins?'" << endl;
cout << "You respond 'Whenever you want to get married we can make something work.' She kisses you again. 'Thank you babe its beautiful!' You see a map rolling across the road and pick it up" << endl;
cout << "We should see where we are..." << endl;
cout << endl;
cout << endl;
Map2();
cout << endl;
cout << endl;
cout << "'Hey we're almost out of Florida. We should be able to get to Georgia tomorrow.'" << endl;
cout << endl;
system("Pause");
BikerGang();
}

void Map2()
{
cout << "                _                                                               " << endl;
cout << "You are here: '|!|'                                                             " << endl;
cout <<                                                                                       endl;
cout << " %@@@@@@@@@@@@@@@@@@@@@@@@@@@@                                                  " << endl;
cout << "  @@&                        @@@@&&&&#/,..               &@,@@@@/               " << endl;
cout << "    @&                                         .,*(%@@@@@@%    @@               " << endl;
cout << "   @@&@@@@@@@@@@@@#         _                                  .@/              " << endl;
cout << "                   *@@@/   |!|     #@@@%.                       &@              " << endl;
cout << "                        @@,    .@@@     .@@,                     @&             " << endl;
cout << "                         @@@@@@.           @@                    ,@#            " << endl;
cout << "                                            .@@                   /@*           " << endl;
cout << "                                              /@@#/                /@/          " << endl;
cout << "                                                  (@                .@@         " << endl;
cout << "                                                  *@*                 %@(       " << endl;
cout << "                                                   (@                   @@      " << endl;
cout << "                                                   @@                  ,@*      " << endl;
cout << "                                                  @@                    @@      " << endl;
cout << "                                                  @&                     @&     " << endl;
cout << "                                                  @@                      @%    " << endl;
cout << "                                                  .@&                     ,@#   " << endl;
cout << "                                                    @@                     *@#  " << endl;
cout << "                                                     *@/                    *@* " << endl;
cout << "                                                      .@/                    &@ " << endl;
cout << "                                                       /@*                   #@ " << endl;
cout << "                                                         *@@@                @@ " << endl;
cout << "                                                           .@(               @& " << endl;
cout << "                                                            @@(             .@% " << endl;
cout << "                                                               ,@@*        %@#  " << endl;
cout << "                                                                 .@%       @#   " << endl;
cout << "                                                                  @%     /@@    " << endl;
cout << "                                                                  *@@@,#/       " << endl;
}

void KeepGoing()
{
system("CLS");

cout << "You just wanna keep going your focused on getting to safety so that someday you can propose. You try to look for something to help guide you so you know your going the right" << endl;
cout << "direction. You've been going purely based off memory which isn't the best. Eventually you find an abandoned car and break into it. You look in the glove box and see a map in there" << endl;
cout << "You look at the map..." << endl;
cout << endl;
cout << endl;
Map2();
cout << endl;
cout << endl;
cout << "'Hey we're almost out of Florida. We should be able to get to Georgia tomorrow.'" << endl;
cout << endl;
system("Pause");
BikerGang();
}

void SellRing(string strYourGirlfriendsName, int &intRing)
{
system("CLS");

cout << "You pull out your Ring, and you ask " << strYourGirlfriendsName << " if its ok to sell this. She was excited that you were gonna propose to her but she sadly agrees. Money could be useful" << endl;
cout << "You can tell she's sad but unfortunately this is the best way to ensure that you guys can get a boat. You go to a pawn shop one of the few that are still working. They offer you" << endl;
cout << "$500.00 and you agree. You give them the ring, but hopefully you can get one again someday. You get a map for free while your there." << endl;
intRing = 0;
cout << endl;
cout << endl;
Map2();
cout << endl;
cout << endl;
cout << "'Hey we're almost out of Florida. We should be able to get to Georgia tomorrow.'" << endl;
cout << endl;
system("Pause");
BikerGang();
}

void TalkAboutDream(string strWeaselsName, string strLlamasName, string strYourGirlfriendsName)
{
system("CLS");

cout << "She asks 'What was the dream about?' You tell her 'I feel crazy for dreaming about this, but " << strWeaselsName << " told me that " << strLlamasName << " was an Alien and that Aliens have been" << endl;
cout << "slowly replacing Llama's, I know it sounds crazy' " << strYourGirlfriendsName << " interjects 'It is a little crazy, but i understand. This feels really crazy and its a lot to handle" << endl;
cout << "i think all of us here really wanna know why this is happening, your brain just tried to give you a solution.' she sighs 'Dont worry there is no way that " << strLlamasName << "is definitely" << endl;
cout << "not an alien.' She hugs you, 'Thanks for Opening up to me.'" << endl;
cout << endl;
cout << endl;
Map3();
cout << endl;
cout << endl;
cout << "'Hey we're near Florida's Capitol. We should be able to get there soon.'" << endl;
cout << endl;
system("Pause");
Weasels();
}

void Map3()
{
cout << "                _                                                               " << endl;
cout << "You are here: '|!|'                                                             " << endl;
cout <<                                                                                       endl;
cout << " %@@@@@@@@@@@@@@@@@@@@@@@@@@@@                                                  " << endl;
cout << "  @@&                        @@@@&&&&#/,..               &@,@@@@/               " << endl;
cout << "    @&                                         .,*(%@@@@@@%    @@               " << endl;
cout << "   @@&@@@@@@@@@@@@#                          _                 .@/              " << endl;
cout << "                   *@@@/           #@@@%.   |!|                 &@              " << endl;
cout << "                        @@,    .@@@     .@@,                     @&             " << endl;
cout << "                         @@@@@@.           @@                    ,@#            " << endl;
cout << "                                            .@@                   /@*           " << endl;
cout << "                                              /@@#/                /@/          " << endl;
cout << "                                                  (@                .@@         " << endl;
cout << "                                                  *@*                 %@(       " << endl;
cout << "                                                   (@                   @@      " << endl;
cout << "                                                   @@                  ,@*      " << endl;
cout << "                                                  @@                    @@      " << endl;
cout << "                                                  @&                     @&     " << endl;
cout << "                                                  @@                      @%    " << endl;
cout << "                                                  .@&                     ,@#   " << endl;
cout << "                                                    @@                     *@#  " << endl;
cout << "                                                     *@/                    *@* " << endl;
cout << "                                                      .@/                    &@ " << endl;
cout << "                                                       /@*                   #@ " << endl;
cout << "                                                         *@@@                @@ " << endl;
cout << "                                                           .@(               @& " << endl;
cout << "                                                            @@(             .@% " << endl;
cout << "                                                               ,@@*        %@#  " << endl;
cout << "                                                                 .@%       @#   " << endl;
cout << "                                                                  @%     /@@    " << endl;
cout << "                                                                  *@@@,#/       " << endl;
}

void StrangeDream(string strWeaselsName, string strLlamasName, string strYourGirlfriendsName)
{
system("CLS");

cout << strYourGirlfriendsName << " tells you 'Wow thats a strange dream, I think the stress is getting to you, why don't you try to get some more rest.' You respond to her 'No, I think I'm" << endl;
cout << "alright. I probably can't fall asleep again anyway.' She responds 'Just try not to let all this craziness in the world get to you, we'll get through this.' You think to" << endl;
cout << "yourself 'What in the world made me dream of that anyway, that's such a strange idea' You look at " << strLlamasName << " 'there's no way that's true is there?" << endl;
cout << "No there can't be.' You get interrupted by " << strWeaselsName << " running towards you with something in his mouth. He hands i to you 'I found a map' You look at it." << endl;
cout << endl;
cout << endl;
Map3();
cout << endl;
cout << endl;
cout << "'Hey we're near Florida's Capitol. We should be able to get there soon.'" << endl;
cout << endl;
system("Pause");
Weasels();
}

void DreamLie(string strWeaselsName, string strYourGirlfriendsName)
{
system("CLS");

cout << "You tell " << strYourGirlfriendsName << " about some made up dream that was romantic with you and her because you don't want to tell her the truth. Your worried that she will think" << endl;
cout << "that your crazy. She looks at you oddly. 'This doesn't seem like something that you would normally dream of, whats gotten into you.' You respond 'I'm not sure maybe the stress is" << endl;
cout << "making me cling to you' " << strYourGirlfriendsName << " hesitantly says 'Okay, I guess that makes sense.' The whole moment becomes really awkward she probably knows your lying." << endl;
cout << "You get interrupted by " << strWeaselsName << " running towards you with something in his mouth. He hands i to you 'I found a map' You look at it." << endl;
cout << endl;
cout << endl;
Map3();
cout << endl;
cout << endl;
cout << "'Hey we're near Florida's Capitol. We should be able to get there soon.'" << endl;
cout << endl;
system("Pause");
Weasels();
}

void Crocodiles()
{
system("CLS");

cout << "You start getting deep into the Everglades where it's like a swamp, it's a little foggy but the biggest impedance is the muck thats all around it slows you down and you cant" << endl;
cout << "move as fast as you could before. You are trying too just get through this as fast as you can. There's a whole bunch of animals around you, you feel like your squashing a" << endl;
cout << "mosquito or spider every second and your seeing snakes slither by you. This is why you hate nature so much, animals suck and plants aren't much better. But despite" << endl;
cout << "all of this you keep on pushing forward. That is until you see 2 Crocodiles coming after you guys. You see whats presumably a big Mother Croc and a Baby Croc coming after you..." << endl;
cout << endl;
system("Pause");
CrocFight(strYourName, strYourGirlfriendsName, strWeaselsName, strLlamasName, intYourHP, intGFHP, intWeaselHP, intLlamaHP, intMommaCrocStun, intBabyCrocStun, intStunned, intYourLevel, intYourEXP, intAttack, intGFLevel, intGFEXP, intStunChance, intWeaselLevel, intWeaselEXP, intHitCount, intLlamaLevel, intLlamaEXP, intAccuracyLowered, intRecharge);
}

void CrocFight(string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, int &intMommaCrocStun, int &intBabyCrocStun, int &intStunned, int &intYourLevel, int &intYourEXP, int &intAttack, int &intGFLevel, int &intGFEXP, int &intStunChance, int &intWeaselLevel, int &intWeaselEXP, int &intHitCount, int &intLlamaLevel, int &intLlamaEXP, int &intAccuracyLowered, int &intRecharge)
{
system("CLS");

int intYourMoveChoice;
int intGFMoveChoice;
int intWeaselChoice;
int intLlamaChoice;

cout << "You are Presented with a Momma and Baby Croc to fight." << endl;
cout << "Momma Croc has 2 Attack and 20 Health. Baby Croc has 1 Attack and 15 Health." << endl;
cout << endl;
system("Pause");
    do
    {

    if (intYourHP > 0)
    {
    intYourMoveChoice = YourCrocFightMenu(intRecharge, intElectricShotgunCharge, intAttack, intMommaCrocHP, intBabyCrocHP, strYourName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intYourHP, intYourEXP, intJello);
    }

    if (intYourHP < 0)
    {
    system("CLS");
    cout << strYourName << " is Knocked out!" << endl;
    system("Pause");
    }

    if (intYourMoveChoice == 5)
    {
    break;
    }

    if (intGFHP > 0)
    {
    intGFMoveChoice = GFCrocFightMenu(intRecharge, intHairStraightenerCharge, intStunChance, intMommaCrocStun, intBabyCrocStun, strYourGirlfriendsName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intGFHP, intGFEXP, intJello);
    }

    if (intGFHP < 0)
    {
    system("CLS");
    cout << strYourGirlfriendsName << " is Knocked out!" << endl;
    system("Pause");
    }

    if (intGFMoveChoice == 5)
    {
    break;
    }
        if (intRecharge != 1 && intWeaselHP > 0)
        {
        intWeaselChoice = WeaselCrocFightMenu(intHitCount, intMommaCrocHP, intBabyCrocHP, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intWeaselHP, intWeaselEXP, intJello);
        }

        if (intWeaselHP < 0)
        {
        system("CLS");
        cout << strWeaselsName << " is Knocked out!" << endl;
        system("Pause");
        }

        if (intWeaselChoice == 5)
        {
        break;
        }

        if (intRecharge == 1)
        {
        system("CLS");
        cout << "Weasel is recharging someones weapon, he cannot preform any actions this turn." << endl;
        cout << endl;
        system("Pause");
        intRecharge = 0;
        }

        if (intLlamaHP > 0)
        {
        intLlamaChoice = LlamaCrocFightMenu(intAccuracyLowered, intMommaCrocAccuracy, intBabyCrocAccuracy, strLlamasName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intLlamaHP, intLlamaEXP, intJello);
        }

        if (intLlamaHP < 0)
        {
        system("CLS");
        cout << strLlamasName << " is Knocked out!" << endl;
        system("Pause");
        }

        if (intLlamaChoice == 5)
        {
        break;
        }

        if (intYourHP < 0 && intGFHP < 0 && intWeaselHP < 0 && intLlamaHP < 0)
        {
        Death(intDied);
        }

        if (intMommaCrocStun <= 4 && intStunned == 0)
        {
        MommaCroc(intMommaCrocHP, intMommaCrocAccuracy, intYourHP, intGFHP, intWeaselHP, intLlamaHP, strYourName, strYourGirlfriendsName, strWeaselsName, strLlamasName);
        }

        if (intBabyCrocStun <= 4 && intStunned == 0)
        {
        BabyCroc(intBabyCrocHP, intBabyCrocAccuracy, intYourHP, intGFHP, intWeaselHP, intLlamaHP, strYourName, strYourGirlfriendsName, strWeaselsName, strLlamasName);
        }

        intMommaCrocStun = 0;
        intBabyCrocStun = 0;
        intStunned = 0;

    } while (intMommaCrocHP > 0 || intBabyCrocHP > 0 && intYourMoveChoice != 5 && intGFMoveChoice != 5 && intWeaselChoice != 5 && intLlamaChoice != 5);

    intYourHP = 15;
    intGFHP = 15;
    intWeaselHP = 15;
    intLlamaHP = 15;

    if (intYourEXP >= 500)
    {
    intYourEXP = 0;
    intYourLevel += 1;
    intAttack += 1;
    intMoney += 50;

    system("CLS");
    cout << "You Leveled Up! " << strYourName << " is now Level " << intYourLevel << endl;
    cout << strYourName << " Attack increased to " << intAttack << endl;
    cout << "You gained 50 Bucks! You have " << intMoney << " bucks" << endl;
    system("Pause");
    }

    if (intGFEXP >= 500)
    {
    intGFEXP = 0;
    intGFLevel += 1;
    intStunChance += 1;

    system("CLS");
    cout << strYourGirlfriendsName << " Leveled Up! " << strYourGirlfriendsName << " is now Level " << intGFLevel << endl;
    cout << strYourGirlfriendsName << "'s Stun Chance increased to " << intStunChance << endl;
    system("Pause");
    }

    if (intWeaselEXP >= 500)
    {
    intWeaselEXP = 0;
    intWeaselLevel += 1;
    intHitCount += 1;

    system("CLS");
    cout << strWeaselsName << " Leveled Up! " << strWeaselsName << " is now Level " << intWeaselLevel << endl;
    cout << strWeaselsName << "'s Hit Count increased to " << intHitCount << endl;
    system("Pause");
    }

    if (intLlamaEXP >= 500)
    {
    intLlamaEXP = 0;
    intLlamaLevel += 1;
    intAccuracyLowered += 1;

    system("CLS");
    cout << strLlamasName << " Leveled Up! " << strLlamasName << " is now Level " << intLlamaLevel << endl;
    cout << strLlamasName << "'s Accuracy Lowering increased to " << intAccuracyLowered << endl;
    system("Pause");
    }

BoatEnding();
}

int YourCrocFightMenu(int &intRecharge, int &intElectricShotgunCharge, int intAttack, int &intMommaCrocHP, int &intBabyCrocHP, string strYourName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intYourHP, int intYourEXP, int intJello)
{
int intYourMoveChoice;
system("CLS");

cout << "It is " << strYourName << "'s Turn." << endl;
cout << "What will you do?" << endl;
cout << "(1) Shoot" << endl;
cout << "(2) Items" << endl;
cout << "(3) Stats" << endl;
cout << "(4) Help" << endl;
cout << "(5) Exit" << endl;
cout << endl;
cin >> intYourMoveChoice;

    if (intYourMoveChoice == 1 && intElectricShotgunCharge == 0)
    {
    system("CLS");
    cout << "You have no Charge Left in your Electric Shotgun, Please Recharge it." << endl;
    intYourMoveChoice = 2;
    cout << "Going to items so you can Recharge..." << endl;
    cout << endl;
    system("Pause");
    }

    if (intYourMoveChoice == 1)
    {
    int intEnemyChoice;
    system("CLS");
    cout << "Target an enemy: " << endl;
    cout << "(1) Momma Croc (" << intMommaCrocHP << " HP)" << endl;
    cout << "(2) Baby Croc (" << intBabyCrocHP << " HP)" << endl;
    cout << endl;
    cin >> intEnemyChoice;

        if (intEnemyChoice == 1)
        {
        int intYourDamage;
        srand(static_cast<int>(time(0)));
        intYourDamage = intAttack + rand()%(3);
        intElectricShotgunCharge -= 1;
        intMommaCrocHP -= intYourDamage;

        intYourEXP += intYourDamage * 20;
        system("CLS");
        cout << "You dealt " << intYourDamage << " Damage, Momma Croc has " << intMommaCrocHP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 2)
        {
        int intYourDamage;
        srand(static_cast<int>(time(0)));
        intYourDamage = intAttack + rand()%(3);
        intElectricShotgunCharge -= 1;
        intBabyCrocHP -= intYourDamage;

        intYourEXP += intYourDamage * 20;
        system("CLS");
        cout << "You dealt " << intYourDamage << " Damage, Baby Croc has " << intBabyCrocHP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }
    }
    if (intYourMoveChoice == 2)
    {
    int intItemChoice;
    system("CLS");
    cout << "Items:" << endl;
    cout << "(1) " << strYourHamstersName << "'s Wheel (Will recharge your Electric Shotgun)" << endl;
        if (intJello != 0)
        {
        cout << "(2) A Jell-O Pack (Will increase the hits of " << strWeaselsName << "'s Knife)" << endl;
        }
        if (intBlanket != 0)
        {
        cout << "(3) A Blanket (Will trap the enemy for a turn, will be used up)" << endl;
        }
        cout << endl;
        cin >> intItemChoice;

        if (intItemChoice == 2)
        {
        system("CLS");
        cout << "You are not " << strWeaselsName << ". Returning back to Attack Menu..." << endl;
        cout << endl;
        system("Pause");
        intYourMoveChoice = YourCrocFightMenu(intRecharge, intElectricShotgunCharge, intAttack, intMommaCrocHP, intBabyCrocHP, strYourName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intYourHP, intYourEXP, intJello);
        }

        if (intItemChoice == 1)
        {
        system("CLS");
        intRecharge += 1;
        intElectricShotgunCharge = 5;
        cout << "You successfully recharge your Electric Shotgun" << endl;
        cout << endl;
        system("Pause");
        }

        if (intItemChoice == 3)
        {
        system("CLS");
        cout << "You stunned The Crocs with your blanket can no longer be used. It was torn up while they were trying to escape." << endl;
        intBlanket -= 1;
        intStunned += 1;
        cout << endl;
        system("Pause");
        }
    }

    if (intYourMoveChoice == 3)
    {
    system("CLS");
    cout << strYourName << ":" << endl;
    cout << "Stats:" << endl;
    cout << "Attack: " << intAttack << " To " << intAttack + 2 << endl;
    cout << "HP: " << intYourHP << endl;
    cout << "EXP: " << intYourEXP << endl;
    cout << endl;
    system("Pause");
    intYourMoveChoice = YourCrocFightMenu(intRecharge, intElectricShotgunCharge, intAttack, intMommaCrocHP, intBabyCrocHP, strYourName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intYourHP, intYourEXP, intJello);
    }

    if (intYourMoveChoice == 4)
    {

    FightHelp(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, strYourHamstersName);
    intYourMoveChoice = YourCrocFightMenu(intRecharge, intElectricShotgunCharge, intAttack, intMommaCrocHP, intBabyCrocHP, strYourName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intYourHP, intYourEXP, intJello);
    }

    if (intYourMoveChoice == 5)
    {
    system("CLS");
    }
    return (intYourMoveChoice);
}

int GFCrocFightMenu(int &intRecharge, int &intHairStraightenerCharge, int intStunChance, int &intMommaCrocStun, int &intBabyCrocStun, string strYourGirlfriendsName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intGFHP, int intGFEXP, int intJello)
{
system("CLS");
int intGFMoveChoice;

cout << "It is " << strYourGirlfriendsName << "'s Turn." << endl;
cout << "What will you do?" << endl;
cout << "(1) Stun" << endl;
cout << "(2) Items" << endl;
cout << "(3) Stats" << endl;
cout << "(4) Help" << endl;
cout << "(5) Exit" << endl;
cout << endl;
cin >> intGFMoveChoice;

    if (intGFMoveChoice == 1 && intHairStraightenerCharge == 0)
    {
    system("CLS");
    cout << strYourGirlfriendsName << " has no Charge Left in your Hair Straightener, Please Recharge it." << endl;
    intGFMoveChoice = 2;
    cout << "Going to items so you can Recharge..." << endl;
    cout << endl;
    system("Pause");
    }

    if (intGFMoveChoice == 1)
    {
    int intEnemyChoice;
    system("CLS");
    cout << "Target an enemy: " << endl;
    cout << "(1) Momma Croc (" << intMommaCrocHP << " HP)" << endl;
    cout << "(2) Baby Croc (" << intBabyCrocHP << " HP)" << endl;
    cout << endl;
    cin >> intEnemyChoice;

        if (intEnemyChoice == 1)
        {
        system("CLS");
        srand(static_cast<int>(time(0)));
        intMommaCrocStun = intStunChance + rand()%(10);
        intHairStraightenerCharge -= 1;
            if (intMommaCrocStun >= 5)
            {
            intGFEXP += intMommaCrocStun * 20;
            cout << strYourGirlfriendsName << " Stunned Momma Croc" << endl;
            cout << endl;
            system("Pause");
            }
            else if (intMommaCrocStun <= 5)
            {
            cout << strYourGirlfriendsName << " failed to stun Momma Croc" << endl;
            cout << endl;
            system("Pause");
            }
        }

        if (intEnemyChoice == 2)
        {
        system("CLS");
        srand(static_cast<int>(time(0)));
        intBabyCrocStun = intStunChance + rand()%(10);
        intHairStraightenerCharge -= 1;
            if (intBabyCrocStun >= 5)
            {
            intGFEXP += intBabyCrocStun * 20;
            cout << strYourGirlfriendsName << " Stunned Baby Croc" << endl;
            cout << endl;
            system("Pause");
            }
            else if (intBabyCrocStun <= 5)
            {
            cout << strYourGirlfriendsName << " failed to stun Baby Croc" << endl;
            cout << endl;
            system("Pause");
            }
        }
    }

    if (intGFMoveChoice == 2)
    {
    int intItemChoice;
    system("CLS");
    cout << "Items:" << endl;
    cout << "(1) " << strYourHamstersName << "'s Wheel (Will recharge your Hair Straightener)" << endl;
        if (intJello != 0)
        {
        cout << "(2) A Jell-O Pack (Will increase the hits of " << strWeaselsName << "'s Knife)" << endl;
        }
        if (intBlanket != 0)
        {
        cout << "(3) A Blanket (Will trap the enemy for a turn, will be used up)" << endl;
        }
        cout << endl;
        cin >> intItemChoice;
        if (intItemChoice == 2)
        {
        system("CLS");
        cout << strYourGirlfriendsName << " is not " << strWeaselsName << ". Returning back to Attack Menu..." << endl;
        cout << endl;
        system("Pause");
        intGFMoveChoice = GFCrocFightMenu(intRecharge, intHairStraightenerCharge, intStunChance, intMommaCrocStun, intBabyCrocStun, strYourGirlfriendsName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intGFHP, intGFEXP, intJello);
        }

        if (intItemChoice == 1)
        {
        system("CLS");
        intRecharge += 1;
        intHairStraightenerCharge = 10;
        cout << strYourGirlfriendsName << " successfully recharge your Hair Straightener" << endl;
        cout << endl;
        system("Pause");
        }

        if (intItemChoice == 3)
        {
        system("CLS");
        cout << strYourGirlfriendsName << " stunned Crocs Your blanket can no longer be used. It was torn up while they were trying to escape." << endl;
        cout << endl;
        intBlanket -= 1;
        intStunned += 1;
        system("Pause");
        }
    }

    if (intGFMoveChoice == 3)
    {
    system("CLS");
    cout << strYourGirlfriendsName << ":" << endl;
    cout << "Stats:" << endl;
    cout << "Stun Chance: " << intStunChance << " To 10" << endl;
    cout << "HP: " << intGFHP << endl;
    cout << "EXP: " << intGFEXP << endl;
    cout << endl;
    system("Pause");
    intGFMoveChoice = GFCrocFightMenu(intRecharge, intHairStraightenerCharge, intStunChance, intMommaCrocStun, intBabyCrocStun, strYourGirlfriendsName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intGFHP, intGFEXP, intJello);
    }

    if (intGFMoveChoice == 4)
    {
    FightHelp(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, strYourHamstersName);
    intGFMoveChoice = GFCrocFightMenu(intRecharge, intHairStraightenerCharge, intStunChance, intMommaCrocStun, intBabyCrocStun, strYourGirlfriendsName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intGFHP, intGFEXP, intJello);
    }

    if (intGFMoveChoice == 5)
    {
    system("CLS");
    }
return (intGFMoveChoice);
}

int WeaselCrocFightMenu(int &intHitCount, int &intMommaCrocHP, int &intBabyCrocHP, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intWeaselHP, int intWeaselEXP, int &intJello)
{
system("CLS");
int intWeaselChoice;

cout << "It is " << strWeaselsName << "'s Turn." << endl;
cout << "What will you do?" << endl;
cout << "(1) Slice" << endl;
cout << "(2) Items" << endl;
cout << "(3) Stats" << endl;
cout << "(4) Help" << endl;
cout << "(5) Exit" << endl;
cout << endl;
cin >> intWeaselChoice;

    if (intWeaselChoice == 1)
    {
    int intEnemyChoice;
    system("CLS");
    cout << "Target an enemy: " << endl;
    cout << "(1) Momma Croc (" << intMommaCrocHP << " HP)" << endl;
    cout << "(2) Baby Croc (" << intBabyCrocHP << " HP)" << endl;
    cout << endl;
    cin >> intEnemyChoice;

        if (intEnemyChoice == 1)
        {
        int intDamage;
        srand(static_cast<int>(time(0)));
        intDamage = 1 + rand()%(2);

        intMommaCrocHP -= intHitCount * intDamage;

        intWeaselEXP += intDamage * intHitCount * 20;
        system("CLS");
        cout << strWeaselsName << " dealt " << intDamage * intHitCount << " Damage, with " << intHitCount << " Hits, Momma Croc has " << intMommaCrocHP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 2)
        {
        int intDamage;
        srand(static_cast<int>(time(0)));
        intDamage = 1 + rand()%(2);

        intBabyCrocHP -= intHitCount * intDamage;

        intWeaselEXP += intDamage * intHitCount * 20;
        system("CLS");
        cout << strWeaselsName << " dealt " << intDamage * intHitCount << " Damage, with " << intHitCount << " Hits, Baby Croc has " << intBabyCrocHP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }
    }

    if (intWeaselChoice == 2)
    {
    int intItemChoice;
    system("CLS");
    cout << "Items:" << endl;
    cout << "(1) " << strYourHamstersName << "'s Wheel" << endl;
        if (intJello != 0)
        {
        cout << "(2) A Jell-O Pack (Will increase the hits of " << strWeaselsName << "'s Knife)" << endl;
        }
        if (intBlanket != 0)
        {
        cout << "(3) A Blanket (Will trap the enemy for a turn, will be used up)" << endl;
        }
        cin >> intItemChoice;
        if (intItemChoice == 2)
        {
        system("CLS");
        cout << "You are " << strWeaselsName << ". Increasing Hit Count..." << endl;
        cout << endl;
        intHitCount += 2;
        intJello = 0;
        system("Pause");
        }

        if (intItemChoice == 1)
        {
        system("CLS");
        cout << strWeaselsName << " has nothing to recharge..." << endl;
        system("Pause");
        intWeaselChoice = WeaselCrocFightMenu(intHitCount, intMommaCrocHP, intBabyCrocHP, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intWeaselHP, intWeaselEXP, intJello);
        }

        if (intItemChoice == 3)
        {
        system("CLS");
        cout << strWeaselsName << " stunned Crocs Your blanket can no longer be used. It was torn up while they were trying to escape." << endl;
        intBlanket -= 1;
        intStunned += 1;
        system("Pause");
        system("CLS");
        }
    }

    if (intWeaselChoice == 3)
    {
    system("CLS");
    cout << strWeaselsName << ":" << endl;
    cout << "Stats:" << endl;
    cout << "Hit Count: " << intHitCount << endl;
    cout << "HP: " << intWeaselHP << endl;
    cout << "EXP: " << intWeaselEXP << endl;
    cout << endl;
    system("Pause");
    intWeaselChoice = WeaselCrocFightMenu(intHitCount, intMommaCrocHP, intBabyCrocHP, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intWeaselHP, intWeaselEXP, intJello);
    }

    if (intWeaselChoice == 4)
    {
    FightHelp(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, strYourHamstersName);
    intWeaselChoice = WeaselCrocFightMenu(intHitCount, intMommaCrocHP, intBabyCrocHP, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intWeaselHP, intWeaselEXP, intJello);
    }

    if (intWeaselChoice == 5)
    {
    system("CLS");
    }
return (intWeaselChoice);
}

int LlamaCrocFightMenu(int intAccuracyLowered, int &intMommaCrocAccuracy, int &intBabyCrocAccuracy, string strLlamasName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intLlamaHP, int intLlamaEXP, int intJello)
{
system("CLS");
int intLlamaChoice;

cout << "It is " << strLlamasName << "'s Turn." << endl;
cout << "What will you do?" << endl;
cout << "(1) Spit" << endl;
cout << "(2) Items" << endl;
cout << "(3) Stats" << endl;
cout << "(4) Help" << endl;
cout << "(5) Exit" << endl;
cout << endl;
cin >> intLlamaChoice;

    if (intLlamaChoice == 1)
    {
    int intEnemyChoice;
    system("CLS");
    cout << "Target an enemy: " << endl;
    cout << "(1) Momma Croc (" << intMommaCrocHP << " HP)" << endl;
    cout << "(2) Baby Croc (" << intBabyCrocHP << " HP)" << endl;
    cout << endl;
    cin >> intEnemyChoice;

        if (intEnemyChoice == 1)
        {
        int intAccuracy;
        srand(static_cast<int>(time(0)));
        intAccuracy = 1 + rand()%(2);

        intMommaCrocAccuracy -= intAccuracy * intAccuracyLowered;

        intLlamaEXP += intAccuracy * intAccuracyLowered * 20;
        system("CLS");
        cout << strLlamasName << " lowered Momma Croc's Accuracy by " << intAccuracy * intAccuracyLowered << ", Momma Croc has " << intMommaCrocHP << " HP left." << endl;
        cout << endl;
        system("Pause");

        }

        if (intEnemyChoice == 2)
        {
        int intAccuracy;
        srand(static_cast<int>(time(0)));
        intAccuracy = 1 + rand()%(2);

        intBabyCrocAccuracy -= intAccuracy * intAccuracyLowered;

        intLlamaEXP += intAccuracy * intAccuracyLowered * 20;
        system("CLS");
        cout << strLlamasName << " lowered Baby Croc's Accuracy by " << intAccuracy * intAccuracyLowered << ", Baby Croc has " << intBabyCrocHP << " HP left." << endl;
        cout << endl;
        system("Pause");

        }
    }

    if (intLlamaChoice == 2)
    {
    int intItemChoice;
    system("CLS");
    cout << "Items:" << endl;
    cout << "(1) " << strYourHamstersName << "'s Wheel" << endl;
        if (intJello != 0)
        {
        cout << "(2) A Jell-O Pack (Will increase the hits of " << strWeaselsName << "'s Knife)" << endl;
        }
        if (intBlanket != 0)
        {
        cout << "(3) A Blanket (Will trap the enemy for a turn, will be used up)" << endl;
        }
        cout << endl;
        cin >> intItemChoice;

        if (intItemChoice == 2)
        {
        system("CLS");
        cout << strLlamasName << " is not " << strWeaselsName << ". Returning back to Attack Menu..." << endl;
        cout << endl;
        system("Pause");
        intLlamaChoice = LlamaCrocFightMenu(intAccuracyLowered, intMommaCrocAccuracy, intBabyCrocAccuracy, strLlamasName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intLlamaHP, intLlamaEXP, intJello);
        }

        if (intItemChoice == 1)
        {
        system("CLS");
        cout << strLlamasName << " has nothing to recharge. Returning back to Attack Menu..." << endl;
        cout << endl;
        system("Pause");
        intLlamaChoice = LlamaCrocFightMenu(intAccuracyLowered, intMommaCrocAccuracy, intBabyCrocAccuracy, strLlamasName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intLlamaHP, intLlamaEXP, intJello);
        }

        if (intItemChoice == 3)
        {
        system("CLS");
        cout << strLlamasName << " stunned Crocs Your blanket can no longer be used. It was torn up while they were trying to escape." << endl;
        cout << endl;
        intBlanket -= 1;
        intStunned += 1;
        system("Pause");
        }
    }

    if (intLlamaChoice == 3)
    {
    system("CLS");
    cout << strLlamasName << ":" << endl;
    cout << "Stats:" << endl;
    cout << "Accuracy Lowered: " << intAccuracyLowered << endl;
    cout << "HP: " << intLlamaHP << endl;
    cout << "EXP: " << intLlamaEXP << endl;
    cout << endl;
    system("Pause");
    intLlamaChoice = LlamaCrocFightMenu(intAccuracyLowered, intMommaCrocAccuracy, intBabyCrocAccuracy, strLlamasName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intLlamaHP, intLlamaEXP, intJello);
    }

    if (intLlamaChoice == 4)
    {
    FightHelp(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, strYourHamstersName);
    intLlamaChoice = LlamaCrocFightMenu(intAccuracyLowered, intMommaCrocAccuracy, intBabyCrocAccuracy, strLlamasName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intLlamaHP, intLlamaEXP, intJello);
    }

    if (intLlamaChoice == 5)
    {
    system("CLS");
    }
return (intLlamaChoice);
}

void MommaCroc(int intMommaCrocHP, int intMommaCrocAccuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName)
{
    if (intMommaCrocHP > 0)
    {
    system("CLS");

    int intCharacterHit;

    srand(static_cast<int>(time(0)));
    intCharacterHit = 1 + rand()%(4);

        if (intCharacterHit == 1)
        {
            if (intMommaCrocAccuracy <= 0)
            {

            cout << "Momma Croc tried to bite " << strYourName << " but missed! Your HP is still at " << intYourHP << endl;
            cout << endl;
            system("Pause");

            }

            if (intMommaCrocAccuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intMommaCrocAccuracy;

                if (intChanceToHit <= 0)
                {
                intYourHP -= 2;

                cout << "Momma Croc bit " << strYourName << "! You lost 2 HP. Your HP is now " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Momma Croc tried to bite " << strYourName << " but missed! Your HP is still at " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 2)
        {
            if (intMommaCrocAccuracy <= 0)
            {
            cout << "Momma Croc tried to bite " << strYourGirlfriendsName << " but missed! Your HP is still at " << intGFHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intMommaCrocAccuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intMommaCrocAccuracy;

                if (intChanceToHit <= 0)
                {
                intGFHP -= 2;

                cout << "Momma Croc bit " << strYourGirlfriendsName << "! You lost 2 HP. Your HP is now " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Momma Croc tried to bite " << strYourGirlfriendsName << " but missed! Your HP is still at " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 3)
        {
            if (intMommaCrocAccuracy <= 0)
            {
            cout << "Momma Croc tried to bite " << strWeaselsName << " but missed! Your HP is still at " << intWeaselHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intMommaCrocAccuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intMommaCrocAccuracy;

                if (intChanceToHit <= 0)
                {
                intWeaselHP -= 2;

                cout << "Momma Croc bit " << strWeaselsName << "! You lost 2 HP. Your HP is now " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Momma Croc tried to bite " << strWeaselsName << " but missed! Your HP is still at " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 4)
        {

            if (intMommaCrocAccuracy <= 0)
            {
            cout << "Momma Croc tried to bite " << strLlamasName << " but missed! Your HP is still at " << intLlamaHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intMommaCrocAccuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intMommaCrocAccuracy;

                if (intChanceToHit <= 0)
                {
                intLlamaHP -= 2;

                cout << "Momma Croc bit " << strLlamasName << "! You lost 2 HP. Your HP is now " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Momma Croc tried to bite " << strLlamasName << " but missed! Your HP is still at " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }
    }
    if (intMommaCrocHP < 0)
    {
    system("CLS");
    cout << "Momma Croc is Dead!" << endl;
    cout << endl;
    system("Pause");
    }
}

void BabyCroc(int intBabyCrocHP, int intBabyCrocAccuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName)
{
    if (intBabyCrocHP > 0)
    {
    system("CLS");

    int intCharacterHit;

    srand(static_cast<int>(time(0)));
    intCharacterHit = 1 + rand()%(4);

        if (intCharacterHit == 1)
        {
            if (intBabyCrocAccuracy <= 0)
            {

            cout << "Baby Croc tried to bite " << strYourName << " but missed! Your HP is still at " << intYourHP << endl;
            cout << endl;
            system("Pause");

            }

            if (intBabyCrocAccuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intBabyCrocAccuracy;

                if (intChanceToHit <= 0)
                {
                intYourHP -= 1;

                cout << "Baby Croc bit " << strYourName << "! You lost 1 HP. Your HP is now " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Baby Croc tried to bite " << strYourName << " but missed! Your HP is still at " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 2)
        {
            if (intBabyCrocAccuracy <= 0)
            {
            cout << "Baby Croc tried to bite " << strYourGirlfriendsName << " but missed! You lost 1 HP. Your HP is now " << intGFHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intBabyCrocAccuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intBabyCrocAccuracy;

                if (intChanceToHit <= 0)
                {
                intGFHP -= 1;

                cout << "Baby Croc bit " << strYourGirlfriendsName << "! You lost 1 HP. Your HP is now " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Baby Croc tried to bite " << strYourGirlfriendsName << " but missed! Your HP is still at " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 3)
        {
            if (intBabyCrocAccuracy <= 0)
            {
            cout << "Baby Croc tried to bite " << strWeaselsName << " but missed! Your HP is still at " << intWeaselHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intBabyCrocAccuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intBabyCrocAccuracy;

                if (intChanceToHit <= 0)
                {
                intWeaselHP -= 1;

                cout << "Baby Croc bit " << strWeaselsName << "! You lost 1 HP. Your HP is now " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Baby Croc tried to bite " << strWeaselsName << " but missed! Your HP is still at " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 4)
        {

            if (intBabyCrocAccuracy <= 0)
            {
            cout << "Baby Croc tried to bite " << strLlamasName << " but missed! Your HP is still at " << intLlamaHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intBabyCrocAccuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intBabyCrocAccuracy;

                if (intChanceToHit <= 0)
                {
                intLlamaHP -= 1;

                cout << "Baby Croc bit " << strLlamasName << "! You lost 1 HP. Your HP is now " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Baby Croc tried to bite " << strLlamasName << " but missed! Your HP is still at " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }
    }
    if (intBabyCrocHP < 0)
    {
    system("CLS");
    cout << "Baby Croc is Dead!" << endl;
    cout << endl;
    system("Pause");
    }
}

void BikerGang()
{
system("CLS");

cout << "You get to the border of Florida and Alabama finally able to get closer to the Midwest and get somewhere safe quick. The world already feels like its ended, but getting somewhere" << endl;
cout << "safe will help. You wanna be able to protect everyone with you if you can. But you mostly just wanna live off the grid. You pass over the border and get to the 'Welcome to Alabama'" << endl;
cout << "sign where you see a bunch of bikers. You hope to yourself that they will just leave you alone. Unfortunately they don't. They start riding towards you and you hear them shout" << endl;
cout << "'It's a Weasel, get him!'" << endl;
cout << endl;
system("Pause");
BikerFight(strYourName, strYourGirlfriendsName, strWeaselsName, strLlamasName, intYourHP, intGFHP, intWeaselHP, intLlamaHP, intBiker1Stun, intBiker2Stun, intBiker3Stun, intBiker4Stun, intStunned, intYourLevel, intYourEXP, intAttack, intGFLevel, intGFEXP, intStunChance, intWeaselLevel, intWeaselEXP, intHitCount, intLlamaLevel, intLlamaEXP, intAccuracyLowered, intRecharge);
}

void BikerFight(string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, int &intBiker1Stun, int &intBiker2Stun, int &intBiker3Stun, int &intBiker4Stun, int &intStunned, int &intYourLevel, int &intYourEXP, int &intAttack, int &intGFLevel, int &intGFEXP, int &intStunChance, int &intWeaselLevel, int &intWeaselEXP, int &intHitCount, int &intLlamaLevel, int &intLlamaEXP, int &intAccuracyLowered, int &intRecharge)
{
system("CLS");

int intYourMoveChoice;
int intGFMoveChoice;
int intWeaselChoice;
int intLlamaChoice;

cout << "You are Presented with 4 Bikers to fight." << endl;
cout << "Each Biker has 2 Attack and 12 Health" << endl;
cout << endl;
system("Pause");
    do
    {

    if (intYourHP > 0)
    {
    intYourMoveChoice = YourBikerFightMenu(intRecharge, intElectricShotgunCharge, intAttack, intBiker1HP, intBiker2HP, intBiker3HP, intBiker4HP, strYourName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intYourHP, intYourEXP, intJello);
    }

    if (intYourHP < 0)
    {
    system("CLS");
    cout << strYourName << " is Knocked out!" << endl;
    system("Pause");
    }

    if (intYourMoveChoice == 5)
    {
    break;
    }

    if (intGFHP > 0)
    {
    intGFMoveChoice = GFBikerFightMenu(intRecharge, intHairStraightenerCharge, intStunChance, intBiker1Stun, intBiker2Stun, intBiker3Stun, intBiker4Stun, strYourGirlfriendsName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intGFHP, intGFEXP, intJello);
    }

    if (intGFHP < 0)
    {
    system("CLS");
    cout << strYourGirlfriendsName << " is Knocked out!" << endl;
    system("Pause");
    }

    if (intGFMoveChoice == 5)
    {
    break;
    }
        if (intRecharge != 1 && intWeaselHP > 0)
        {
        intWeaselChoice = WeaselBikerFightMenu(intHitCount, intBiker1HP, intBiker2HP, intBiker3HP, intBiker4HP, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intWeaselHP, intWeaselEXP, intJello);
        }

        if (intWeaselHP < 0)
        {
        system("CLS");
        cout << strWeaselsName << " is Knocked out!" << endl;
        system("Pause");
        }

        if (intWeaselChoice == 5)
        {
        break;
        }

        if (intRecharge == 1)
        {
        system("CLS");
        cout << "Weasel is recharging someones weapon, he cannot preform any actions this turn." << endl;
        cout << endl;
        system("Pause");
        intRecharge = 0;
        }

        if (intLlamaHP > 0)
        {
        intLlamaChoice = LlamaBikerFightMenu(intAccuracyLowered, intBiker1Accuracy, intBiker2Accuracy, intBiker3Accuracy, intBiker4Accuracy, strLlamasName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intLlamaHP, intLlamaEXP, intJello);
        }

        if (intLlamaHP < 0)
        {
        system("CLS");
        cout << strLlamasName << " is Knocked out!" << endl;
        system("Pause");
        }

        if (intLlamaChoice == 5)
        {
        break;
        }

        if (intBiker1Stun <= 4 && intStunned == 0)
        {
        Biker1(intBiker1HP, intBiker1Accuracy, intYourHP, intGFHP, intWeaselHP, intLlamaHP, strYourName, strYourGirlfriendsName, strWeaselsName, strLlamasName);
        }

        if (intBiker2Stun <= 4 && intStunned == 0)
        {
        Biker2(intBiker2HP, intBiker2Accuracy, intYourHP, intGFHP, intWeaselHP, intLlamaHP, strYourName, strYourGirlfriendsName, strWeaselsName, strLlamasName);
        }

        if (intBiker3Stun <= 4 && intStunned == 0)
        {
        Biker3(intBiker3HP, intBiker3Accuracy, intYourHP, intGFHP, intWeaselHP, intLlamaHP, strYourName, strYourGirlfriendsName, strWeaselsName, strLlamasName);
        }

        if (intBiker4Stun <= 4 && intStunned == 0)
        {
        Biker4(intBiker4HP, intBiker4Accuracy, intYourHP, intGFHP, intWeaselHP, intLlamaHP, strYourName, strYourGirlfriendsName, strWeaselsName, strLlamasName);
        }

        intBiker1Stun = 0;
        intBiker2Stun = 0;
        intBiker3Stun = 0;
        intBiker4Stun = 0;
        intStunned = 0;

    } while (intBiker1HP > 0 || intBiker2HP > 0 || intBiker3HP > 0 || intBiker4HP > 0 && intYourMoveChoice != 5 && intGFMoveChoice != 5 && intWeaselChoice != 5 && intLlamaChoice != 5);

    intYourHP = 15;
    intGFHP = 15;
    intWeaselHP = 15;
    intLlamaHP = 15;

        if (intYourEXP >= 500)
    {
    intYourEXP = 0;
    intYourLevel += 1;
    intAttack += 1;
    intMoney += 50;

    system("CLS");
    cout << "You Leveled Up! " << strYourName << " is now Level " << intYourLevel << endl;
    cout << strYourName << " Attack increased to " << intAttack << endl;
    cout << "You gained 50 Bucks! You have " << intMoney << " bucks" << endl;
    system("Pause");
    }

    if (intGFEXP >= 500)
    {
    intGFEXP = 0;
    intGFLevel += 1;
    intStunChance += 1;

    system("CLS");
    cout << strYourGirlfriendsName << " Leveled Up! " << strYourGirlfriendsName << " is now Level " << intGFLevel << endl;
    cout << strYourGirlfriendsName << "'s Stun Chance increased to " << intStunChance << endl;
    system("Pause");
    }

    if (intWeaselEXP >= 500)
    {
    intWeaselEXP = 0;
    intWeaselLevel += 1;
    intHitCount += 1;

    system("CLS");
    cout << strWeaselsName << " Leveled Up! " << strWeaselsName << " is now Level " << intWeaselLevel << endl;
    cout << strWeaselsName << "'s Hit Count increased to " << intHitCount << endl;
    system("Pause");
    }

    if (intLlamaEXP >= 500)
    {
    intLlamaEXP = 0;
    intLlamaLevel += 1;
    intAccuracyLowered += 1;

    system("CLS");
    cout << strLlamasName << " Leveled Up! " << strLlamasName << " is now Level " << intLlamaLevel << endl;
    cout << strLlamasName << "'s Accuracy Lowering increased to " << intAccuracyLowered << endl;
    system("Pause");
    }

DirectEnding();
}

int YourBikerFightMenu(int &intRecharge, int &intElectricShotgunCharge, int intAttack, int &intBiker1HP, int &intBiker2HP, int &intBiker3HP, int &intBiker4HP, string strYourName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intYourHP, int intYourEXP, int intJello)
{
int intYourMoveChoice;
system("CLS");

cout << "It is " << strYourName << "'s Turn." << endl;
cout << "What will you do?" << endl;
cout << "(1) Shoot" << endl;
cout << "(2) Items" << endl;
cout << "(3) Stats" << endl;
cout << "(4) Help" << endl;
cout << "(5) Exit" << endl;
cout << endl;
cin >> intYourMoveChoice;

    if (intYourMoveChoice == 1 && intElectricShotgunCharge == 0)
    {
    system("CLS");
    cout << "You have no Charge Left in your Electric Shotgun, Please Recharge it." << endl;
    intYourMoveChoice = 2;
    cout << "Going to items so you can Recharge..." << endl;
    cout << endl;
    system("Pause");
    }

    if (intYourMoveChoice == 1)
    {
    int intEnemyChoice;
    system("CLS");
    cout << "Target an enemy: " << endl;
    cout << "(1) Biker 1 (" << intBiker1HP << " HP)" << endl;
    cout << "(2) Biker 2 (" << intBiker2HP << " HP)" << endl;
    cout << "(3) Biker 3 (" << intBiker3HP << " HP)" << endl;
    cout << "(4) Biker 4 (" << intBiker4HP << " HP)" << endl;
    cout << endl;
    cin >> intEnemyChoice;

        if (intEnemyChoice == 1)
        {
        int intYourDamage;
        srand(static_cast<int>(time(0)));
        intYourDamage = intAttack + rand()%(3);
        intElectricShotgunCharge -= 1;
        intBiker1HP -= intYourDamage;

        intYourEXP += intYourDamage * 20;
        system("CLS");
        cout << "You dealt " << intYourDamage << " Damage, Biker 1 has " << intBiker1HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 2)
        {
        int intYourDamage;
        srand(static_cast<int>(time(0)));
        intYourDamage = intAttack + rand()%(3);
        intElectricShotgunCharge -= 1;
        intBiker2HP -= intYourDamage;

        intYourEXP += intYourDamage * 20;
        system("CLS");
        cout << "You dealt " << intYourDamage << " Damage, Biker 2 has " << intBiker2HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 3)
        {
        int intYourDamage;
        srand(static_cast<int>(time(0)));
        intYourDamage = intAttack + rand()%(3);
        intElectricShotgunCharge -= 1;
        intBiker3HP -= intYourDamage;

        intYourEXP += intYourDamage * 20;
        system("CLS");
        cout << "You dealt " << intYourDamage << " Damage, Biker 3 has " << intBiker3HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 4)
        {
        int intYourDamage;
        srand(static_cast<int>(time(0)));
        intYourDamage = intAttack + rand()%(3);
        intElectricShotgunCharge -= 1;
        intBiker4HP -= intYourDamage;

        intYourEXP += intYourDamage * 20;
        system("CLS");
        cout << "You dealt " << intYourDamage << " Damage, Biker 4 has " << intBiker4HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }
    }
    if (intYourMoveChoice == 2)
    {
    int intItemChoice;
    system("CLS");
    cout << "Items:" << endl;
    cout << "(1) " << strYourHamstersName << "'s Wheel (Will recharge your Electric Shotgun)" << endl;
        if (intJello != 0)
        {
        cout << "(2) A Jell-O Pack (Will increase the hits of " << strWeaselsName << "'s Knife)" << endl;
        }
        if (intBlanket != 0)
        {
        cout << "(3) A Blanket (Will trap the enemy for a turn, will be used up)" << endl;
        }
        cout << endl;
        cin >> intItemChoice;

        if (intItemChoice == 2)
        {
        system("CLS");
        cout << "You are not " << strWeaselsName << ". Returning back to Attack Menu..." << endl;
        cout << endl;
        system("Pause");
        intYourMoveChoice = YourBikerFightMenu(intRecharge, intElectricShotgunCharge, intAttack, intBiker1HP, intBiker2HP, intBiker3HP, intBiker4HP, strYourName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intYourHP, intYourEXP, intJello);
        }

        if (intItemChoice == 1)
        {
        system("CLS");
        intRecharge += 1;
        intElectricShotgunCharge = 5;
        cout << "You successfully recharge your Electric Shotgun" << endl;
        cout << endl;
        system("Pause");
        }

        if (intItemChoice == 3)
        {
        system("CLS");
        cout << "You stunned The Bikers with your blanket can no longer be used. It was torn up while they were trying to escape." << endl;
        intBlanket -= 1;
        intStunned += 1;
        cout << endl;
        system("Pause");
        }
    }

    if (intYourMoveChoice == 3)
    {
    system("CLS");
    cout << strYourName << ":" << endl;
    cout << "Stats:" << endl;
    cout << "Attack: " << intAttack << " To " << intAttack + 2 << endl;
    cout << "HP: " << intYourHP << endl;
    cout << "EXP: " << intYourEXP << endl;
    cout << endl;
    system("Pause");
    intYourMoveChoice = YourBikerFightMenu(intRecharge, intElectricShotgunCharge, intAttack, intBiker1HP, intBiker2HP, intBiker3HP, intBiker4HP, strYourName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intYourHP, intYourEXP, intJello);
    }

    if (intYourMoveChoice == 4)
    {

    FightHelp(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, strYourHamstersName);
    intYourMoveChoice = YourBikerFightMenu(intRecharge, intElectricShotgunCharge, intAttack, intBiker1HP, intBiker2HP, intBiker3HP, intBiker4HP, strYourName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intYourHP, intYourEXP, intJello);
    }

    if (intYourMoveChoice == 5)
    {
    system("CLS");
    }
    return (intYourMoveChoice);
}

int GFBikerFightMenu(int &intRecharge, int &intHairStraightenerCharge, int intStunChance, int &intBiker1Stun, int &intBiker2Stun, int &intBiker3Stun, int &intBiker4Stun, string strYourGirlfriendsName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intGFHP, int intGFEXP, int intJello)
{
system("CLS");
int intGFMoveChoice;

cout << "It is " << strYourGirlfriendsName << "'s Turn." << endl;
cout << "What will you do?" << endl;
cout << "(1) Stun" << endl;
cout << "(2) Items" << endl;
cout << "(3) Stats" << endl;
cout << "(4) Help" << endl;
cout << "(5) Exit" << endl;
cout << endl;
cin >> intGFMoveChoice;

    if (intGFMoveChoice == 1 && intHairStraightenerCharge == 0)
    {
    system("CLS");
    cout << strYourGirlfriendsName << " has no Charge Left in your Hair Straightener, Please Recharge it." << endl;
    intGFMoveChoice = 2;
    cout << "Going to items so you can Recharge..." << endl;
    cout << endl;
    system("Pause");
    }

    if (intGFMoveChoice == 1)
    {
    int intEnemyChoice;
    system("CLS");
    cout << "Target an enemy: " << endl;
    cout << "(1) Biker 1 (" << intBiker1HP << " HP)" << endl;
    cout << "(2) Biker 2 (" << intBiker2HP << " HP)" << endl;
    cout << "(3) Biker 3 (" << intBiker3HP << " HP)" << endl;
    cout << "(4) Biker 4 (" << intBiker4HP << " HP)" << endl;
    cout << endl;
    cin >> intEnemyChoice;

        if (intEnemyChoice == 1)
        {
        system("CLS");
        srand(static_cast<int>(time(0)));
        intBiker1Stun = intStunChance + rand()%(10);
        intHairStraightenerCharge -= 1;
            if (intBiker1Stun >= 5)
            {
            intGFEXP += intBiker1Stun * 20;
            cout << strYourGirlfriendsName << " Stunned Biker 1" << endl;
            cout << endl;
            system("Pause");
            }
            else if (intBiker1Stun <= 5)
            {
            cout << strYourGirlfriendsName << " failed to stun Biker 1" << endl;
            cout << endl;
            system("Pause");
            }
        }

        if (intEnemyChoice == 2)
        {
        system("CLS");
        srand(static_cast<int>(time(0)));
        intBiker2Stun = intStunChance + rand()%(10);
        intHairStraightenerCharge -= 1;
            if (intBiker2Stun >= 5)
            {
            intGFEXP += intBiker2Stun * 20;
            cout << strYourGirlfriendsName << " Stunned Biker 2" << endl;
            cout << endl;
            system("Pause");
            }
            else if (intBiker2Stun <= 5)
            {
            cout << strYourGirlfriendsName << " failed to stun Biker 2" << endl;
            cout << endl;
            system("Pause");
            }
        }

        if (intEnemyChoice == 3)
        {
        system("CLS");
        srand(static_cast<int>(time(0)));
        intBiker3Stun = intStunChance + rand()%(10);
        intHairStraightenerCharge -= 1;
            if (intBiker3Stun >= 5)
            {
            intGFEXP += intBiker3Stun * 20;
            cout << strYourGirlfriendsName << " Stunned Biker 3" << endl;
            cout << endl;
            system("Pause");
            }
            else if (intBiker3Stun <= 5)
            {
            cout << strYourGirlfriendsName << " failed to stun Biker 3" << endl;
            cout << endl;
            system("Pause");
            }
        }

        if (intEnemyChoice == 4)
        {
        system("CLS");
        srand(static_cast<int>(time(0)));
        intBiker4Stun = intStunChance + rand()%(10);
        intHairStraightenerCharge -= 1;
            if (intBiker4Stun >= 5)
            {
            intGFEXP += intBiker4Stun * 20;
            cout << strYourGirlfriendsName << " Stunned Biker 4" << endl;
            cout << endl;
            system("Pause");
            }
            else if (intBiker4Stun <= 5)
            {
            cout << strYourGirlfriendsName << " failed to stun Biker 4" << endl;
            cout << endl;
            system("Pause");
            }
        }
    }

    if (intGFMoveChoice == 2)
    {
    int intItemChoice;
    system("CLS");
    cout << "Items:" << endl;
    cout << "(1) " << strYourHamstersName << "'s Wheel (Will recharge your Hair Straightener)" << endl;
        if (intJello != 0)
        {
        cout << "(2) A Jell-O Pack (Will increase the hits of " << strWeaselsName << "'s Knife)" << endl;
        }
        if (intBlanket != 0)
        {
        cout << "(3) A Blanket (Will trap the enemy for a turn, will be used up)" << endl;
        }
        cout << endl;
        cin >> intItemChoice;
        if (intItemChoice == 2)
        {
        system("CLS");
        cout << strYourGirlfriendsName << " is not " << strWeaselsName << ". Returning back to Attack Menu..." << endl;
        cout << endl;
        system("Pause");
        intGFMoveChoice = GFBikerFightMenu(intRecharge, intHairStraightenerCharge, intStunChance, intBiker1Stun, intBiker2Stun, intBiker3Stun, intBiker4Stun, strYourGirlfriendsName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intGFHP, intGFEXP, intJello);
        }

        if (intItemChoice == 1)
        {
        system("CLS");
        intRecharge += 1;
        intHairStraightenerCharge = 10;
        cout << strYourGirlfriendsName << " successfully recharge your Hair Straightener" << endl;
        cout << endl;
        system("Pause");
        }

        if (intItemChoice == 3)
        {
        system("CLS");
        cout << strYourGirlfriendsName << " stunned Bikers Your blanket can no longer be used. It was torn up while they were trying to escape." << endl;
        cout << endl;
        intBlanket -= 1;
        intStunned += 1;
        system("Pause");
        }
    }

    if (intGFMoveChoice == 3)
    {
    system("CLS");
    cout << strYourGirlfriendsName << ":" << endl;
    cout << "Stats:" << endl;
    cout << "Stun Chance: " << intStunChance << " To 10" << endl;
    cout << "HP: " << intGFHP << endl;
    cout << "EXP: " << intGFEXP << endl;
    cout << endl;
    system("Pause");
    intGFMoveChoice = GFBikerFightMenu(intRecharge, intHairStraightenerCharge, intStunChance, intBiker1Stun, intBiker2Stun, intBiker3Stun, intBiker4Stun, strYourGirlfriendsName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intGFHP, intGFEXP, intJello);
    }

    if (intGFMoveChoice == 4)
    {
    FightHelp(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, strYourHamstersName);
    intGFMoveChoice = GFBikerFightMenu(intRecharge, intHairStraightenerCharge, intStunChance, intBiker1Stun, intBiker2Stun, intBiker3Stun, intBiker4Stun, strYourGirlfriendsName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intGFHP, intGFEXP, intJello);
    }

    if (intGFMoveChoice == 5)
    {
    system("CLS");
    }
return (intGFMoveChoice);
}

int WeaselBikerFightMenu(int &intHitCount, int &intBiker1HP, int &intBiker2HP, int &intBiker3HP, int &intBiker4HP, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intWeaselHP, int intWeaselEXP, int &intJello)
{
system("CLS");
int intWeaselChoice;

cout << "It is " << strWeaselsName << "'s Turn." << endl;
cout << "What will you do?" << endl;
cout << "(1) Slice" << endl;
cout << "(2) Items" << endl;
cout << "(3) Stats" << endl;
cout << "(4) Help" << endl;
cout << "(5) Exit" << endl;
cout << endl;
cin >> intWeaselChoice;

    if (intWeaselChoice == 1)
    {
    int intEnemyChoice;
    system("CLS");
    cout << "Target an enemy: " << endl;
    cout << "(1) Biker 1 (" << intBiker1HP << " HP)" << endl;
    cout << "(2) Biker 2 (" << intBiker2HP << " HP)" << endl;
    cout << "(3) Biker 3 (" << intBiker3HP << " HP)" << endl;
    cout << "(4) Biker 4 (" << intBiker4HP << " HP)" << endl;
    cout << endl;
    cin >> intEnemyChoice;

        if (intEnemyChoice == 1)
        {
        int intDamage;
        srand(static_cast<int>(time(0)));
        intDamage = 1 + rand()%(2);

        intBiker1HP -= intHitCount * intDamage;

        intWeaselEXP += intDamage * intHitCount * 20;
        system("CLS");
        cout << strWeaselsName << " dealt " << intDamage * intHitCount << " Damage, with " << intHitCount << " Hits, Biker 1 has " << intBiker1HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 2)
        {
        int intDamage;
        srand(static_cast<int>(time(0)));
        intDamage = 1 + rand()%(2);

        intBiker2HP -= intHitCount * intDamage;

        intWeaselEXP += intDamage * intHitCount * 20;
        system("CLS");
        cout << strWeaselsName << " dealt " << intDamage * intHitCount << " Damage, with " << intHitCount << " Hits, Biker 2 has " << intBiker2HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 3)
        {
        int intDamage;
        srand(static_cast<int>(time(0)));
        intDamage = 1 + rand()%(2);

        intBiker3HP -= intHitCount * intDamage;

        intWeaselEXP += intDamage * intHitCount * 20;
        system("CLS");
        cout << strWeaselsName << " dealt " << intDamage * intHitCount << " Damage, with " << intHitCount << " Hits, Biker 3 has " << intBiker3HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 4)
        {
        int intDamage;
        srand(static_cast<int>(time(0)));
        intDamage = 1 + rand()%(2);

        intBiker4HP -= intHitCount * intDamage;

        intWeaselEXP += intDamage * intHitCount * 20;
        system("CLS");
        cout << strWeaselsName << " dealt " << intDamage * intHitCount << " Damage, with " << intHitCount << " Hits, Biker 4 has " << intBiker4HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }
    }

    if (intWeaselChoice == 2)
    {
    int intItemChoice;
    system("CLS");
    cout << "Items:" << endl;
    cout << "(1) " << strYourHamstersName << "'s Wheel" << endl;
        if (intJello != 0)
        {
        cout << "(2) A Jell-O Pack (Will increase the hits of " << strWeaselsName << "'s Knife)" << endl;
        }
        if (intBlanket != 0)
        {
        cout << "(3) A Blanket (Will trap the enemy for a turn, will be used up)" << endl;
        }
        cin >> intItemChoice;
        if (intItemChoice == 2)
        {
        system("CLS");
        cout << "You are " << strWeaselsName << ". Increasing Hit Count..." << endl;
        cout << endl;
        intHitCount += 2;
        intJello = 0;
        system("Pause");
        }

        if (intItemChoice == 1)
        {
        system("CLS");
        cout << strWeaselsName << " has nothing to recharge..." << endl;
        system("Pause");
        intWeaselChoice = WeaselBikerFightMenu(intHitCount, intBiker1HP, intBiker2HP, intBiker3HP, intBiker4HP, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intWeaselHP, intWeaselEXP, intJello);
        }

        if (intItemChoice == 3)
        {
        system("CLS");
        cout << strWeaselsName << " stunned Bikers Your blanket can no longer be used. It was torn up while they were trying to escape." << endl;
        intBlanket -= 1;
        intStunned += 1;
        system("Pause");
        system("CLS");
        }
    }

    if (intWeaselChoice == 3)
    {
    system("CLS");
    cout << strWeaselsName << ":" << endl;
    cout << "Stats:" << endl;
    cout << "Hit Count: " << intHitCount << endl;
    cout << "HP: " << intWeaselHP << endl;
    cout << "EXP: " << intWeaselEXP << endl;
    cout << endl;
    system("Pause");
    intWeaselChoice = WeaselBikerFightMenu(intHitCount, intBiker1HP, intBiker2HP, intBiker3HP, intBiker4HP, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intWeaselHP, intWeaselEXP, intJello);
    }

    if (intWeaselChoice == 4)
    {
    FightHelp(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, strYourHamstersName);
    intWeaselChoice = WeaselBikerFightMenu(intHitCount, intBiker1HP, intBiker2HP, intBiker3HP, intBiker4HP, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intWeaselHP, intWeaselEXP, intJello);
    }

    if (intWeaselChoice == 5)
    {
    system("CLS");
    }
return (intWeaselChoice);
}

int LlamaBikerFightMenu(int intAccuracyLowered, int &intBiker1Accuracy, int &intBiker2Accuracy, int &intBiker3Accuracy, int &intBiker4Accuracy, string strLlamasName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intLlamaHP, int intLlamaEXP, int intJello)
{
system("CLS");
int intLlamaChoice;

cout << "It is " << strLlamasName << "'s Turn." << endl;
cout << "What will you do?" << endl;
cout << "(1) Spit" << endl;
cout << "(2) Items" << endl;
cout << "(3) Stats" << endl;
cout << "(4) Help" << endl;
cout << "(5) Exit" << endl;
cout << endl;
cin >> intLlamaChoice;

    if (intLlamaChoice == 1)
    {
    int intEnemyChoice;
    system("CLS");
    cout << "Target an enemy: " << endl;
    cout << "(1) Biker 1 (" << intBiker1HP << " HP)" << endl;
    cout << "(2) Biker 2 (" << intBiker2HP << " HP)" << endl;
    cout << "(3) Biker 3 (" << intBiker3HP << " HP)" << endl;
    cout << "(4) Biker 4 (" << intBiker4HP << " HP)" << endl;
    cout << endl;
    cin >> intEnemyChoice;

        if (intEnemyChoice == 1)
        {
        int intAccuracy;
        srand(static_cast<int>(time(0)));
        intAccuracy = 1 + rand()%(2);

        intBiker1Accuracy -= intAccuracy * intAccuracyLowered;

        intLlamaEXP += intAccuracy * intAccuracyLowered * 20;
        system("CLS");
        cout << strLlamasName << " lowered Biker 1's Accuracy by " << intAccuracy * intAccuracyLowered << ", Biker 1 has " << intBiker1HP << " HP left." << endl;
        cout << endl;
        system("Pause");

        }

        if (intEnemyChoice == 2)
        {
        int intAccuracy;
        srand(static_cast<int>(time(0)));
        intAccuracy = 1 + rand()%(2);

        intBiker2Accuracy -= intAccuracy * intAccuracyLowered;

        intLlamaEXP += intAccuracy * intAccuracyLowered * 20;
        system("CLS");
        cout << strLlamasName << " lowered Biker 2's Accuracy by " << intAccuracy * intAccuracyLowered << ", Biker 2 has " << intBiker2HP << " HP left." << endl;
        cout << endl;
        system("Pause");

        }

        if (intEnemyChoice == 3)
        {
        int intAccuracy;
        srand(static_cast<int>(time(0)));
        intAccuracy = 1 + rand()%(2);

        intBiker3Accuracy -= intAccuracy * intAccuracyLowered;

        intLlamaEXP += intAccuracy * intAccuracyLowered * 20;
        system("CLS");
        cout << strLlamasName << " lowered Biker 3's Accuracy by " << intAccuracy * intAccuracyLowered << ", Biker 3 has " << intBiker3HP << " HP left." << endl;
        cout << endl;
        system("Pause");

        }

        if (intEnemyChoice == 4)
        {
        int intAccuracy;
        srand(static_cast<int>(time(0)));
        intAccuracy = 1 + rand()%(2);

        intBiker4Accuracy -= intAccuracy * intAccuracyLowered;

        intLlamaEXP += intAccuracy * intAccuracyLowered * 20;
        system("CLS");
        cout << strLlamasName << " lowered Biker 4's Accuracy by " << intAccuracy * intAccuracyLowered << ", Biker 4 has " << intBiker4HP << " HP left." << endl;
        cout << endl;
        system("Pause");

        }
    }

    if (intLlamaChoice == 2)
    {
    int intItemChoice;
    system("CLS");
    cout << "Items:" << endl;
    cout << "(1) " << strYourHamstersName << "'s Wheel" << endl;
        if (intJello != 0)
        {
        cout << "(2) A Jell-O Pack (Will increase the hits of " << strWeaselsName << "'s Knife)" << endl;
        }
        if (intBlanket != 0)
        {
        cout << "(3) A Blanket (Will trap the enemy for a turn, will be used up)" << endl;
        }
        cout << endl;
        cin >> intItemChoice;

        if (intItemChoice == 2)
        {
        system("CLS");
        cout << strLlamasName << " is not " << strWeaselsName << ". Returning back to Attack Menu..." << endl;
        cout << endl;
        system("Pause");
        intLlamaChoice = LlamaBikerFightMenu(intAccuracyLowered, intBiker1Accuracy, intBiker2Accuracy, intBiker3Accuracy, intBiker4Accuracy, strLlamasName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intLlamaHP, intLlamaEXP, intJello);
        }

        if (intItemChoice == 1)
        {
        system("CLS");
        cout << strLlamasName << " has nothing to recharge. Returning back to Attack Menu..." << endl;
        cout << endl;
        system("Pause");
        intLlamaChoice = LlamaBikerFightMenu(intAccuracyLowered, intBiker1Accuracy, intBiker2Accuracy, intBiker3Accuracy, intBiker4Accuracy, strLlamasName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intLlamaHP, intLlamaEXP, intJello);
        }

        if (intItemChoice == 3)
        {
        system("CLS");
        cout << strLlamasName << " stunned Bikers Your blanket can no longer be used. It was torn up while they were trying to escape." << endl;
        cout << endl;
        intBlanket -= 1;
        intStunned += 1;
        system("Pause");
        }
    }

    if (intLlamaChoice == 3)
    {
    system("CLS");
    cout << strLlamasName << ":" << endl;
    cout << "Stats:" << endl;
    cout << "Accuracy Lowered: " << intAccuracyLowered << endl;
    cout << "HP: " << intLlamaHP << endl;
    cout << "EXP: " << intLlamaEXP << endl;
    cout << endl;
    system("Pause");
    intLlamaChoice = LlamaBikerFightMenu(intAccuracyLowered, intBiker1Accuracy, intBiker2Accuracy, intBiker3Accuracy, intBiker4Accuracy, strLlamasName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intLlamaHP, intLlamaEXP, intJello);
    }

    if (intLlamaChoice == 4)
    {
    FightHelp(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, strYourHamstersName);
    intLlamaChoice = LlamaBikerFightMenu(intAccuracyLowered, intBiker1Accuracy, intBiker2Accuracy, intBiker3Accuracy, intBiker4Accuracy, strLlamasName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intLlamaHP, intLlamaEXP, intJello);
    }

    if (intLlamaChoice == 5)
    {
    system("CLS");
    }
return (intLlamaChoice);
}

void Biker1(int intBiker1HP, int intBiker1Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName)
{
    if (intBiker1HP > 0)
    {
    system("CLS");

    int intCharacterHit;

    srand(static_cast<int>(time(0)));
    intCharacterHit = 1 + rand()%(4);

        if (intCharacterHit == 1)
        {
            if (intBiker1Accuracy <= 0)
            {

            cout << "Biker 1 tried to punch " << strYourName << " but missed! Your HP is still at " << intYourHP << endl;
            cout << endl;
            system("Pause");

            }

            if (intBiker1Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intBiker1Accuracy;

                if (intChanceToHit <= 0)
                {
                intYourHP -= 2;

                cout << "Biker 1 punched " << strYourName << "! You lost 2 HP. Your HP is now " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Biker 1 tried to punch " << strYourName << " but missed! Your HP is still at " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 2)
        {
            if (intBiker1Accuracy <= 0)
            {
            cout << "Biker 1 tried to punch " << strYourGirlfriendsName << " but missed! Your HP is still at " << intGFHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intBiker1Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intBiker1Accuracy;

                if (intChanceToHit <= 0)
                {
                intGFHP -= 2;

                cout << "Biker 1 punched " << strYourGirlfriendsName << "! You lost 2 HP. Your HP is now " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Biker 1 tried to punch " << strYourGirlfriendsName << " but missed! Your HP is still at " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 3)
        {
            if (intBiker1Accuracy <= 0)
            {
            cout << "Biker 1 tried to punch " << strWeaselsName << " but missed! Your HP is still at " << intWeaselHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intBiker1Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intBiker1Accuracy;

                if (intChanceToHit <= 0)
                {
                intWeaselHP -= 2;

                cout << "Biker 1 punched " << strWeaselsName << "! You lost 2 HP. Your HP is now " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Biker 1 tried to punch " << strWeaselsName << " but missed! Your HP is still at " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 4)
        {

            if (intBiker1Accuracy <= 0)
            {
            cout << "Biker 1 tried to punch " << strLlamasName << " but missed! Your HP is still at " << intLlamaHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intBiker1Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intBiker1Accuracy;

                if (intChanceToHit <= 0)
                {
                intLlamaHP -= 2;

                cout << "Biker 1 punched " << strLlamasName << "! You lost 1 HP. Your HP is now " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Biker 1 tried to punch " << strLlamasName << " but missed! Your HP is still at " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }
    }
    if (intBiker1HP < 0)
    {
    system("CLS");
    cout << "Biker 1 is Dead!" << endl;
    cout << endl;
    system("Pause");
    }
}

void Biker2(int intBiker2HP, int intBiker2Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName)
{
    if (intBiker2HP > 0)
    {
    system("CLS");

    int intCharacterHit;

    srand(static_cast<int>(time(0)));
    intCharacterHit = 1 + rand()%(4);

        if (intCharacterHit == 1)
        {
            if (intBiker2Accuracy <= 0)
            {

            cout << "Biker 2 tried to punch " << strYourName << " but missed! Your HP is still at " << intYourHP << endl;
            cout << endl;
            system("Pause");

            }

            if (intBiker2Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intBiker2Accuracy;

                if (intChanceToHit <= 0)
                {
                intYourHP -= 2;

                cout << "Biker 2 punched " << strYourName << "! You lost 2 HP. Your HP is now " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Biker 2 tried to punch " << strYourName << " but missed! Your HP is still at " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 2)
        {
            if (intBiker2Accuracy <= 0)
            {
            cout << "Biker 2 tried to punch " << strYourGirlfriendsName << " but missed! Your HP is still at " << intGFHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intBiker2Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intBiker2Accuracy;

                if (intChanceToHit <= 0)
                {
                intGFHP -= 2;

                cout << "Biker 2 punched " << strYourGirlfriendsName << "! You lost 2 HP. Your HP is now " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Biker 2 tried to punch " << strYourGirlfriendsName << " but missed! Your HP is still at " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 3)
        {
            if (intBiker2Accuracy <= 0)
            {
            cout << "Biker 2 tried to punch " << strWeaselsName << " but missed! Your HP is still at " << intWeaselHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intBiker2Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intBiker2Accuracy;

                if (intChanceToHit <= 0)
                {
                intWeaselHP -= 2;

                cout << "Biker 2 punched " << strWeaselsName << "! You lost 2 HP. Your HP is now " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Biker 2 tried to punch " << strWeaselsName << " but missed! Your HP is still at " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 4)
        {

            if (intBiker2Accuracy <= 0)
            {
            cout << "Biker 2 tried to punch " << strLlamasName << " but missed! Your HP is still at " << intLlamaHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intBiker2Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intBiker2Accuracy;

                if (intChanceToHit <= 0)
                {
                intLlamaHP -= 2;

                cout << "Biker 2 punched " << strLlamasName << "! You lost 2 HP. Your HP is now " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Biker 2 tried to punch " << strLlamasName << " but missed! Your HP is still at " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }
    }
    if (intBiker2HP < 0)
    {
    system("CLS");
    cout << "Biker 2 is Dead!" << endl;
    cout << endl;
    system("Pause");
    }
}

void Biker3(int intBiker3HP, int intBiker3Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName)
{
    if (intBiker3HP > 0)
    {
    system("CLS");

    int intCharacterHit;

    srand(static_cast<int>(time(0)));
    intCharacterHit = 1 + rand()%(4);

        if (intCharacterHit == 1)
        {
            if (intBiker3Accuracy <= 0)
            {

            cout << "Biker 3 tried to punch " << strYourName << " but missed! Your HP is still at " << intYourHP << endl;
            cout << endl;
            system("Pause");

            }

            if (intBiker3Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intBiker3Accuracy;

                if (intChanceToHit <= 0)
                {
                intYourHP -= 2;

                cout << "Biker 3 punched " << strYourName << "! You lost 2 HP. Your HP is now " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Biker 3 tried to punch " << strYourName << " but missed! Your HP is still at " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 2)
        {
            if (intBiker3Accuracy <= 0)
            {
            cout << "Biker 3 tried to punch " << strYourGirlfriendsName << " but missed! Your HP is still at " << intGFHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intBiker3Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intBiker3Accuracy;

                if (intChanceToHit <= 0)
                {
                intGFHP -= 2;

                cout << "Biker 3 punched " << strYourGirlfriendsName << "! You lost 2 HP. Your HP is now " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Biker 3 tried to punch " << strYourGirlfriendsName << " but missed! Your HP is still at " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 3)
        {
            if (intBiker3Accuracy <= 0)
            {
            cout << "Biker 3 tried to punch " << strWeaselsName << " but missed! Your HP is still at " << intWeaselHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intBiker3Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intBiker3Accuracy;

                if (intChanceToHit <= 0)
                {
                intWeaselHP -= 2;

                cout << "Biker 3 punched " << strWeaselsName << "! You lost 2 HP. Your HP is now " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Biker 3 tried to punch " << strWeaselsName << " but missed! Your HP is still at " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 4)
        {

            if (intBiker3Accuracy <= 0)
            {
            cout << "Biker 3 tried to punch " << strLlamasName << " but missed! Your HP is still at " << intLlamaHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intBiker3Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intBiker3Accuracy;

                if (intChanceToHit <= 0)
                {
                intLlamaHP -= 2;

                cout << "Biker 3 punched " << strLlamasName << "! You lost 2 HP. Your HP is now " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Biker 3 tried to punch " << strLlamasName << " but missed! Your HP is still at " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }
    }
    if (intBiker3HP < 0)
    {
    system("CLS");
    cout << "Biker 3 is Dead!" << endl;
    cout << endl;
    system("Pause");
    }
}

void Biker4(int intBiker4HP, int intBiker4Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName)
{
    if (intBiker4HP > 0)
    {
    system("CLS");

    int intCharacterHit;

    srand(static_cast<int>(time(0)));
    intCharacterHit = 1 + rand()%(4);

        if (intCharacterHit == 1)
        {
            if (intBiker4Accuracy <= 0)
            {

            cout << "Biker 4 tried to punch " << strYourName << " but missed! Your HP is still at " << intYourHP << endl;
            cout << endl;
            system("Pause");

            }

            if (intBiker4Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intBiker4Accuracy;

                if (intChanceToHit <= 0)
                {
                intYourHP -= 2;

                cout << "Biker 4 punched " << strYourName << "! You lost 2 HP. Your HP is now " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Biker 4 tried to punch " << strYourName << " but missed! Your HP is still at " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 2)
        {
            if (intBiker4Accuracy <= 0)
            {
            cout << "Biker 4 tried to punch " << strYourGirlfriendsName << " but missed! Your HP is still at " << intGFHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intBiker4Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intBiker4Accuracy;

                if (intChanceToHit <= 0)
                {
                intGFHP -= 2;

                cout << "Biker 4 punched " << strYourGirlfriendsName << "! You lost 2 HP. Your HP is now " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Biker 4 tried to punch " << strYourGirlfriendsName << " but missed! Your HP is still at " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 3)
        {
            if (intBiker4Accuracy <= 0)
            {
            cout << "Biker 4 tried to punch " << strWeaselsName << " but missed! Your HP is still at " << intWeaselHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intBiker4Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intBiker4Accuracy;

                if (intChanceToHit <= 0)
                {
                intWeaselHP -= 2;

                cout << "Biker 4 punched " << strWeaselsName << "! You lost 2 HP. Your HP is now " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Biker 4 tried to punch " << strWeaselsName << " but missed! Your HP is still at " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 4)
        {

            if (intBiker4Accuracy <= 0)
            {
            cout << "Biker 4 tried to punch " << strLlamasName << " but missed! Your HP is still at " << intLlamaHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intBiker4Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intBiker4Accuracy;

                if (intChanceToHit <= 0)
                {
                intLlamaHP -= 2;

                cout << "Biker 4 punched " << strLlamasName << "! You lost 2 HP. Your HP is now " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Biker 4 tried to punch " << strLlamasName << " but missed! Your HP is still at " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }
    }
    if (intBiker4HP < 0)
    {
    system("CLS");
    cout << "Biker 4 is Dead!" << endl;
    cout << endl;
    system("Pause");
    }
}

void Weasels()
{
system("CLS");

cout << "You finally get to Florida's Capitol in Tallahassee. You see the Governors Building and its in ruins. Windows are shattered, the door has been blown through, and all the cars are gone." << endl;
cout << "You have your guard up you don't know what you'll find but you do know that you've come too far to give up. You make sure you have your Electric Shotgun ready. You sneak in to see a" << endl;
cout << "bunch of Weasels who have taken over the Capitol. You hear one of them saying 'I'm so glad we got rid of these idiots in office, the ones who allowed us to get attacked just cuz we" << endl;
cout << "were Weasels.' " << strWeaselsName << " slams the door open 'You really think it's ok to hurt people just because y'all were treated bad, i was getting beat up when these people found me" << endl;
cout << "and you don't see me taking that out on others, life sucks doesn't mean you hurt everyone else because of it.' After that long proud speech they all turn to him and say 'Nah they deserve" << endl;
cout << "to be hurt. And you know what if you disagree so do you!' The Weasels start charging at you with various office supplies!" << endl;
cout << endl;
system("Pause");

}

void WeaselFight(string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, int &intWeasel1Stun, int &intWeasel2Stun, int &intWeasel3Stun, int &intWeasel4Stun, int &intWeasel5Stun, int &intWeasel6Stun, int &intStunned, int &intYourLevel, int &intYourEXP, int &intAttack, int &intGFLevel, int &intGFEXP, int &intStunChance, int &intWeaselLevel, int &intWeaselEXP, int &intHitCount, int &intLlamaLevel, int &intLlamaEXP, int &intAccuracyLowered, int &intRecharge)
{
system("CLS");

int intYourMoveChoice;
int intGFMoveChoice;
int intWeaselChoice;
int intLlamaChoice;

cout << "You are Presented with 6 Weasels to fight." << endl;
cout << "Each Weasel has 1 Attack and 5 Health" << endl;
cout << endl;
system("Pause");
    do
    {

    if (intYourHP > 0)
    {
    intYourMoveChoice = YourWeaselFightMenu(intRecharge, intElectricShotgunCharge, intAttack, intWeasel1HP, intWeasel2HP, intWeasel3HP, intWeasel4HP, intWeasel5HP, intWeasel6HP, strYourName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intYourHP, intYourEXP, intJello);
    }

    if (intYourHP < 0)
    {
    system("CLS");
    cout << strYourName << " is Knocked out!" << endl;
    system("Pause");
    }

    if (intYourMoveChoice == 5)
    {
    break;
    }

    if (intGFHP > 0)
    {
    intGFMoveChoice = GFWeaselFightMenu(intRecharge, intHairStraightenerCharge, intStunChance, intWeasel1Stun, intWeasel2Stun, intWeasel3Stun, intWeasel4Stun, intWeasel5Stun, intWeasel6Stun, strYourGirlfriendsName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intGFHP, intGFEXP, intJello);

    }

    if (intGFHP < 0)
    {
    system("CLS");
    cout << strYourGirlfriendsName << " is Knocked out!" << endl;
    system("Pause");
    }

    if (intGFMoveChoice == 5)
    {
    break;
    }
        if (intRecharge != 1 && intWeaselHP > 0)
        {
        intWeaselChoice = WeaselWeaselFightMenu(intHitCount, intWeasel1HP, intWeasel2HP, intWeasel3HP, intWeasel4HP, intWeasel5HP, intWeasel6HP, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intWeaselHP, intWeaselEXP, intJello);
        }

        if (intWeaselHP < 0)
        {
        system("CLS");
        cout << strWeaselsName << " is Knocked out!" << endl;
        system("Pause");
        }

        if (intWeaselChoice == 5)
        {
        break;
        }

        if (intRecharge == 1)
        {
        system("CLS");
        cout << "Weasel is recharging someones weapon, he cannot preform any actions this turn." << endl;
        cout << endl;
        system("Pause");
        intRecharge = 0;
        }

        if (intLlamaHP > 0)
        {
        intLlamaChoice = LlamaWeaselFightMenu(intAccuracyLowered, intWeasel1Accuracy, intWeasel2Accuracy, intWeasel3Accuracy, intWeasel4Accuracy, intWeasel5Accuracy, intWeasel6Accuracy, strLlamasName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intLlamaHP, intLlamaEXP, intJello);
        }

        if (intLlamaHP < 0)
        {
        system("CLS");
        cout << strLlamasName << " is Knocked out!" << endl;
        system("Pause");
        }

        if (intLlamaChoice == 5)
        {
        break;
        }

        if (intWeasel1Stun <= 4 && intStunned == 0)
        {
        Weasel1(intWeasel1HP, intWeasel1Accuracy, intYourHP, intGFHP, intWeaselHP, intLlamaHP, strYourName, strYourGirlfriendsName, strWeaselsName, strLlamasName);
        }

        if (intWeasel2Stun <= 4 && intStunned == 0)
        {
        Weasel2(intWeasel2HP, intWeasel2Accuracy, intYourHP, intGFHP, intWeaselHP, intLlamaHP, strYourName, strYourGirlfriendsName, strWeaselsName, strLlamasName);
        }

        if (intWeasel3Stun <= 4 && intStunned == 0)
        {
        Weasel3(intWeasel3HP, intWeasel3Accuracy, intYourHP, intGFHP, intWeaselHP, intLlamaHP, strYourName, strYourGirlfriendsName, strWeaselsName, strLlamasName);
        }

        if (intWeasel4Stun <= 4 && intStunned == 0)
        {
        Weasel4(intWeasel4HP, intWeasel4Accuracy, intYourHP, intGFHP, intWeaselHP, intLlamaHP, strYourName, strYourGirlfriendsName, strWeaselsName, strLlamasName);
        }

        if (intWeasel5Stun <= 4 && intStunned == 0)
        {
        Weasel5(intWeasel5HP, intWeasel5Accuracy, intYourHP, intGFHP, intWeaselHP, intLlamaHP, strYourName, strYourGirlfriendsName, strWeaselsName, strLlamasName);
        }

        if (intWeasel6Stun <= 4 && intStunned == 0)
        {
        Weasel6(intWeasel6HP, intWeasel6Accuracy, intYourHP, intGFHP, intWeaselHP, intLlamaHP, strYourName, strYourGirlfriendsName, strWeaselsName, strLlamasName);
        }

        intWeasel1Stun = 0;
        intWeasel2Stun = 0;
        intWeasel3Stun = 0;
        intWeasel4Stun = 0;
        intWeasel5Stun = 0;
        intWeasel6Stun = 0;
        intStunned = 0;

    } while (intWeasel1HP > 0 || intWeasel2HP > 0 || intWeasel3HP > 0 || intWeasel4HP > 0 || intWeasel5HP > 0 || intWeasel6HP > 0 && intYourMoveChoice != 5 && intGFMoveChoice != 5 && intWeaselChoice != 5 && intLlamaChoice != 5);

    intYourHP = 15;
    intGFHP = 15;
    intWeaselHP = 15;
    intLlamaHP = 15;

    if (intYourEXP >= 500)
    {
    intYourEXP = 0;
    intYourLevel += 1;
    intAttack += 1;
    intMoney += 50;

    system("CLS");
    cout << "You Leveled Up! " << strYourName << " is now Level " << intYourLevel << endl;
    cout << strYourName << " Attack increased to " << intAttack << endl;
    cout << "You gained 50 Bucks! You have " << intMoney << " bucks" << endl;
    system("Pause");
    }

    if (intGFEXP >= 500)
    {
    intGFEXP = 0;
    intGFLevel += 1;
    intStunChance += 1;

    system("CLS");
    cout << strYourGirlfriendsName << " Leveled Up! " << strYourGirlfriendsName << " is now Level " << intGFLevel << endl;
    cout << strYourGirlfriendsName << "'s Stun Chance increased to " << intStunChance << endl;
    system("Pause");
    }

    if (intWeaselEXP >= 500)
    {
    intWeaselEXP = 0;
    intWeaselLevel += 1;
    intHitCount += 1;

    system("CLS");
    cout << strWeaselsName << " Leveled Up! " << strWeaselsName << " is now Level " << intWeaselLevel << endl;
    cout << strWeaselsName << "'s Hit Count increased to " << intHitCount << endl;
    system("Pause");
    }

    if (intLlamaEXP >= 500)
    {
    intLlamaEXP = 0;
    intLlamaLevel += 1;
    intAccuracyLowered += 1;

    system("CLS");
    cout << strLlamasName << " Leveled Up! " << strLlamasName << " is now Level " << intLlamaLevel << endl;
    cout << strLlamasName << "'s Accuracy Lowering increased to " << intAccuracyLowered << endl;
    system("Pause");
    }

GovernmentEnding();
}

int YourWeaselFightMenu(int &intRecharge, int &intElectricShotgunCharge, int intAttack, int &intWeasel1HP, int &intWeasel2HP, int &intWeasel3HP, int &intWeasel4HP, int &intWeasel5HP, int &intWeasel6HP, string strYourName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intYourHP, int intYourEXP, int intJello)
{
int intYourMoveChoice;
system("CLS");

cout << "It is " << strYourName << "'s Turn." << endl;
cout << "What will you do?" << endl;
cout << "(1) Shoot" << endl;
cout << "(2) Items" << endl;
cout << "(3) Stats" << endl;
cout << "(4) Help" << endl;
cout << "(5) Exit" << endl;
cout << endl;
cin >> intYourMoveChoice;

    if (intYourMoveChoice == 1 && intElectricShotgunCharge == 0)
    {
    system("CLS");
    cout << "You have no Charge Left in your Electric Shotgun, Please Recharge it." << endl;
    intYourMoveChoice = 2;
    cout << "Going to items so you can Recharge..." << endl;
    cout << endl;
    system("Pause");
    }

    if (intYourMoveChoice == 1)
    {
    int intEnemyChoice;
    system("CLS");
    cout << "Target an enemy: " << endl;
    cout << "(1) Weasel 1 (" << intWeasel1HP << " HP)" << endl;
    cout << "(2) Weasel 2 (" << intWeasel2HP << " HP)" << endl;
    cout << "(3) Weasel 3 (" << intWeasel3HP << " HP)" << endl;
    cout << "(4) Weasel 4 (" << intWeasel4HP << " HP)" << endl;
    cout << "(5) Weasel 5 (" << intWeasel5HP << " HP)" << endl;
    cout << "(6) Weasel 6 (" << intWeasel6HP << " HP)" << endl;
    cout << endl;
    cin >> intEnemyChoice;

        if (intEnemyChoice == 1)
        {
        int intYourDamage;
        srand(static_cast<int>(time(0)));
        intYourDamage = intAttack + rand()%(3);
        intElectricShotgunCharge -= 1;
        intWeasel1HP -= intYourDamage;

        intYourEXP += intYourDamage * 20;
        system("CLS");
        cout << "You dealt " << intYourDamage << " Damage, Weasel 1 has " << intWeasel1HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 2)
        {
        int intYourDamage;
        srand(static_cast<int>(time(0)));
        intYourDamage = intAttack + rand()%(3);
        intElectricShotgunCharge -= 1;
        intWeasel2HP -= intYourDamage;

        intYourEXP += intYourDamage * 20;
        system("CLS");
        cout << "You dealt " << intYourDamage << " Damage, Weasel 2 has " << intWeasel2HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 3)
        {
        int intYourDamage;
        srand(static_cast<int>(time(0)));
        intYourDamage = intAttack + rand()%(3);
        intElectricShotgunCharge -= 1;
        intWeasel3HP -= intYourDamage;

        intYourEXP += intYourDamage * 20;
        system("CLS");
        cout << "You dealt " << intYourDamage << " Damage, Weasel 3 has " << intWeasel3HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 4)
        {
        int intYourDamage;
        srand(static_cast<int>(time(0)));
        intYourDamage = intAttack + rand()%(3);
        intElectricShotgunCharge -= 1;
        intWeasel4HP -= intYourDamage;

        intYourEXP += intYourDamage * 20;
        system("CLS");
        cout << "You dealt " << intYourDamage << " Damage, Weasel 4 has " << intWeasel4HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }


        if (intEnemyChoice == 5)
        {
        int intYourDamage;
        srand(static_cast<int>(time(0)));
        intYourDamage = intAttack + rand()%(3);
        intElectricShotgunCharge -= 1;
        intWeasel5HP -= intYourDamage;

        intYourEXP += intYourDamage * 20;
        system("CLS");
        cout << "You dealt " << intYourDamage << " Damage, Weasel 5 has " << intWeasel5HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 6)
        {
        int intYourDamage;
        srand(static_cast<int>(time(0)));
        intYourDamage = intAttack + rand()%(3);
        intElectricShotgunCharge -= 1;
        intWeasel6HP -= intYourDamage;

        intYourEXP += intYourDamage * 20;
        system("CLS");
        cout << "You dealt " << intYourDamage << " Damage, Weasel 6 has " << intWeasel6HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }
    }
    if (intYourMoveChoice == 2)
    {
    int intItemChoice;
    system("CLS");
    cout << "Items:" << endl;
    cout << "(1) " << strYourHamstersName << "'s Wheel (Will recharge your Electric Shotgun)" << endl;
        if (intJello != 0)
        {
        cout << "(2) A Jell-O Pack (Will increase the hits of " << strWeaselsName << "'s Knife)" << endl;
        }
        if (intBlanket != 0)
        {
        cout << "(3) A Blanket (Will trap the enemy for a turn, will be used up)" << endl;
        }
        cout << endl;
        cin >> intItemChoice;

        if (intItemChoice == 2)
        {
        system("CLS");
        cout << "You are not " << strWeaselsName << ". Returning back to Attack Menu..." << endl;
        cout << endl;
        system("Pause");
        intYourMoveChoice = YourWeaselFightMenu(intRecharge, intElectricShotgunCharge, intAttack, intWeasel1HP, intWeasel2HP, intWeasel3HP, intWeasel4HP, intWeasel5HP, intWeasel6HP, strYourName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intYourHP, intYourEXP, intJello);
        }

        if (intItemChoice == 1)
        {
        system("CLS");
        intRecharge += 1;
        intElectricShotgunCharge = 5;
        cout << "You successfully recharge your Electric Shotgun" << endl;
        cout << endl;
        system("Pause");
        }

        if (intItemChoice == 3)
        {
        system("CLS");
        cout << "You stunned The Weasels with your blanket can no longer be used. It was torn up while they were trying to escape." << endl;
        intBlanket -= 1;
        intStunned += 1;
        cout << endl;
        system("Pause");
        }
    }

    if (intYourMoveChoice == 3)
    {
    system("CLS");
    cout << strYourName << ":" << endl;
    cout << "Stats:" << endl;
    cout << "Attack: " << intAttack << " To " << intAttack + 2 << endl;
    cout << "HP: " << intYourHP << endl;
    cout << "EXP: " << intYourEXP << endl;
    cout << endl;
    system("Pause");
    intYourMoveChoice = YourWeaselFightMenu(intRecharge, intElectricShotgunCharge, intAttack, intWeasel1HP, intWeasel2HP, intWeasel3HP, intWeasel4HP, intWeasel5HP, intWeasel6HP, strYourName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intYourHP, intYourEXP, intJello);
    }

    if (intYourMoveChoice == 4)
    {

    FightHelp(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, strYourHamstersName);
    intYourMoveChoice = YourWeaselFightMenu(intRecharge, intElectricShotgunCharge, intAttack, intWeasel1HP, intWeasel2HP, intWeasel3HP, intWeasel4HP, intWeasel5HP, intWeasel6HP, strYourName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intYourHP, intYourEXP, intJello);
    }

    if (intYourMoveChoice == 5)
    {
    system("CLS");
    }
    return (intYourMoveChoice);
}

int GFWeaselFightMenu(int &intRecharge, int &intHairStraightenerCharge, int intStunChance, int &intWeasel1Stun, int &intWeasel2Stun, int &intWeasel3Stun, int &intWeasel4Stun, int &intWeasel5Stun, int &intWeasel6Stun, string strYourGirlfriendsName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intGFHP, int intGFEXP, int intJello)
{
system("CLS");
int intGFMoveChoice;

cout << "It is " << strYourGirlfriendsName << "'s Turn." << endl;
cout << "What will you do?" << endl;
cout << "(1) Stun" << endl;
cout << "(2) Items" << endl;
cout << "(3) Stats" << endl;
cout << "(4) Help" << endl;
cout << "(5) Exit" << endl;
cout << endl;
cin >> intGFMoveChoice;

    if (intGFMoveChoice == 1 && intHairStraightenerCharge == 0)
    {
    system("CLS");
    cout << strYourGirlfriendsName << " has no Charge Left in your Hair Straightener, Please Recharge it." << endl;
    intGFMoveChoice = 2;
    cout << "Going to items so you can Recharge..." << endl;
    cout << endl;
    system("Pause");
    }

    if (intGFMoveChoice == 1)
    {
    int intEnemyChoice;
    system("CLS");
    cout << "Target an enemy: " << endl;
    cout << "(1) Weasel 1 (" << intWeasel1HP << " HP)" << endl;
    cout << "(2) Weasel 2 (" << intWeasel2HP << " HP)" << endl;
    cout << "(3) Weasel 3 (" << intWeasel3HP << " HP)" << endl;
    cout << "(4) Weasel 4 (" << intWeasel4HP << " HP)" << endl;
    cout << "(5) Weasel 5 (" << intWeasel5HP << " HP)" << endl;
    cout << "(6) Weasel 6 (" << intWeasel6HP << " HP)" << endl;
    cout << endl;
    cin >> intEnemyChoice;

        if (intEnemyChoice == 1)
        {
        system("CLS");
        srand(static_cast<int>(time(0)));
        intWeasel1Stun = intStunChance + rand()%(10);
        intHairStraightenerCharge -= 1;
            if (intWeasel1Stun >= 5)
            {
            intGFEXP += intWeasel1Stun * 20;
            cout << strYourGirlfriendsName << " Stunned Weasel 1" << endl;
            cout << endl;
            system("Pause");
            }
            else if (intWeasel1Stun <= 5)
            {
            cout << strYourGirlfriendsName << " failed to stun Weasel 1" << endl;
            cout << endl;
            system("Pause");
            }
        }

        if (intEnemyChoice == 2)
        {
        system("CLS");
        srand(static_cast<int>(time(0)));
        intWeasel2Stun = intStunChance + rand()%(10);
        intHairStraightenerCharge -= 1;
            if (intWeasel2Stun >= 5)
            {
            intGFEXP += intWeasel2Stun * 20;
            cout << strYourGirlfriendsName << " Stunned Weasel 2" << endl;
            cout << endl;
            system("Pause");
            }
            else if (intWeasel2Stun <= 5)
            {
            cout << strYourGirlfriendsName << " failed to stun Weasel 2" << endl;
            cout << endl;
            system("Pause");
            }
        }

        if (intEnemyChoice == 3)
        {
        system("CLS");
        srand(static_cast<int>(time(0)));
        intWeasel3Stun = intStunChance + rand()%(10);
        intHairStraightenerCharge -= 1;
            if (intWeasel3Stun >= 5)
            {
            intGFEXP += intWeasel3Stun * 20;
            cout << strYourGirlfriendsName << " Stunned Weasel 3" << endl;
            cout << endl;
            system("Pause");
            }
            else if (intWeasel3Stun <= 5)
            {
            cout << strYourGirlfriendsName << " failed to stun Weasel 3" << endl;
            cout << endl;
            system("Pause");
            }
        }

        if (intEnemyChoice == 4)
        {
        system("CLS");
        srand(static_cast<int>(time(0)));
        intWeasel4Stun = intStunChance + rand()%(10);
        intHairStraightenerCharge -= 1;
            if (intWeasel4Stun >= 5)
            {
            intGFEXP += intWeasel4Stun * 20;
            cout << strYourGirlfriendsName << " Stunned Weasel 4" << endl;
            cout << endl;
            system("Pause");
            }
            else if (intWeasel4Stun <= 5)
            {
            cout << strYourGirlfriendsName << " failed to stun Weasel 4" << endl;
            cout << endl;
            system("Pause");
            }
        }

        if (intEnemyChoice == 3)
        {
        system("CLS");
        srand(static_cast<int>(time(0)));
        intWeasel5Stun = intStunChance + rand()%(10);
        intHairStraightenerCharge -= 1;
            if (intWeasel5Stun >= 5)
            {
            intGFEXP += intWeasel5Stun * 20;
            cout << strYourGirlfriendsName << " Stunned Weasel 5" << endl;
            cout << endl;
            system("Pause");
            }
            else if (intWeasel5Stun <= 5)
            {
            cout << strYourGirlfriendsName << " failed to stun Weasel 5" << endl;
            cout << endl;
            system("Pause");
            }
        }

        if (intEnemyChoice == 6)
        {
        system("CLS");
        srand(static_cast<int>(time(0)));
        intWeasel6Stun = intStunChance + rand()%(10);
        intHairStraightenerCharge -= 1;
            if (intWeasel6Stun >= 5)
            {
            intGFEXP += intWeasel6Stun * 20;
            cout << strYourGirlfriendsName << " Stunned Weasel 6" << endl;
            cout << endl;
            system("Pause");
            }
            else if (intWeasel6Stun <= 5)
            {
            cout << strYourGirlfriendsName << " failed to stun Weasel 6" << endl;
            cout << endl;
            system("Pause");
            }
        }
    }

    if (intGFMoveChoice == 2)
    {
    int intItemChoice;
    system("CLS");
    cout << "Items:" << endl;
    cout << "(1) " << strYourHamstersName << "'s Wheel (Will recharge your Hair Straightener)" << endl;
        if (intJello != 0)
        {
        cout << "(2) A Jell-O Pack (Will increase the hits of " << strWeaselsName << "'s Knife)" << endl;
        }
        if (intBlanket != 0)
        {
        cout << "(3) A Blanket (Will trap the enemy for a turn, will be used up)" << endl;
        }
        cout << endl;
        cin >> intItemChoice;
        if (intItemChoice == 2)
        {
        system("CLS");
        cout << strYourGirlfriendsName << " is not " << strWeaselsName << ". Returning back to Attack Menu..." << endl;
        cout << endl;
        system("Pause");
        intGFMoveChoice = GFWeaselFightMenu(intRecharge, intHairStraightenerCharge, intStunChance, intWeasel1Stun, intWeasel2Stun, intWeasel3Stun, intWeasel4Stun, intWeasel5Stun, intWeasel6Stun, strYourGirlfriendsName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intGFHP, intGFEXP, intJello);
        }

        if (intItemChoice == 1)
        {
        system("CLS");
        intRecharge += 1;
        intHairStraightenerCharge = 10;
        cout << strYourGirlfriendsName << " successfully recharge your Hair Straightener" << endl;
        cout << endl;
        system("Pause");
        }

        if (intItemChoice == 3)
        {
        system("CLS");
        cout << strYourGirlfriendsName << " stunned Weasels Your blanket can no longer be used. It was torn up while they were trying to escape." << endl;
        cout << endl;
        intBlanket -= 1;
        intStunned += 1;
        system("Pause");
        }
    }

    if (intGFMoveChoice == 3)
    {
    system("CLS");
    cout << strYourGirlfriendsName << ":" << endl;
    cout << "Stats:" << endl;
    cout << "Stun Chance: " << intStunChance << " To 10" << endl;
    cout << "HP: " << intGFHP << endl;
    cout << "EXP: " << intGFEXP << endl;
    cout << endl;
    system("Pause");
    intGFMoveChoice = GFWeaselFightMenu(intRecharge, intHairStraightenerCharge, intStunChance, intWeasel1Stun, intWeasel2Stun, intWeasel3Stun, intWeasel4Stun, intWeasel5Stun, intWeasel6Stun, strYourGirlfriendsName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intGFHP, intGFEXP, intJello);
    }

    if (intGFMoveChoice == 4)
    {
    FightHelp(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, strYourHamstersName);
    intGFMoveChoice = GFWeaselFightMenu(intRecharge, intHairStraightenerCharge, intStunChance, intWeasel1Stun, intWeasel2Stun, intWeasel3Stun, intWeasel4Stun, intWeasel5Stun, intWeasel6Stun, strYourGirlfriendsName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intGFHP, intGFEXP, intJello);
    }

    if (intGFMoveChoice == 5)
    {
    system("CLS");
    }
return (intGFMoveChoice);
}

int WeaselWeaselFightMenu(int &intHitCount, int &intWeasel1HP, int &intWeasel2HP, int &intWeasel3HP, int &intWeasel4HP, int &intWeasel5, int &intWeasel6, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intWeaselHP, int intWeaselEXP, int &intJello)
{
system("CLS");
int intWeaselChoice;

cout << "It is " << strWeaselsName << "'s Turn." << endl;
cout << "What will you do?" << endl;
cout << "(1) Slice" << endl;
cout << "(2) Items" << endl;
cout << "(3) Stats" << endl;
cout << "(4) Help" << endl;
cout << "(5) Exit" << endl;
cout << endl;
cin >> intWeaselChoice;

    if (intWeaselChoice == 1)
    {
    int intEnemyChoice;
    system("CLS");
    cout << "Target an enemy: " << endl;
    cout << "(1) Weasel 1 (" << intWeasel1HP << " HP)" << endl;
    cout << "(2) Weasel 2 (" << intWeasel2HP << " HP)" << endl;
    cout << "(3) Weasel 3 (" << intWeasel3HP << " HP)" << endl;
    cout << "(4) Weasel 4 (" << intWeasel4HP << " HP)" << endl;
    cout << "(5) Weasel 5 (" << intWeasel5HP << " HP)" << endl;
    cout << "(6) Weasel 6 (" << intWeasel6HP << " HP)" << endl;
    cout << endl;
    cin >> intEnemyChoice;

        if (intEnemyChoice == 1)
        {
        int intDamage;
        srand(static_cast<int>(time(0)));
        intDamage = 1 + rand()%(2);

        intWeasel1HP -= intHitCount * intDamage;

        intWeaselEXP += intDamage * intHitCount * 20;
        system("CLS");
        cout << strWeaselsName << " dealt " << intDamage * intHitCount << " Damage, with " << intHitCount << " Hits, Weasel 1 has " << intWeasel1HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 2)
        {
        int intDamage;
        srand(static_cast<int>(time(0)));
        intDamage = 1 + rand()%(2);

        intWeasel2HP -= intHitCount * intDamage;

        intWeaselEXP += intDamage * intHitCount * 20;
        system("CLS");
        cout << strWeaselsName << " dealt " << intDamage * intHitCount << " Damage, with " << intHitCount << " Hits, Weasel 2 has " << intWeasel2HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 3)
        {
        int intDamage;
        srand(static_cast<int>(time(0)));
        intDamage = 1 + rand()%(2);

        intWeasel3HP -= intHitCount * intDamage;

        intWeaselEXP += intDamage * intHitCount * 20;
        system("CLS");
        cout << strWeaselsName << " dealt " << intDamage * intHitCount << " Damage, with " << intHitCount << " Hits, Weasel 3 has " << intWeasel3HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 4)
        {
        int intDamage;
        srand(static_cast<int>(time(0)));
        intDamage = 1 + rand()%(2);

        intWeasel4HP -= intHitCount * intDamage;

        intWeaselEXP += intDamage * intHitCount * 20;
        system("CLS");
        cout << strWeaselsName << " dealt " << intDamage * intHitCount << " Damage, with " << intHitCount << " Hits, Weasel 4 has " << intWeasel4HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 5)
        {
        int intDamage;
        srand(static_cast<int>(time(0)));
        intDamage = 1 + rand()%(2);

        intWeasel5HP -= intHitCount * intDamage;

        intWeaselEXP += intDamage * intHitCount * 20;
        system("CLS");
        cout << strWeaselsName << " dealt " << intDamage * intHitCount << " Damage, with " << intHitCount << " Hits, Weasel 5 has " << intWeasel5HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }

        if (intEnemyChoice == 6)
        {
        int intDamage;
        srand(static_cast<int>(time(0)));
        intDamage = 1 + rand()%(2);

        intWeasel6HP -= intHitCount * intDamage;

        intWeaselEXP += intDamage * intHitCount * 20;
        system("CLS");
        cout << strWeaselsName << " dealt " << intDamage * intHitCount << " Damage, with " << intHitCount << " Hits, Weasel 6 has " << intWeasel6HP << " HP left." << endl;
        cout << endl;
        system("Pause");
        }
    }

    if (intWeaselChoice == 2)
    {
    int intItemChoice;
    system("CLS");
    cout << "Items:" << endl;
    cout << "(1) " << strYourHamstersName << "'s Wheel" << endl;
        if (intJello != 0)
        {
        cout << "(2) A Jell-O Pack (Will increase the hits of " << strWeaselsName << "'s Knife)" << endl;
        }
        if (intBlanket != 0)
        {
        cout << "(3) A Blanket (Will trap the enemy for a turn, will be used up)" << endl;
        }
        cout << endl;
        cin >> intItemChoice;
        if (intItemChoice == 2)
        {
        system("CLS");
        cout << "You are " << strWeaselsName << ". Increasing Hit Count..." << endl;
        cout << endl;
        intHitCount += 2;
        intJello = 0;
        system("Pause");
        }

        if (intItemChoice == 1)
        {
        system("CLS");
        cout << strWeaselsName << " has nothing to recharge..." << endl;
        system("Pause");
        intWeaselChoice = WeaselWeaselFightMenu(intHitCount, intWeasel1HP, intWeasel2HP, intWeasel3HP, intWeasel4HP, intWeasel5HP, intWeasel6HP, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intWeaselHP, intWeaselEXP, intJello);
        }

        if (intItemChoice == 3)
        {
        system("CLS");
        cout << strWeaselsName << " stunned Weasels Your blanket can no longer be used. It was torn up while they were trying to escape." << endl;
        intBlanket -= 1;
        intStunned += 1;
        system("Pause");
        system("CLS");
        }
    }

    if (intWeaselChoice == 3)
    {
    system("CLS");
    cout << strWeaselsName << ":" << endl;
    cout << "Stats:" << endl;
    cout << "Hit Count: " << intHitCount << endl;
    cout << "HP: " << intWeaselHP << endl;
    cout << "EXP: " << intWeaselEXP << endl;
    cout << endl;
    system("Pause");
    intWeaselChoice = WeaselWeaselFightMenu(intHitCount, intWeasel1HP, intWeasel2HP, intWeasel3HP, intWeasel4HP, intWeasel5HP, intWeasel6HP, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intWeaselHP, intWeaselEXP, intJello);
    }

    if (intWeaselChoice == 4)
    {
    FightHelp(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, strYourHamstersName);
    intWeaselChoice = WeaselWeaselFightMenu(intHitCount, intWeasel1HP, intWeasel2HP, intWeasel3HP, intWeasel4HP, intWeasel5HP, intWeasel6HP, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intWeaselHP, intWeaselEXP, intJello);
    }

    if (intWeaselChoice == 5)
    {
    system("CLS");
    }
return (intWeaselChoice);
}

int LlamaWeaselFightMenu(int intAccuracyLowered, int &intWeasel1Accuracy, int &intWeasel2Accuracy, int &intWeasel3Accuracy, int &intWeasel4Accuracy, int &intWeasel5Accuracy, int &intWeasel6Accuracy, string strLlamasName, string strWeaselsName, string strYourHamstersName, int &intBlanket, int &intStunned, int intLlamaHP, int intLlamaEXP, int intJello)
{
system("CLS");
int intLlamaChoice;

cout << "It is " << strLlamasName << "'s Turn." << endl;
cout << "What will you do?" << endl;
cout << "(1) Spit" << endl;
cout << "(2) Items" << endl;
cout << "(3) Stats" << endl;
cout << "(4) Help" << endl;
cout << "(5) Exit" << endl;
cout << endl;
cin >> intLlamaChoice;

    if (intLlamaChoice == 1)
    {
    int intEnemyChoice;
    system("CLS");
    cout << "Target an enemy: " << endl;
    cout << "(1) Weasel 1 (" << intWeasel1HP << " HP)" << endl;
    cout << "(2) Weasel 2 (" << intWeasel2HP << " HP)" << endl;
    cout << "(3) Weasel 3 (" << intWeasel3HP << " HP)" << endl;
    cout << "(4) Weasel 4 (" << intWeasel4HP << " HP)" << endl;
    cout << "(5) Weasel 5 (" << intWeasel5HP << " HP)" << endl;
    cout << "(6) Weasel 6 (" << intWeasel6HP << " HP)" << endl;
    cout << endl;
    cin >> intEnemyChoice;

        if (intEnemyChoice == 1)
        {
        int intAccuracy;
        srand(static_cast<int>(time(0)));
        intAccuracy = 1 + rand()%(2);

        intWeasel1Accuracy -= intAccuracy * intAccuracyLowered;

        intLlamaEXP += intAccuracy * intAccuracyLowered * 20;
        system("CLS");
        cout << strLlamasName << " lowered Weasel 1's Accuracy by " << intAccuracy * intAccuracyLowered << ", Weasel 1 has " << intWeasel1HP << " HP left." << endl;
        cout << endl;
        system("Pause");

        }

        if (intEnemyChoice == 2)
        {
        int intAccuracy;
        srand(static_cast<int>(time(0)));
        intAccuracy = 1 + rand()%(2);

        intWeasel2Accuracy -= intAccuracy * intAccuracyLowered;

        intLlamaEXP += intAccuracy * intAccuracyLowered * 20;
        system("CLS");
        cout << strLlamasName << " lowered Weasel 2's Accuracy by " << intAccuracy * intAccuracyLowered << ", Weasel 2 has " << intWeasel2HP << " HP left." << endl;
        cout << endl;
        system("Pause");

        }

        if (intEnemyChoice == 3)
        {
        int intAccuracy;
        srand(static_cast<int>(time(0)));
        intAccuracy = 1 + rand()%(2);

        intWeasel3Accuracy -= intAccuracy * intAccuracyLowered;

        intLlamaEXP += intAccuracy * intAccuracyLowered * 20;
        system("CLS");
        cout << strLlamasName << " lowered Weasel 3's Accuracy by " << intAccuracy * intAccuracyLowered << ", Weasel 3 has " << intWeasel3HP << " HP left." << endl;
        cout << endl;
        system("Pause");

        }

        if (intEnemyChoice == 4)
        {
        int intAccuracy;
        srand(static_cast<int>(time(0)));
        intAccuracy = 1 + rand()%(2);

        intWeasel4Accuracy -= intAccuracy * intAccuracyLowered;

        intLlamaEXP += intAccuracy * intAccuracyLowered * 20;
        system("CLS");
        cout << strLlamasName << " lowered Weasel 4's Accuracy by " << intAccuracy * intAccuracyLowered << ", Weasel 4 has " << intWeasel4HP << " HP left." << endl;
        cout << endl;
        system("Pause");

        }

        if (intEnemyChoice == 5)
        {
        int intAccuracy;
        srand(static_cast<int>(time(0)));
        intAccuracy = 1 + rand()%(2);

        intWeasel5Accuracy -= intAccuracy * intAccuracyLowered;

        intLlamaEXP += intAccuracy * intAccuracyLowered * 20;
        system("CLS");
        cout << strLlamasName << " lowered Weasel 5's Accuracy by " << intAccuracy * intAccuracyLowered << ", Weasel 5 has " << intWeasel5HP << " HP left." << endl;
        cout << endl;
        system("Pause");

        }

        if (intEnemyChoice == 4)
        {
        int intAccuracy;
        srand(static_cast<int>(time(0)));
        intAccuracy = 1 + rand()%(2);

        intWeasel6Accuracy -= intAccuracy * intAccuracyLowered;

        intLlamaEXP += intAccuracy * intAccuracyLowered * 20;
        system("CLS");
        cout << strLlamasName << " lowered Weasel 6's Accuracy by " << intAccuracy * intAccuracyLowered << ", Weasel 6 has " << intWeasel6HP << " HP left." << endl;
        cout << endl;
        system("Pause");

        }
    }

    if (intLlamaChoice == 2)
    {
    int intItemChoice;
    system("CLS");
    cout << "Items:" << endl;
    cout << "(1) " << strYourHamstersName << "'s Wheel" << endl;
        if (intJello != 0)
        {
        cout << "(2) A Jell-O Pack (Will increase the hits of " << strWeaselsName << "'s Knife)" << endl;
        }
        if (intBlanket != 0)
        {
        cout << "(3) A Blanket (Will trap the enemy for a turn, will be used up)" << endl;
        }
        cout << endl;
        cin >> intItemChoice;

        if (intItemChoice == 2)
        {
        system("CLS");
        cout << strLlamasName << " is not " << strWeaselsName << ". Returning back to Attack Menu..." << endl;
        cout << endl;
        system("Pause");
        intLlamaChoice = LlamaWeaselFightMenu(intAccuracyLowered, intWeasel1Accuracy, intWeasel2Accuracy, intWeasel3Accuracy, intWeasel4Accuracy, intWeasel5Accuracy, intWeasel6Accuracy, strLlamasName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intLlamaHP, intLlamaEXP, intJello);
        }

        if (intItemChoice == 1)
        {
        system("CLS");
        cout << strLlamasName << " has nothing to recharge. Returning back to Attack Menu..." << endl;
        cout << endl;
        system("Pause");
        intLlamaChoice = LlamaWeaselFightMenu(intAccuracyLowered, intWeasel1Accuracy, intWeasel2Accuracy, intWeasel3Accuracy, intWeasel4Accuracy, intWeasel5Accuracy, intWeasel6Accuracy, strLlamasName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intLlamaHP, intLlamaEXP, intJello);
        }

        if (intItemChoice == 3)
        {
        system("CLS");
        cout << strLlamasName << " stunned Weasels Your blanket can no longer be used. It was torn up while they were trying to escape." << endl;
        cout << endl;
        intBlanket -= 1;
        intStunned += 1;
        system("Pause");
        }
    }

    if (intLlamaChoice == 3)
    {
    system("CLS");
    cout << strLlamasName << ":" << endl;
    cout << "Stats:" << endl;
    cout << "Accuracy Lowered: " << intAccuracyLowered << endl;
    cout << "HP: " << intLlamaHP << endl;
    cout << "EXP: " << intLlamaEXP << endl;
    cout << endl;
    system("Pause");
    intLlamaChoice = LlamaWeaselFightMenu(intAccuracyLowered, intWeasel1Accuracy, intWeasel2Accuracy, intWeasel3Accuracy, intWeasel4Accuracy, intWeasel5Accuracy, intWeasel6Accuracy, strLlamasName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intLlamaHP, intLlamaEXP, intJello);
    }

    if (intLlamaChoice == 4)
    {
    FightHelp(strWeaselsName, strLlamasName, strYourGirlfriendsName, strYourName, strYourHamstersName);
    intLlamaChoice = LlamaWeaselFightMenu(intAccuracyLowered, intWeasel1Accuracy, intWeasel2Accuracy, intWeasel3Accuracy, intWeasel4Accuracy, intWeasel5Accuracy, intWeasel6Accuracy, strLlamasName, strWeaselsName, strYourHamstersName, intBlanket, intStunned, intLlamaHP, intLlamaEXP, intJello);
    }

    if (intLlamaChoice == 5)
    {
    system("CLS");
    }
return (intLlamaChoice);
}

void Weasel1(int intWeasel1HP, int intWeasel1Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName)
{
    if (intWeasel1HP > 0)
    {
    system("CLS");

    int intCharacterHit;

    srand(static_cast<int>(time(0)));
    intCharacterHit = 1 + rand()%(4);

        if (intCharacterHit == 1)
        {
            if (intWeasel1Accuracy <= 0)
            {

            cout << "Weasel 1 tried to stab " << strYourName << " with a pencil but missed! Your HP is still at " << intYourHP << endl;
            cout << endl;
            system("Pause");

            }

            if (intWeasel1Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel1Accuracy;

                if (intChanceToHit <= 0)
                {
                intYourHP -= 1;

                cout << "Weasel 1 stabbed " << strYourName << " with a pencil! You lost 1 HP. Your HP is now " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 1 tried to stab " << strYourName << " with a pencil but missed! Your HP is still at " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 2)
        {
            if (intWeasel1Accuracy <= 0)
            {
            cout << "Weasel 1 tried to stab " << strYourGirlfriendsName << " with a pencil but missed! Your HP is still at " << intGFHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intWeasel1Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel1Accuracy;

                if (intChanceToHit <= 0)
                {
                intGFHP -= 1;

                cout << "Weasel 1 stabbed " << strYourGirlfriendsName << " with a pencil! You lost 1 HP. Your HP is now " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 1 tried to stab " << strYourGirlfriendsName << " with a pencil but missed! Your HP is still at " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 3)
        {
            if (intWeasel1Accuracy <= 0)
            {
            cout << "Weasel 1 tried to stab " << strWeaselsName << " with a pencil but missed! Your HP is still at " << intWeaselHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intWeasel1Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel1Accuracy;

                if (intChanceToHit <= 0)
                {
                intWeaselHP -= 1;

                cout << "Weasel 1 stabbed " << strWeaselsName << " with a pencil! You lost 1 HP. Your HP is now " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 1 tried to stab " << strWeaselsName << " with a pencil but missed! Your HP is still at " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 4)
        {

            if (intWeasel1Accuracy <= 0)
            {
            cout << "Weasel 1 tried to stab " << strLlamasName << " with a pencil but missed! Your HP is still at " << intLlamaHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intWeasel1Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel1Accuracy;

                if (intChanceToHit <= 0)
                {
                intLlamaHP -= 1;

                cout << "Weasel 1 stabbed " << strLlamasName << " with a pencil! You lost 1 HP. Your HP is now " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 1 tried to stab " << strLlamasName << " with a pencil but missed! Your HP is still at " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }
    }
    if (intWeasel1HP < 0)
    {
    system("CLS");
    cout << "Weasel 1 is Dead!" << endl;
    cout << endl;
    system("Pause");
    }
}

void Weasel2(int intWeasel2HP, int intWeasel2Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName)
{
    if (intWeasel2HP > 0)
    {
    system("CLS");

    int intCharacterHit;

    srand(static_cast<int>(time(0)));
    intCharacterHit = 1 + rand()%(4);

        if (intCharacterHit == 1)
        {
            if (intWeasel2Accuracy <= 0)
            {

            cout << "Weasel 2 tried to stab " << strYourName << " with a pencil but missed! Your HP is still at " << intYourHP << endl;
            cout << endl;
            system("Pause");

            }

            if (intWeasel2Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel2Accuracy;

                if (intChanceToHit <= 0)
                {
                intYourHP -= 1;

                cout << "Weasel 2 stabbed " << strYourName << " with a pencil! You lost 1 HP. Your HP is now " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 2 tried to stab " << strYourName << " with a pencil but missed! Your HP is still at " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 2)
        {
            if (intWeasel2Accuracy <= 0)
            {
            cout << "Weasel 2 tried to stab " << strYourGirlfriendsName << " with a pencil but missed! Your HP is still at " << intGFHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intWeasel2Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel2Accuracy;

                if (intChanceToHit <= 0)
                {
                intGFHP -= 1;

                cout << "Weasel 2 stabbed " << strYourGirlfriendsName << " with a pencil! You lost 1 HP. Your HP is now " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 2 tried to stab " << strYourGirlfriendsName << " with a pencil but missed! Your HP is still at " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 3)
        {
            if (intWeasel2Accuracy <= 0)
            {
            cout << "Weasel 2 tried to stab " << strWeaselsName << " with a pencil but missed! Your HP is still at " << intWeaselHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intWeasel2Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel2Accuracy;

                if (intChanceToHit <= 0)
                {
                intWeaselHP -= 1;

                cout << "Weasel 2 stabbed " << strWeaselsName << " with a pencil! You lost 1 HP. Your HP is now " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 2 tried to stab " << strWeaselsName << " with a pencil but missed! Your HP is still at " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 4)
        {

            if (intWeasel2Accuracy <= 0)
            {
            cout << "Weasel 2 tried to stab " << strLlamasName << " with a pencil but missed! Your HP is still at " << intLlamaHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intWeasel2Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel2Accuracy;

                if (intChanceToHit <= 0)
                {
                intLlamaHP -= 1;

                cout << "Weasel 2 stabbed " << strLlamasName << " with a pencil! You lost 1 HP. Your HP is now " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 2 tried to stab " << strLlamasName << " with a pencil but missed! Your HP is still at " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }
    }
    if (intWeasel2HP < 0)
    {
    system("CLS");
    cout << "Weasel 2 is Dead!" << endl;
    cout << endl;
    system("Pause");
    }
}

void Weasel3(int intWeasel3HP, int intWeasel3Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName)
{
    if (intWeasel3HP > 0)
    {
    system("CLS");

    int intCharacterHit;

    srand(static_cast<int>(time(0)));
    intCharacterHit = 1 + rand()%(4);

        if (intCharacterHit == 1)
        {
            if (intWeasel3Accuracy <= 0)
            {

            cout << "Weasel 3 tried to stab " << strYourName << " with a pencil but missed! Your HP is still at " << intYourHP << endl;
            cout << endl;
            system("Pause");

            }

            if (intWeasel3Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel3Accuracy;

                if (intChanceToHit <= 0)
                {
                intYourHP -= 1;

                cout << "Weasel 3 stabbed " << strYourName << " with a pencil! You lost 1 HP. Your HP is now " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 3 tried to stab " << strYourName << " with a pencil but missed! Your HP is still at " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 2)
        {
            if (intWeasel3Accuracy <= 0)
            {
            cout << "Weasel 3 tried to stab " << strYourGirlfriendsName << " with a pencil but missed! Your HP is still at " << intGFHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intWeasel3Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel3Accuracy;

                if (intChanceToHit <= 0)
                {
                intGFHP -= 1;

                cout << "Weasel 3 stabbed " << strYourGirlfriendsName << " with a pencil! You lost 1 HP. Your HP is now " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 3 tried to stab " << strYourGirlfriendsName << " with a pencil but missed! Your HP is still at " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 3)
        {
            if (intWeasel3Accuracy <= 0)
            {
            cout << "Weasel 3 tried to stab " << strWeaselsName << " with a pencil but missed! Your HP is still at " << intWeaselHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intWeasel3Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel3Accuracy;

                if (intChanceToHit <= 0)
                {
                intWeaselHP -= 1;

                cout << "Weasel 3 stabbed " << strWeaselsName << " with a pencil! You lost 1 HP. Your HP is now " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 3 tried to stab " << strWeaselsName << " with a pencil but missed! Your HP is still at " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 4)
        {

            if (intWeasel3Accuracy <= 0)
            {
            cout << "Weasel 3 tried to stab " << strLlamasName << " with a pencil but missed! Your HP is still at " << intLlamaHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intWeasel3Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel3Accuracy;

                if (intChanceToHit <= 0)
                {
                intLlamaHP -= 1;

                cout << "Weasel 3 stabbed " << strLlamasName << " with a pencil! You lost 1 HP. Your HP is now " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 3 tried to stab " << strLlamasName << " with a pencil but missed! Your HP is still at " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }
    }
    if (intWeasel3HP < 0)
    {
    system("CLS");
    cout << "Weasel 3 is Dead!" << endl;
    cout << endl;
    system("Pause");
    }
}

void Weasel4(int intWeasel4HP, int intWeasel4Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName)
{
    if (intWeasel4HP > 0)
    {
    system("CLS");

    int intCharacterHit;

    srand(static_cast<int>(time(0)));
    intCharacterHit = 1 + rand()%(4);

        if (intCharacterHit == 1)
        {
            if (intWeasel4Accuracy <= 0)
            {

            cout << "Weasel 4 tried to stab " << strYourName << " with a pencil but missed! Your HP is still at " << intYourHP << endl;
            cout << endl;
            system("Pause");

            }

            if (intWeasel4Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel4Accuracy;

                if (intChanceToHit <= 0)
                {
                intYourHP -= 1;

                cout << "Weasel 4 stabbed " << strYourName << " with a pencil! You lost 1 HP. Your HP is now " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 4 tried to stab " << strYourName << " with a pencil but missed! Your HP is still at " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 2)
        {
            if (intWeasel4Accuracy <= 0)
            {
            cout << "Weasel 4 tried to stab " << strYourGirlfriendsName << " with a pencil but missed! Your HP is still at " << intGFHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intWeasel4Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel4Accuracy;

                if (intChanceToHit <= 0)
                {
                intGFHP -= 1;

                cout << "Weasel 4 stabbed " << strYourGirlfriendsName << " with a pencil! You lost 1 HP. Your HP is now " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 4 tried to stab " << strYourGirlfriendsName << " with a pencil but missed! Your HP is still at " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 3)
        {
            if (intWeasel4Accuracy <= 0)
            {
            cout << "Weasel 4 tried to stab " << strWeaselsName << " with a pencil but missed! Your HP is still at " << intWeaselHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intWeasel4Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel4Accuracy;

                if (intChanceToHit <= 0)
                {
                intWeaselHP -= 1;

                cout << "Weasel 4 stabbed " << strWeaselsName << " with a pencil! You lost 1 HP. Your HP is now " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 4 tried to stab " << strWeaselsName << " with a pencil but missed! Your HP is still at " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 4)
        {

            if (intWeasel4Accuracy <= 0)
            {
            cout << "Weasel 4 tried to stab " << strLlamasName << " with a pencil but missed! Your HP is still at " << intLlamaHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intWeasel4Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel4Accuracy;

                if (intChanceToHit <= 0)
                {
                intLlamaHP -= 1;

                cout << "Weasel 4 stabbed " << strLlamasName << " with a pencil! You lost 1 HP. Your HP is now " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 4 tried to stab " << strLlamasName << " with a pencil but missed! Your HP is still at " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }
    }
    if (intWeasel4HP < 0)
    {
    system("CLS");
    cout << "Weasel 4 is Dead!" << endl;
    cout << endl;
    system("Pause");
    }
}

void Weasel5(int intWeasel5HP, int intWeasel5Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName)
{
    if (intWeasel5HP > 0)
    {
    system("CLS");

    int intCharacterHit;

    srand(static_cast<int>(time(0)));
    intCharacterHit = 1 + rand()%(4);

        if (intCharacterHit == 1)
        {
            if (intWeasel5Accuracy <= 0)
            {

            cout << "Weasel 5 tried to stab " << strYourName << " with a pencil but missed! Your HP is still at " << intYourHP << endl;
            cout << endl;
            system("Pause");

            }

            if (intWeasel5Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel5Accuracy;

                if (intChanceToHit <= 0)
                {
                intYourHP -= 1;

                cout << "Weasel 5 stabbed " << strYourName << " with a pencil! You lost 1 HP. Your HP is now " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 5 tried to stab " << strYourName << " with a pencil but missed! Your HP is still at " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 2)
        {
            if (intWeasel5Accuracy <= 0)
            {
            cout << "Weasel 5 tried to stab " << strYourGirlfriendsName << " with a pencil but missed! Your HP is still at " << intGFHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intWeasel5Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel5Accuracy;

                if (intChanceToHit <= 0)
                {
                intGFHP -= 1;

                cout << "Weasel 5 stabbed " << strYourGirlfriendsName << " with a pencil! You lost 1 HP. Your HP is now " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 5 tried to stab " << strYourGirlfriendsName << " with a pencil but missed! Your HP is still at " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 3)
        {
            if (intWeasel5Accuracy <= 0)
            {
            cout << "Weasel 5 tried to stab " << strWeaselsName << " with a pencil but missed! Your HP is still at " << intWeaselHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intWeasel5Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel5Accuracy;

                if (intChanceToHit <= 0)
                {
                intWeaselHP -= 1;

                cout << "Weasel 5 stabbed " << strWeaselsName << " with a pencil! You lost 1 HP. Your HP is now " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 5 tried to stab " << strWeaselsName << " with a pencil but missed! Your HP is still at " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 4)
        {

            if (intWeasel5Accuracy <= 0)
            {
            cout << "Weasel 5 tried to stab " << strLlamasName << " with a pencil but missed! Your HP is still at " << intLlamaHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intWeasel5Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel5Accuracy;

                if (intChanceToHit <= 0)
                {
                intLlamaHP -= 1;

                cout << "Weasel 5 stabbed " << strLlamasName << " with a pencil! You lost 1 HP. Your HP is now " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 5 tried to stab " << strLlamasName << " with a pencil but missed! Your HP is still at " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }
    }
    if (intWeasel5HP < 0)
    {
    system("CLS");
    cout << "Weasel 5 is Dead!" << endl;
    cout << endl;
    system("Pause");
    }
}

void Weasel6(int intWeasel6HP, int intWeasel6Accuracy, int &intYourHP, int &intGFHP, int &intWeaselHP, int &intLlamaHP, string strYourName, string strYourGirlfriendsName, string strWeaselsName, string strLlamasName)
{
    if (intWeasel6HP > 0)
    {
    system("CLS");

    int intCharacterHit;

    srand(static_cast<int>(time(0)));
    intCharacterHit = 1 + rand()%(4);

        if (intCharacterHit == 1)
        {
            if (intWeasel6Accuracy <= 0)
            {

            cout << "Weasel 6 tried to stab " << strYourName << " with a pencil but missed! Your HP is still at " << intYourHP << endl;
            cout << endl;
            system("Pause");

            }

            if (intWeasel6Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel6Accuracy;

                if (intChanceToHit <= 0)
                {
                intYourHP -= 1;

                cout << "Weasel 6 stabbed " << strYourName << " with a pencil! You lost 1 HP. Your HP is now " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 6 tried to stab " << strYourName << " with a pencil but missed! Your HP is still at " << intYourHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 2)
        {
            if (intWeasel6Accuracy <= 0)
            {
            cout << "Weasel 6 tried to stab " << strYourGirlfriendsName << " with a pencil but missed! Your HP is still at " << intGFHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intWeasel6Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel6Accuracy;

                if (intChanceToHit <= 0)
                {
                intGFHP -= 1;

                cout << "Weasel 6 stabbed " << strYourGirlfriendsName << " with a pencil! You lost 1 HP. Your HP is now " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 6 tried to stab " << strYourGirlfriendsName << " with a pencil but missed! Your HP is still at " << intGFHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 3)
        {
            if (intWeasel6Accuracy <= 0)
            {
            cout << "Weasel 6 tried to stab " << strWeaselsName << " with a pencil but missed! Your HP is still at " << intWeaselHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intWeasel6Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel6Accuracy;

                if (intChanceToHit <= 0)
                {
                intWeaselHP -= 1;

                cout << "Weasel 6 stabbed " << strWeaselsName << " with a pencil! You lost 1 HP. Your HP is now " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 6 tried to stab " << strWeaselsName << " with a pencil but missed! Your HP is still at " << intWeaselHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }

        if (intCharacterHit == 4)
        {

            if (intWeasel6Accuracy <= 0)
            {
            cout << "Weasel 6 tried to stab " << strLlamasName << " with a pencil but missed! Your HP is still at " << intLlamaHP << endl;
            cout << endl;
            system("Pause");
            }

            if (intWeasel6Accuracy >= 1)
            {
            int intChanceToHit;
            srand(static_cast<int>(time(0)));
            intChanceToHit = 0 + rand()%(10);
            intChanceToHit -= intWeasel6Accuracy;

                if (intChanceToHit <= 0)
                {
                intLlamaHP -= 1;

                cout << "Weasel 6 stabbed " << strLlamasName << " with a pencil! You lost 1 HP. Your HP is now " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }

                if (intChanceToHit >= 1)
                {
                cout << "Weasel 6 tried to stab " << strLlamasName << " with a pencil but missed! Your HP is still at " << intLlamaHP << endl;
                cout << endl;
                system("Pause");
                }
            }
        }
    }
    if (intWeasel6HP < 0)
    {
    system("CLS");
    cout << "Weasel 6 is Dead!" << endl;
    cout << endl;
    system("Pause");
    }
}

void GovernmentEnding()
{
system("CLS");

cout << "You keep on traveling through the various State governments you find all of them being the same case as how you found the Florida one." << endl;
cout << "They are all taken down or dismantled one way or another. There's no hope of finding a solution the government doesn't exist anymore." << endl;
cout << "You get to The White House and unfortunately its the same case it's in ruins with no hope of any help. The world is what it is, and there's" << endl;
cout << "nothing you can do. You decide to stop and stay in The White House at least its safe there. You stop there and live out the rest of your life" << endl;
cout << "with your Girlfriend, Weasel and Llama." << endl;

system("Pause");
Game(intStartGame);
}

void DirectEnding()
{
system("CLS");

cout << "You make it Midwest and find a safe spot to hide and scavenge for whatever you need. You never find out what it is that caused all this but you don't" << endl;
cout << "really need to. Your just trying to make your life last. Thankfully by now most of the violent people in the world have killed each other. Theres not" << endl;
cout << "many people left but you find a small community and stay with them, along with your Girlfriend, Weasel and Llama." << endl;

system("Pause");
Game(intStartGame);
}

void BoatEnding()
{

cout << "You get down south and are able to find a boat that can be powered by both wind and electricity. You use this and start sailing Midwest, but you" << endl;
cout << "realize your probably safer here. You ask everyone what they think and they agree. So for the rest of your life you travel around finding different" << endl;
cout << "ways to power the boat, get food, water anything you need. You use the sail when your out of power and try to get back to shore. You try communicating" << endl;
cout << "through radio but get no responses. It's just you your Girlfriend, The Weasel, and The Llama forever...Great!" << endl;

system("Pause");
Game(intStartGame);
}

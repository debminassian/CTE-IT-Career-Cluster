public class IncreaseDecrease
{
    public static void main(String args[]) 
    {
    int num1 = 4;
    int num2 = 3;

    System.out.print("num1 = ");
    System.out.println(num1);
    System.out.print("num2 = ");
    System.out.println(num2);
    
    System.out.println("Increasing the value of num1");
    // ++ increases the value by 1
    num1++;
    
    System.out.println("Decreasing the value of num2");
    // -- decreases the value by 1
    num2--;

    System.out.print("num1 = ");
    System.out.println(num1);
    System.out.print("num2 = ");
    System.out.println(num2);
    }
}
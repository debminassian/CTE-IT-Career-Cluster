public class MyAge
{
    public static void main(String[] args)
    {
        // Start here!
    }
}
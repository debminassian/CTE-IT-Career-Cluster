# Example: All Functions Calculator
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

# Example: Increase/Decrease by 1
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

# Problem 1 - Work Shift
A doctor works 20 hours, 42 minutes, and 16 seconds in one shift at a hospital. Convert the total shift time into seconds and display that information.

**NOTE**: You must use at least ONE compound operator (`+=, -=, *=, /=, %=`) to complete this program.

# Problem 2 - My Age
Using only one variable called `age` and the increment and decrement operators, produce the output for your current and upcoming age next year, then back to your current age.

Sample output:
```
My current age is: 14
My age next year will be: 15
My current age is: 14
```
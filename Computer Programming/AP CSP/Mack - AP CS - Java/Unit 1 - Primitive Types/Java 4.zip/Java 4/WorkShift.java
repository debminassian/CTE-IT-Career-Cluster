public class WorkShift
{
    public static void main(String[] args)
    {
        // Start here!
    }
}
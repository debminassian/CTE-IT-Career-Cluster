public class Calculator 
{
    public static void main(String[] args)
    {
        /*Change the values of first and second below to different integers 
          to test the program. Do negative integers work? 
          What happens with decimal numbers? Why? */ 
        double first = 12.5;
        double second = 17.3; 
        double sum = first + second;
        System.out.println(sum);
    }
}
public class Pyramid 
{
    public static void main(String[] args)
    {
        
    }
}
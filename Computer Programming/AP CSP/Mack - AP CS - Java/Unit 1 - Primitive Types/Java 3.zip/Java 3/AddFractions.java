public class AddFractions 
{
    public static void main(String[] args)
    {
        //Your code goes here! 
    }
}
public class Pig extends Animal
{
    @Override
    public void talk()
    {
        System.out.println("Oink");
    }
}
public class Animal
{
    public void talk() {
         System.out.println("I don't know what to say!");
    }
}
public class Cow extends Animal
{
    @Override
    public void talk()
    {
        System.out.println("Moo");
    }
}
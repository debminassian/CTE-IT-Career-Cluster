import java.util.ArrayList;

public class PieTester
{
    public static void main(String[] args)
    {
        // Start here!
    }
}

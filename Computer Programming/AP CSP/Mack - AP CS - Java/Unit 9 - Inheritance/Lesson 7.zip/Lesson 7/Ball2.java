public class Ball2
{
   private String color;
   
   public Ball2(String color){
       this.color = color;
   }
   
   public String getColor(){
       return color;
   }
   
   // Write an equals method here that returns true if
   // the colors are the same.
   
   // Write a toString statement here, for example:
   // Color: Red
   
   
}

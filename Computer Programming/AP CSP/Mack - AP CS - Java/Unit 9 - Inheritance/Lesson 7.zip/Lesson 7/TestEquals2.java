public class TestEquals2
{
    public static void main(String[] args)
    {
        System.out.println("** Object **");
        Object obj1 = new Object();
        Object obj2 = new Object();
        Object obj3 = obj1;
        
        // Copy your entire code from the previous exercise

        
        System.out.println("** Ball **");
        
        
        Ball2 ball_1 = new Ball2("Red");
        Ball2 ball_2 = new Ball2("Red");
        Ball2 ball_3 = ball_1;

    }
}

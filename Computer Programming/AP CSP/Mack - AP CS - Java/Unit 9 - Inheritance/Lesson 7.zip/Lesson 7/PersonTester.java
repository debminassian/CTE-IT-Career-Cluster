public class PersonTester
{
    public static void main(String[] args)
    {
        Person mikiah = new Person("Mikiah", "04/13/1998");
        
        //The toString override will provide a better output. 
        System.out.println(mikiah);
    }
}

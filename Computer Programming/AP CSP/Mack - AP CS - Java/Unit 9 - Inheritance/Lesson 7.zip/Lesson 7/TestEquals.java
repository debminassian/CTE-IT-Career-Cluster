public class TestEquals
{
    public static void main(String[] args)
    {
        System.out.println("** Object **");
        Object obj1 = new Object();
        Object obj2 = new Object();
        Object obj3 = obj1;
        
        // Print out all three objects

        
        // Print a true statement using 2 objects and ==

        
        // Print a false statement using 2 objects and ==

        
        // Print a true statement using 2 objects and .equals()

        
        // Print a false statement using 2 objects and .equals()

        
        System.out.println("** Ball **");
        
        
        Ball ball1 = new Ball("Red");
        Ball ball2 = new Ball("Red");
        Ball ball3 = ball1;
        
        // Print out all three objects
        
        
         // Print a true statement using 2 objects and ==

        
        // Print a false statement using 2 objects and ==

        
        // Print a true statement using 2 objects and .equals()

        
        // Print a false statement using 2 objects and .equals()


    }
}

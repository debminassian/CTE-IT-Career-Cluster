# Problem 1 - Dogs Bark

Not all dogs like to bark, but some like to make a lot of noise! In this exercise we have a `Dog` superclass and a `LoudDog` subclass. You do not need to modify the Dog class.

Your task is to write two override methods in the LoudDog class. You will override the speak method to return `BARK!`. You will then override the toString so that it returns **Clover is loud and likes to BARK!** where Clover is replaced by the name variable.

Create and print at least one `Dog` and one `LoudDog` to test.
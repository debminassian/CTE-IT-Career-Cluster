public class DogTester
{
    public static void main(String[] args)
    {
        // Start here
    }
}

public class Dict extends Book
{
    private int pages;
    private String name;
    private int words;
    
    public int getPages() {
        return pages;
    }
    
    public void setPages(int pages) {
        this.pages = pages;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public int getWords() {
        return words;
    }
    
    public void setWords(int words) {
        this.words = words;
    }
}

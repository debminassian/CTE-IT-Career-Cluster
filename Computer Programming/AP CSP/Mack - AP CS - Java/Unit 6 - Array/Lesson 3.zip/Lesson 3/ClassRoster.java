public class ClassRoster
{
    public static void main(String[] args)
    {
        Student2 julian = new Student2("Julian", "Jones", 9);
        Student2 larisa = new Student2("Larisa", "Torres", 10);
        Student2 amada = new Student2("Amada", "Robin", 10);
        Student2 mikka = new Student2("Mikka", "Leads", 9);
        Student2 jay = new Student2("Jay", "Khalil", 10);
        
        Student2[] classroom = {julian, larisa, amada, mikka, jay};

        // for each for printing goes here 
        
    }
}
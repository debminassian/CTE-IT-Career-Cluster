public class MyArray
{
    public static void main(String[] args)
    {
        int[] scores = {80, 92, 91, 68, 88};

        for(int score : scores)
        {
        	System.out.println(score);
        }
    }
}
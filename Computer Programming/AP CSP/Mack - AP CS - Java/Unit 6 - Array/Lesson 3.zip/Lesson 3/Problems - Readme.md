# Problem 1 - Largest Value

In this exercise, rewrite the for-each loop that finds the largest value in an array as a for or while loop.

# Problem 2 - Classroom Array
In this exercise, use the `Student` class to print out each student using a `for-each` loop with their first name, last name and grade level.

You will need to finish the class with the appropriate getter (accessor) methods for last name and grade level.

You must print in the for each loop, and NOT use the `toString` method in the class.

Output:

`Julian Jones is in grade 9`
`Larisa Torres is in grade 10`
`Amada Robin is in grade 10`
`Mikka Leads is in grade 9`
`Jay Khalil is in grade 10`
`Julian Jones is in grade: 9`
public class MyArray
{
    public static void main(String[] args)
    {
        int[] scores = {80, 92, 91, 68, 88};
        for(int i = 0; i < scores.length; i++)
        {
	        // This prints out the ith element!
	        System.out.println(scores[i]);
        }
    }
}
public class FirstArray
{
    public static void main(String[] args)
    {
      // Create the 3 arrays here
        
      // Print all 3 arrays according to the output in the description
    
    }
}
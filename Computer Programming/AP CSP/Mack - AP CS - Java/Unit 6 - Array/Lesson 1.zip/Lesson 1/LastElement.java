public class LastElement
{
    public static void main(String[] args)
    {
        String[] arr = new String[]{"hello", "my name", "world", "Chad", "Monkey D. Luffy"};
        //get and print the last element of the array
    }

    public static String getLastElement(String[] arr)
    {
        // Your code goes here!
    }
}
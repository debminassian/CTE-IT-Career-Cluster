package Lesson 2;

public class Countdown {
    // Run this code first to see what is does. 
        // Replace the while loop with an equivalent for loop.
        int x = 10;
        while (x > 0)
        {
            System.out.println(x);
            x = x - 1;
        }
}

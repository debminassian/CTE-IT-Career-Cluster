# Example: For Loop
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

ForLoopExample

# Example: Countdown
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

CountdownExample

# Example: Count By Twos
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

CountByTwoExample

# Problem 1 - Print the Odds
Write a program that prints the odd numbers from 1 to 100.

# Problem 2 - Replace WHILE with FOR Loop
Run this program first to see what is does. Then rewrite the program so it uses a `for` loop instead of a `while` loop.
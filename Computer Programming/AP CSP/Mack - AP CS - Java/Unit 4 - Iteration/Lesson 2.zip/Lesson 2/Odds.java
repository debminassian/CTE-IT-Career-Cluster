package Lesson 2;

public class Odds {
    public static void main(String[] args)
    {
        // Your code goes here!
    }
}

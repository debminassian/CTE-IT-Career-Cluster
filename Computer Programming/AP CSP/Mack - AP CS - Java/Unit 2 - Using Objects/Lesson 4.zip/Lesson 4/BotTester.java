import java.util.Scanner;

public class BotTester
{
    public static void main(String[] args) {

        //Put your code here
        
    }
}


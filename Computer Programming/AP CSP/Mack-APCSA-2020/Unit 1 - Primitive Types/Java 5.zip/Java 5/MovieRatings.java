import java.util.Scanner;

public class MovieRatings
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter the number you want?");
        int num = input.nextInt();
        System.out.println(num);
    }
}

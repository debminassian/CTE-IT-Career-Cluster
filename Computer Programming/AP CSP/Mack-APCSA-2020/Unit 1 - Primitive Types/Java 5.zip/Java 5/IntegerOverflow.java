public class IntegerOverflow
{
    public static void main(String[] args)
    {
        // Start here!
    }
}


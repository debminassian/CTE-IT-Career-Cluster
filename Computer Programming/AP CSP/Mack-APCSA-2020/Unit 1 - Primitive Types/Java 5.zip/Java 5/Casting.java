public class Casting 
{
    public static void main(String[] args)
    {
        int total = 100;
        int numPeople = 40;
        double average = total / (double) numPeople;
        System.out.print("Total: ");
        System.out.println(total);
        System.out.print("People: ");
        System.out.println(numPeople);
        System.out.print("Average: ");
        System.out.println(average);
    }
}

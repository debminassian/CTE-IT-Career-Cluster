public class Wind extends Instrument
{
 
 
}

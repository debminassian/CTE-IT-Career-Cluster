public class Strings extends Instrument
{
    
       
}

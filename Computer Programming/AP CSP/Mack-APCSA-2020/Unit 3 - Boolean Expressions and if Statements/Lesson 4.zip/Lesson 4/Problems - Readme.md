# Example: Add Tip
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

Bill & BillTester

# Problem 1 - Positive, Negative, or Zero
Write a program that asks the user for a number.

Use an if-else if- else to determine if the number is positive, negative, or zero. A number is considered positive if it is greater than to 0. A number is negative if it is less than 0.

Once you determine a number is not positive and not negative, that leaves one case left – the number must equal zero!

If it is positive, print `“The number is positive!”`
If it is negative, print `“The number is negative!”`

If it is zero, print `“The number is neither positive nor negative!”`
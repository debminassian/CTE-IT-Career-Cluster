# Example: Can Vote
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

Voters

# Example: Negative Numbers
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

NegativeNumbers

# Example: Rectangle
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

Rectangle & RectangleTester

# Problem 1 - Cooking
Write a program that helps a novice microwave chef decide how long to microwave a refrigerated bread roll.

Use the `Math` class to generate a random integer between 0 and 60 to represent the number of seconds the roll will be microwaved.

Print out the number of seconds generated.

If the number is less than or equal to 20, print
`Perfect cooking time!`

If the number is greater than 20, print
`Your roll will catch fire!`

Here are a few output examples
Example 1:
```
Microwaving for 21 seconds
Your roll will catch fire!
```
Example 2:
```
Microwaving for 9 seconds
Perfect cooking time!
```
import java.util.Scanner;

public class Numbers
{
    public static void main(String[] args)
    {
        // Start here!
    }
}
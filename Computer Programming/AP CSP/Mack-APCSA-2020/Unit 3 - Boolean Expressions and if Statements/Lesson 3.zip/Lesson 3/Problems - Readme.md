# Example: Bill with add tip
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

bill & billTester

# Example: Even and Odd
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

EvenOdd

# Problem 1 - Positive or Negative
Write a program that asks the user for a number.

Use an if-else to determine if the number is positive or negative. A number will be considered positive if it is greater than or equal to 0. Otherwise, it is considered to be negative.

If it is positive, print “The number is positive!”
If it is negative, print “The number is negative!”


Very, very small technicality: zero is neither positive nor negative. We’ll consider it positive for this problem.
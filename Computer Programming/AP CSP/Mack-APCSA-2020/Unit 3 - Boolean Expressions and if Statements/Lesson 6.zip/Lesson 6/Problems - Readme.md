# Example: De Morgan AND
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

Biking

# Example: De Morgan OR
This is an example for this lesson. You are encouraged to play around with it, run and change the code, and learn how it works. When you are done, click continue to go to the next problem.

NightBiking

# Problem 1 - Odd and Even
The program in this starter code does NOT work as intended. Your job is to find out why and fix the issue.

The program asks the user for two positive integers and will determine if both numbers are odd, if both numbers are even, or if one number is odd and the other number is even. Test and run the program to see how it behaves BEFORE diving into resolving the issue.

Take notes as you work. You’ll need to answer the following questions in the free response that follows.
1. What was wrong with the program?
2. What expression was the programmer trying to use that gave the error?
3. How did you resolve the error?

HINT: The error can be resolved in the `OddEven` class.
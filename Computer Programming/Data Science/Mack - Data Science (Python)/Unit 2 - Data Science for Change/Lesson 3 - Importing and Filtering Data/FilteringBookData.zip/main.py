# Click on the Assignment tab to see the instructions. -->
# <-- Click on the data.csv file to see the dataset.

import pandas as pd

# import the data from the data.csv file


# Using loc - Print the title and page count columns 
# for rows 3 to 6


# Using iloc - Print the title and page count columns 
# for rows 3 to 6


# Using loc - Print the title of the book at index 1000


# Using iloc - Print the title of the book at index 1000


# Using loc - Print rows at index 10-15 and columns at index 3-5


# Using iloc - Print rows at index 10-15 and columns at index
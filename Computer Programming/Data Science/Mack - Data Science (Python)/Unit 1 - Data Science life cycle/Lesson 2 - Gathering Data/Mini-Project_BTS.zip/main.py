# Click on the Example tab to see more info. -->
# <-- Click on the data.csv file to see the dataset.

import pandas as pd

df = pd.read_csv (r"data.csv")
pd.set_option("display.max_columns", None)

print (df)
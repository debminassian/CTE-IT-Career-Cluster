my_list = [24, 9, 55, 12]

# Print the data type of the elements in the list. 

print("my_list elements are stored as " + str(type(my_list[0])))

# Print the length of the list, the min value, the max value 
# and the sum of the list.

print()
print("The length of my_list list is " + str(len(my_list)))
print("The minimum element is " + str(min(my_list)))
print("The maximum element is " + str(max(my_list)))
print("The sum of all elements is " + str(sum(my_list)))

# Add the first two elements of the list. 
# Print the result. 

print()
print("First element in my_list + second element in my_list = " 
+ str(my_list[0] + my_list[1]))


# Decide whether the following expression is true or false. 
# Add the print function to the expression to check your answers.

print()
print(my_list[0] > my_list[1]) # What will this print?

# Decide whether the following Boolean statement is true or false.
# Add the print function to the statement to check your answers.

print()
print(my_list[3] < my_list[1] or my_list[3] == my_list[2]) # What will this print?